package com.shubham.signuppage

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class x : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_x)
    }
}