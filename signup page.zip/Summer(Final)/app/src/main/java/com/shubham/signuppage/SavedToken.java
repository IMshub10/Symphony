package com.shubham.signuppage;

import android.content.Context;
import android.content.SharedPreferences;

public class SavedToken {
    private  static Context context;
    private static SavedToken instance;
    private static final String SHARED_PREF_NAME = "Firebase_Cloud_Messaging";
    private static final String KEY_ACCES_TOKEN = "token";

    public SavedToken(Context context) {
        this.context= context;
    }

    public static synchronized SavedToken getInstance(Context context){
        if (instance == null){
            instance = new SavedToken(context);
        }
        return  instance;
    }

    public boolean storeToken(String token){
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_ACCES_TOKEN,token);
        editor.apply();
        return true;
    }

    public String getToken(){
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME,Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_ACCES_TOKEN,null);
    }


}
