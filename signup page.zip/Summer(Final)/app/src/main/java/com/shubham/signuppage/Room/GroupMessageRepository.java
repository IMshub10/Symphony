package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class GroupMessageRepository {
    private GroupMessageDao groupMessageDao;
    private LiveData<List<GroupMessage>> allMessages;

    public GroupMessageRepository(Application application) {
        GroupMessageDatabase groupMessageDatabase = GroupMessageDatabase.getInstance(application);
        groupMessageDao = groupMessageDatabase.groupMessageDao();
    }
    public  void insert(GroupMessage groupMessage){
        new InsertFeedTask(groupMessageDao).execute(groupMessage);
    }
    public  void delete(GroupMessage groupMessage){
        new DeleteFeedTask(groupMessageDao).execute(groupMessage);
    }
    public  void update(GroupMessage groupMessage){
        new UpdateFeedTask(groupMessageDao).execute(groupMessage);
    }
    public  void deleteAllThreads(){
        new DeleteAllFeedTask(groupMessageDao).execute();
    }
    public  LiveData<List<GroupMessage>> getAllMessages(String workKey,String work,String receiverid,String threadId){
        allMessages = groupMessageDao.getAllMessages(workKey,work,receiverid,threadId);
        return  allMessages;
    }
    public  void  updateRead(String work,String receiverid,Boolean read){
        groupMessageDao.updateRead(work,receiverid,read);
    }
    public int getThreadMessageCount(String threadId){
        return  groupMessageDao.getThreadMessageCount(threadId);
    }

    public void deleteMessage(String messageId){
        new DeleteMessageTask(groupMessageDao).execute(messageId);
    }
    public List<GroupMessage> getThreadMessages(String threadId) {
        return groupMessageDao.getThreadMessage(threadId);
    }
    public List<GroupMessage> getMessages(String work,String receiverId,String cotains) {
        return groupMessageDao.getMessages(work,receiverId,cotains);
    }
    public List<GroupMessage> getMess(String work,String receiverId) {
        return groupMessageDao.getMess(work,receiverId);
    }

    public  void updateMessageLikeCount(String asKey,int likes){
        new UpdateMessageLikeCount(groupMessageDao,asKey,likes).execute();
    }

    private  static class UpdateMessageLikeCount extends  AsyncTask<Void,Void,Void>{

        private GroupMessageDao groupMessageDao;
        private String asKey;
        private int likes;

        public UpdateMessageLikeCount(GroupMessageDao groupMessageDao, String asKey, int likes) {
            this.groupMessageDao = groupMessageDao;
            this.asKey = asKey;
            this.likes = likes;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            groupMessageDao.updateMessageLikeCount(asKey,likes);
            return null;
        }

    }

    private  static  class InsertFeedTask extends AsyncTask<GroupMessage,Void,Void> {

        private GroupMessageDao groupMessageDao;
        private  InsertFeedTask(GroupMessageDao groupMessageDao){
            this.groupMessageDao = groupMessageDao;
        }

        @Override
        protected Void doInBackground(GroupMessage... groupMessages) {
            groupMessageDao.insert(groupMessages[0]);
            return null;

        }

    }
    private  static  class UpdateFeedTask extends  AsyncTask<GroupMessage,Void,Void>{

        private GroupMessageDao groupMessageDao;
        private  UpdateFeedTask(GroupMessageDao groupMessageDao){
            this.groupMessageDao = groupMessageDao;
        }

        @Override
        protected Void doInBackground(GroupMessage... groupMessages) {
            groupMessageDao.update(groupMessages[0]);
            return null;
        }

    }
    private  static  class DeleteFeedTask extends  AsyncTask<GroupMessage,Void,Void>{
        private GroupMessageDao groupMessageDao;
        private  DeleteFeedTask(GroupMessageDao groupMessageDao){
            this.groupMessageDao = groupMessageDao;
        }

        @Override
        protected Void doInBackground(GroupMessage... groupMessages) {
            groupMessageDao.delete(groupMessages[0]);
            return null;
        }

    }
    private  static  class DeleteMessageTask extends  AsyncTask<String,Void,Void>{

        private GroupMessageDao groupMessageDao;
        private  DeleteMessageTask(GroupMessageDao groupMessageDao){
            this.groupMessageDao = groupMessageDao;
        }

        @Override
        protected Void doInBackground(String... strings) {
            groupMessageDao.deleteMessage(strings[0]);
            return null;
        }

    }
    private  static  class DeleteAllFeedTask extends  AsyncTask<Void,Void,Void>{

        private GroupMessageDao groupMessageDao;
        private  DeleteAllFeedTask(GroupMessageDao groupMessageDao){
            this.groupMessageDao = groupMessageDao;
        }

        @Override
        protected Void doInBackground(Void ... voids) {
            groupMessageDao.deleteAllMessages();
            return null;
        }

    }
}
