package com.shubham.signuppage.Room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Member.class},version = 7,exportSchema = false)
public abstract class MemberDatabase  extends RoomDatabase {
    private static MemberDatabase instance;

    public abstract MemberDao memberDao();

    public  static  synchronized MemberDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    MemberDatabase.class,"member_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbTask(instance).execute();
        }
    };

    private  static class  PopulateDbTask extends AsyncTask<Void,Void,Void> {

        private  MemberDao memberDao;
        private PopulateDbTask(MemberDatabase database){
            memberDao = database.memberDao();
        }


        @Override
        protected Void doInBackground(Void... voids) {

            return null;
        }
    }
}
