package com.shubham.signuppage.Room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;


@Database(entities = {GroupThread.class},version = 6,exportSchema = false)
public abstract class GroupThreadDatabase extends RoomDatabase {
    private static GroupThreadDatabase instance;

    public  abstract GroupThreadDao groupThreadDao();

    public  static synchronized GroupThreadDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    GroupThreadDatabase.class,"group_thread_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbTask(instance).execute();
        }
    };
    private  static class  PopulateDbTask extends AsyncTask<Void,Void,Void> {

        private  GroupThreadDao groupThreadDao;
        private PopulateDbTask(GroupThreadDatabase database){
            groupThreadDao = database.groupThreadDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            return null;
        }
    }

}

