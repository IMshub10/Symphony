package com.shubham.signuppage.Groups;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.shubham.signuppage.Main3Activity;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.Member;
import com.shubham.signuppage.Room.MembersViewModel;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.Services.Tools;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import Interfaces.RecyclerViewItemClickListener;
import de.hdodenhof.circleimageview.CircleImageView;

public class CreateGroup extends AppCompatActivity {
    Toolbar toolbar;
    EditText group_name_edit;
    Button getMembers;
    ProgressBar prog;
    int count=0;
    RecyclerView recyclerView_create_group;
    TextView group_name;
    MembersViewModel membersViewModel;
    List<Member> memberList = new ArrayList<>();
    HashMap<Integer,String> hashMapx = new HashMap<>();
    HashMap<Integer,String> hashMapy = new HashMap<>();
    HashMap<Integer,Member> hashMapz= new HashMap<>();
    GroupsMembersRecyclerAdapter groupsMembersRecyclerAdapter;
    int x = 0;
    HashMap<Integer,Integer> hashMap = new HashMap<>();
    CircleImageView create_groups_image;
    List<String> members_list= new ArrayList<>();
    List<String> members_list_key= new ArrayList<>();
    List<Member> member_list_member = new ArrayList<>();
    String  val_team;
    String uniqueid;
    CoordinatorLayout root_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            setTheme(R.style.MainActivity3_Dark);
        else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_create_group);
        root_layout = findViewById(R.id.root_create_group);
        toolbar = findViewById(R.id.toolBar_create_group);
        group_name_edit = findViewById(R.id.group_name_edit);
        getMembers = findViewById(R.id.getMembers);
        prog = findViewById(R.id.prog_create_group);
        recyclerView_create_group = findViewById(R.id.recyclerView_group_members);
        create_groups_image = findViewById(R.id.create_groups_image);

        group_name = findViewById(R.id.group_name);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_dark);
        else {
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        }
        uniqueid = UUID.randomUUID().toString();
        groupsMembersRecyclerAdapter = new GroupsMembersRecyclerAdapter(getApplicationContext());
        recyclerView_create_group.setAdapter(groupsMembersRecyclerAdapter);
        recyclerView_create_group.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView_create_group.setHasFixedSize(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        membersViewModel = ViewModelProviders.of(this).get(MembersViewModel.class);
        /*
        membersViewModel.getAllMembers(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName).observe(this, new Observer<List<Member>>() {
            @Override
            public void onChanged(List<Member> members) {
                groupsMembersRecyclerAdapter.submitList(members);
            }
        });

         */
        new GetAllMembersWork().execute();
//        create_groups_image.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
//                    requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 1);
//                } else {
//                    getPhoto();
//                }
//            }
//        });
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (x==1){
                    group_name_edit.setVisibility(View.VISIBLE);
                    getMembers.setVisibility(View.VISIBLE);
                    recyclerView_create_group.setVisibility(View.INVISIBLE);
                    prog.setVisibility(View.INVISIBLE);
                    group_name.setVisibility(View.VISIBLE);

                    x=0;
                    count=0;
                    hashMapx.clear();
                    hashMapy.clear();
                    hashMapz.clear();
                    hashMap.clear();
                }else {
                    onBackPressed();
                }

            }
        });
        new GetMembersTask().execute();

        getMembers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                x=1;
                String team_name = group_name_edit.getText().toString();
                if (team_name.length()  > 5) {
                    for(int i=0;i<memberList.size();i++){
                        hashMap.put(i,0);
                    }
                    if (Tools.isNetworkAvailable(getApplicationContext())) {
                        group_name_edit.setVisibility(View.INVISIBLE);
                        getMembers.setVisibility(View.INVISIBLE);
                        group_name.setVisibility(View.INVISIBLE);
                        create_groups_image.setVisibility(View.INVISIBLE);
                        recyclerView_create_group.setVisibility(View.VISIBLE);
                        groupsMembersRecyclerAdapter.setOnItemClickListener(new RecyclerViewItemClickListener() {
                            @SuppressLint("ResourceAsColor")
                            @Override
                            public void onItemClick(View view, int position) {
                                //view.setBackgroundColor(R.color.colorPrimaryDark);
                                if (memberList.size() != 0) {
                                    if (hashMap.get(position) == 0) {
                                        view.setBackgroundColor(R.color.colorPrimaryDark);
                                        hashMap.put(position, 1);
                                        count++;
                                        Member memberz = new Member();
                                        memberz = memberList.get(position);
                                        hashMapx.put(position, memberList.get(position).getName());
                                        hashMapy.put(position, memberList.get(position).getMemberKey());
                                        hashMapz.put(position, memberz);
                                    } else {
                                        view.setBackgroundColor(0xFFFFFFFF);
                                        hashMap.put(position, 0);
                                        count--;
                                        hashMapz.remove(position);
                                        hashMapx.remove(position);
                                        hashMapy.remove(position);
                                    }
                                }
                            }

                            @Override
                            public void onLongItemClick(View view, int position) {
                            }
                        });

                    } else {
                        Snackbar.make(root_layout,"Network Error: No Internet Connection", Snackbar.LENGTH_LONG).show();
                        Toast.makeText(CreateGroup.this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(getApplicationContext(),"Minimum length of team name is 5 and description is 10",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
//    public void getPhoto() {
//        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//
//        startActivityForResult(intent, 1);
//
//    }
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == 1) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                getPhoto();
//            }
//        }
//    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//
//        if (requestCode == 1 && resultCode == Activity.RESULT_OK && data != null) {
//            try {
//                imageFile = data.getData();
//                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageFile);
//                //rofImageView.setImageBitmap(bitmap);
//
//                create_groups_image.setImageBitmap(bitmap);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.getMenuInflater().inflate(R.menu.workplace_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.tick ){
            if(x==1) {
//                if (imageFile !=null){
                    if( group_name_edit.getText().length() > 5){
                        int asd = 0;
                        int sad = 0;
                        while (asd < hashMapx.size()){
                            if(hashMapx.get(sad) != null){
                                members_list.add(hashMapx.get(sad));
                                members_list_key.add(hashMapy.get(sad));
                                member_list_member.add(hashMapz.get(sad));
                                asd++;
                            }
                            sad++;
                        }

                        val_team = group_name_edit.getText().toString();
                        UploadTask uploadTask = new UploadTask();
                        uploadTask.execute();
                        Intent intent = new Intent(this, Main3Activity.class);
                        startActivity(intent);
                    }
//                }else{
//                    Toast.makeText(this,"Please select A Group image first",Toast.LENGTH_SHORT).show();
//                }
            }else{
                Toast.makeText(this,"Please select members.",Toast.LENGTH_SHORT).show();
            }

        }
        return super.onOptionsItemSelected(item);
    }

    public class UploadTask extends AsyncTask<Void,Void,Void>{
        @Override
        protected Void doInBackground(Void... voids) {

            String string2 = new SimpleDateFormat("dd MM yy hh:mm a").format(new Date());
            String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
            Map<String,String> map= new HashMap<>();
            map.put("Creator",LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                    +LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
            map.put("Group Name",val_team);
//                            map.put("Group Image",uri.toString());
            map.put("Create Date",string2);
            map.put("Timestamp",timestamp);
            //FirebaseDatabase.getInstance().getReference().child("Workplaces")
            // .child(uniqueid+LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone).setValue(map);

            FirebaseDatabase.getInstance().getReference().child("Groups")
                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                    .child(uniqueid).setValue(map);

            Map<String,String> map2 = new HashMap<>();
            for (int j=0; j < members_list.size(); j++){
                map2.clear();
                map2.put("Member Name",members_list.get(j));
                map2.put("Member Key",member_list_member.get(j).getMemberKey());
                map2.put("Member Phone Number",member_list_member.get(j).getPhone());
                FirebaseDatabase.getInstance().getReference().child("Groups")
                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child(uniqueid)
                        .child("Members").child(members_list_key.get(j)).setValue(map2);
            }
            Map<String,String> map6 = new HashMap<>();
            map6.put("Member Name",LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName +
                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
            map6.put("Member Key",LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key);
//                            map6.put("Member Image Url",LocalUserService.getLocalUserFromPreferences(getApplicationContext()).ImageUrl);
            map6.put("Member Phone Number",LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone);

            String myKey = (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key);
            FirebaseDatabase.getInstance().getReference().child("Groups")
                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                    .child(uniqueid)
                    .child("Members")
                    .child(myKey).setValue(map6);

            for (int j=0; j < members_list_key.size();j++){
                Map<String,String>map3 = new HashMap<>();
                map3.clear();
                map3.put("Group Id",uniqueid);
                map3.put("Group Name",val_team);
                map3.put("Create Date",string2);
                map3.put("Creator",LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                        +LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
//                                map3.put("Group Image",uri.toString());
                map3.put("Timestamp",timestamp);
                FirebaseDatabase.getInstance().getReference().child("Users").child(members_list_key.get(j)).child("Groups").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child(uniqueid).setValue(map3);
            }
            Map<String,String> map7 = new HashMap<>();
            map7.put("Group Id",uniqueid);
            map7.put("Group Name",val_team);
//                            map7.put("Group Image",uri.toString());
            map7.put("Create Date",string2);
            map7.put("Timestamp",timestamp);
            map7.put("Creator",LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                    +LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
            FirebaseDatabase.getInstance().getReference().child("Users").child(myKey).child("Groups").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                    .child(uniqueid).setValue(map7);

            return null;
        }
    }

    public class GetMembersTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {

            if (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName != null) {
                FirebaseDatabase.getInstance().getReference().child("Workplaces").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey).child("Members")
                        .addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                                if (!dataSnapshot.getKey().equals(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)) {
                                    String phone = Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString();

                                    membersViewModel.insert(new Member(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Name").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString(),
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            null,
                                            null,0,null));
                                }
                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                                membersViewModel.update(new Member(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("Member Name").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString(),
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                        null,
                                        null,0,null));
                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                                membersViewModel.delete(new Member(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("Member Name").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString(),
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                        null,
                                        null,0,null));
                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
            }
            return null;
        }
    }

    public class GetAllMembersWork extends AsyncTask<Void,Void,Void>{
        @Override
        protected Void doInBackground(Void... voids) {
            memberList = membersViewModel.getAllMembersWork(LocalUserService.getLocalUserFromPreferences(CreateGroup.this).CurrentWorkplaceName);
            groupsMembersRecyclerAdapter.submitList(memberList);
            return null;
        }
    }


}
