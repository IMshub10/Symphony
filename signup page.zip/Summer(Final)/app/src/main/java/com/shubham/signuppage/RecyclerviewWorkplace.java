package com.shubham.signuppage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.shubham.signuppage.Room.AllUsers;

import Interfaces.RecyclerViewItemClickListener;
import de.hdodenhof.circleimageview.CircleImageView;

public class RecyclerviewWorkplace extends ListAdapter<AllUsers,RecyclerviewWorkplace.ViewHolder> {


    private Context context;

    private RecyclerViewItemClickListener recyclerViewItemClickListener;


    RecyclerviewWorkplace(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
    }

    private static final DiffUtil.ItemCallback<AllUsers> DIFF_CALLBACK = new DiffUtil.ItemCallback<AllUsers>() {
        @Override
        public boolean areItemsTheSame(@NonNull AllUsers oldItem, @NonNull AllUsers newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull AllUsers oldItem, @NonNull AllUsers newItem) {
            return false;
        }

    };
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.workplace_recyclerview,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }
    public  void  setOnItemClickListener(RecyclerViewItemClickListener recyclerViewItemClickListener){
        this.recyclerViewItemClickListener= recyclerViewItemClickListener;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AllUsers current_user= getItem(position);
        String firstName = current_user.getF_name();
        String lastName = current_user.getL_name();
        String fullName = firstName + " " +lastName;
        holder.workplace_user_name.setText(fullName);
        holder.workplace_user_phone.setText(current_user.getPhone());
    }

    @Override
    public int getItemCount() {
        return super.getItemCount();
    }

    @Override
    protected AllUsers getItem(int position) {
        return super.getItem(position);
    }

    public  class ViewHolder extends RecyclerView.ViewHolder {
        TextView  workplace_user_name, workplace_user_phone;
        CircleImageView workplace_user_image;
        public ViewHolder(@NonNull View view) {
            super(view);
            workplace_user_name=view.findViewById(R.id.workplace_user_name);
            workplace_user_phone=view.findViewById(R.id.workplace_user_phone);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecyclerviewWorkplace.this.recyclerViewItemClickListener.onItemClick(view,getLayoutPosition());

                }
            });
            view.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    RecyclerviewWorkplace.this.recyclerViewItemClickListener.onLongItemClick(view,getLayoutPosition());
                    return false;
                }
            });
        }
    }
    @Override
    public void onViewAttachedToWindow(@NonNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }
}
