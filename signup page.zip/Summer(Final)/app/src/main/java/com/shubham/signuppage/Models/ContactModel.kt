package com.shubham.signuppage.Models

class ContactModel {
    var name: String? = null
    var number: String? = null

}