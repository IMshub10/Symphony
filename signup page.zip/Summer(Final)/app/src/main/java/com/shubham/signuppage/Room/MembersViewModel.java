package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class MembersViewModel extends AndroidViewModel {

    private MemberRepository memberRepository;
    private LiveData<List<Member>> allMembers;
    private  int count;

    public MembersViewModel(@NonNull Application application) {
        super(application);
        memberRepository = new MemberRepository(application);
    }

    public  void  insert(Member member){
        memberRepository.insert(member);
    }
    public List<Member>getAllMembersWork(String work){
        return memberRepository.getAllMembersWork(work);
    }
    public  void  deleteMMember(String memberId){
        memberRepository.deleteMessage(memberId);
    }
    public  void  update(Member member){
        memberRepository.update(member);
    }
    public  void  updateMember(String key, String message, int messsageCount,String createDate,String timestamp){
        memberRepository.updateMember(key,message,messsageCount,createDate,timestamp);
    }
    public  void  updateMemberMessageCount(String key, String message,String createDate,String timestamp){
        memberRepository.updateMemberMessage(key,message,createDate,timestamp);
    }
    public  void  updateMemberMess(String key, int messageCount){
        memberRepository.updateMemberMess(key,messageCount);
    }
    public  void  delete(Member member){
        memberRepository.delete(member);
    }
    public  void deleteall(){
        memberRepository.deleteAllMembers();
    }
    public  LiveData<List<Member>> getAllMembers(String  work){
        allMembers = memberRepository.getAllMembers( work);
        return  allMembers;
    }
    public  LiveData<List<Member>> getAllMembersFrag(String  work,String lastMessage){
        allMembers = memberRepository.getAllMembersFrag(work,lastMessage);
        return  allMembers;
    }



}
