package com.shubham.signuppage.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface GroupMessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(GroupMessage groupMessage);

    @Update
    void update(GroupMessage groupMessage);

    @Delete
    void delete(GroupMessage groupMessage);

    @Query("Delete From group_message_table ")
    void deleteAllMessages();

    @Query("Delete From group_message_table WHERE `key`=:messageId ")
    void deleteMessage(String messageId);

    @Query("SELECT * FROM  group_message_table where threadId=:threadId")
    List<GroupMessage> getThreadMessage(String threadId);

    @Query("SELECT * FROM  group_message_table where (workplace =:work  AND group_receiverId=:receiverid)")
    List<GroupMessage> getMess(String work,  String receiverid);

    @Query("SELECT * FROM  group_message_table where workplace=:work AND group_receiverId=:receiverId AND (message_text LIKE '%' || :cotains ||'%' ) ORDER BY  timestamp DESC")
    List<GroupMessage> getMessages(String work,String receiverId,String cotains);

    @Query("SELECT * FROM  group_message_table where (workplaceKey =:workKey AND workplace =:work  AND group_receiverId=:receiverid AND threadId=:threadId) ORDER BY timestamp ASC ")
    LiveData<List<GroupMessage>> getAllMessages(String workKey,String work,  String receiverid, String threadId);

    @Query("UPDATE group_message_table SET likes=:likes WHERE `key`=:askey")
    void updateMessageLikeCount(String askey,int likes);

    @Query("UPDATE group_message_table SET read=:read WHERE workplace=:work AND group_receiverId=:receiverid")
    void  updateRead(String work,String receiverid,Boolean read);

    @Query("SELECT COUNT(`key`) FROM  group_message_table where threadId=:threadId ")
    int getThreadMessageCount(String threadId);
}
