package com.shubham.signuppage;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.shubham.signuppage.Models.Alluser;
import com.shubham.signuppage.Models.User;
import com.shubham.signuppage.Room.AllUserViewModel;
import com.shubham.signuppage.Room.AllUsers;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.Services.Tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import Interfaces.RecyclerViewItemClickListener;

public class CreateWorkplaceActivity extends AppCompatActivity {
    Toolbar toolbar;
    EditText team_name_edit, description_edit;
    Button getUsers;
    ProgressBar prog;
    RecyclerView recyclerView_workplace;

    TextView description, team_name;
    RecyclerviewWorkplace recyclerviewWorkplace;
    AllUserViewModel allUserViewModel;
    int x = 0;
    int count = 0;
    String val_decription, val_team;
    HashMap<Integer, Integer> hashMap = new HashMap<>();
    HashMap<Integer, String> hashMapx = new HashMap<>();
    HashMap<Integer, String> hashMapy = new HashMap<>();
    HashMap<Integer, Alluser> hashMapz = new HashMap<>();
    List<String> members_list = new ArrayList<>();
    List<String> members_list_key = new ArrayList<>();
    List<Alluser> member_list_user = new ArrayList<>();
    String uniqueid;
    int highest_position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            setTheme(R.style.MainActivity3_Dark);
        else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_main4);
        toolbar = findViewById(R.id.toolBar_workplace);
        team_name_edit = findViewById(R.id.team_name_edit);
        description_edit = findViewById(R.id.description_edit);
        getUsers = findViewById(R.id.getUsers);
        prog = findViewById(R.id.prog);
        description = findViewById(R.id.description);
        team_name = findViewById(R.id.workplace_name);
        recyclerView_workplace = findViewById(R.id.recyclerView_workplace);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_dark);
        else {
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        }
        allUserViewModel = ViewModelProviders.of(this).get(AllUserViewModel.class);

        //db=new DataContext(this,null,null,8);
        uniqueid = UUID.randomUUID().toString();
        getUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (team_name_edit.getText().length() > 3 && description_edit.getText().length() > 15) {
                    x = 1;
                    prog.setVisibility(View.VISIBLE);
                    team_name_edit.setVisibility(View.INVISIBLE);
                    description_edit.setVisibility(View.INVISIBLE);
                    getUsers.setVisibility(View.INVISIBLE);
                    recyclerView_workplace.setVisibility(View.VISIBLE);
                    team_name.setVisibility(View.INVISIBLE);
                    description.setVisibility(View.INVISIBLE);
                    new GetUsersTask().execute();

                } else {
//                    TODO: Remove Minimum Length of Description.
                    Toast.makeText(getApplicationContext(), "Minimum length of Team name is 5", Toast.LENGTH_SHORT).show();
                }
            }

        });
        recyclerviewWorkplace = new RecyclerviewWorkplace(this);
        recyclerView_workplace.setAdapter(recyclerviewWorkplace);
        recyclerView_workplace.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        try {

        }catch (Exception e){
            Log.e("Error",e.toString());
        }
        ((SimpleItemAnimator) recyclerView_workplace.getItemAnimator()).setSupportsChangeAnimations(false);
        prog.setVisibility(View.INVISIBLE);

        /*
        allUserViewModel.getAllUsers().observe(this, new Observer<List<AllUsers>>() {
            @Override
            public void onChanged(List<AllUsers> allUsers) {
                recyclerviewWorkplace.submitList(allUsers);
            }
        });

         */
        recyclerviewWorkplace.setOnItemClickListener(new RecyclerViewItemClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onItemClick(View view, int position) {
                //view.setBackgroundColor(R.color.colorPrimaryDark);
                if (recyclerviewWorkplace.getItemCount() != 0) {
                    /*
                    Alluser alluser = new Alluser(recyclerviewWorkplace.getItem(position).getKey(),
                            recyclerviewWorkplace.getItem(position).getF_name(),
                            recyclerviewWorkplace.getItem(position).getL_name(),
                            recyclerviewWorkplace.getItem(position).getPhone());
                    if (!member_list_user.contains(alluser)) {
                        view.setBackgroundColor(R.color.colorPrimary);
                        member_list_user.remove(alluser);
                    }else {
                        view.setBackgroundColor(R.color.design_default_color_background);
                        member_list_user.add(alluser);

                    }

                     */


                    if (hashMap.get(position) == 0) {
                        view.setBackgroundColor(R.color.colorPrimaryDark);
                        hashMap.put(position, 1);
                        count++;
                        Alluser alluser = new Alluser(recyclerviewWorkplace.getItem(position).getKey(),
                                recyclerviewWorkplace.getItem(position).getF_name(),
                                recyclerviewWorkplace.getItem(position).getL_name(),
                                recyclerviewWorkplace.getItem(position).getPhone());

                        hashMapx.put(position, recyclerviewWorkplace.getItem(position).getF_name() + "  " + recyclerviewWorkplace.getItem(position).getL_name());
                        hashMapy.put(position, recyclerviewWorkplace.getItem(position).getKey());
                        hashMapz.put(position, alluser);
                    } else {
                        view.setBackgroundColor(0xFFFFFFFF);
                        hashMap.put(position, 0);
                        count--;
                        hashMapz.remove(position);
                        hashMapx.remove(position);
                        hashMapy.remove(position);
                    }


                }
            }

            @Override
            public void onLongItemClick(View view, int position) {
            }
        });
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (x==1){
                    if (hashMapz.size()==0){
                        team_name_edit.setVisibility(View.VISIBLE);
                        description_edit.setVisibility(View.VISIBLE);
                        getUsers.setVisibility(View.VISIBLE);
                        recyclerView_workplace.setVisibility(View.INVISIBLE);
                        prog.setVisibility(View.INVISIBLE);
                        team_name.setVisibility(View.VISIBLE);
                        description.setVisibility(View.VISIBLE);
                        x=0;
                        count=0;
                        hashMapx.clear();
                        hashMapy.clear();
                        hashMapz.clear();
                        hashMap.clear();
                    }else {
                        Toast.makeText(CreateWorkplaceActivity.this, "Please unselect members", Toast.LENGTH_SHORT).show();
                    }

                }else {
                    onBackPressed();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{(Manifest.permission.READ_CONTACTS)}, 4);
        } else {
            new GetContactTask().execute();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 4) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                new GetContactTask().execute();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.getMenuInflater().inflate(R.menu.workplace_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.tick) {
            if (x == 1) {
                if (team_name_edit.getText().length() > 5 && description_edit.getText().length() > 15 && count > 0) {
                    int asd = 0;
                    int sad = 0;
                    while (asd < hashMapx.size()) {
                        if (hashMapx.get(sad) != null) {
                            members_list.add(hashMapx.get(sad));
                            members_list_key.add(hashMapy.get(sad));
                            member_list_user.add(hashMapz.get(sad));
                            asd++;
                        }
                        sad++;
                    }

                    val_decription = description_edit.getText().toString();
                    val_team = team_name_edit.getText().toString();
                    UploadTask uploadTask = new UploadTask();
                    uploadTask.execute();
                    Intent intent = new Intent(this, Main3Activity.class);
                    startActivity(intent);
                }
            } else {
                Toast.makeText(this, "Please select members", Toast.LENGTH_SHORT).show();
            }

        }
        else if (id == R.id.menu_refresh){
            if (hashMapz.size()==0){
                new GetUsersTask().execute();
            }else {
                Toast.makeText(this, "Please unselect members", Toast.LENGTH_SHORT).show();
            }
        }
        return true;
    }
    private List<String> getContactList() {

        List<String> PhoneList = new ArrayList<>();
        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if ((cur != null ? cur.getCount() : 0) > 0) {
            while (cur != null && cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                if (cur.getInt(cur.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));
                        if (phoneNo.length() > 13) {
                            phoneNo = phoneNo.substring(0, 3) + phoneNo.substring(4, 9) + phoneNo.substring(10, 15);
                        }else if (phoneNo.trim().length()==10){
                            String c ="+91";
                            phoneNo = c + phoneNo;
                        }
                        if (!phoneNo.equals(LocalUserService.getLocalUserFromPreferences(this).Phone)) {
                            PhoneList.add(phoneNo);
                        }
                        Log.i("TAG", "Name: " + name);
                        Log.i("TAG", "Phone Number: " + phoneNo);
                    }
                    pCur.close();
                }
            }
        }
        if (cur != null) {
            cur.close();
        }
        return  PhoneList;
    }


    public class GetContactTask extends AsyncTask<Void, Void, List<String>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            prog.setVisibility(View.VISIBLE);
        }

        @Override
        protected List<String> doInBackground(Void... voids) {
            return getContactList();

        }

        @Override
        protected void onPostExecute(List<String> strings) {
            super.onPostExecute(strings);
            prog.setVisibility(View.INVISIBLE);
            new InsertUserTask(strings).execute();

        }
    }

    public class UploadTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            int temp = 0;
            String tem;

            Map<String, String> map = new HashMap<>();
            map.put("Creator", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                    + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
            map.put("Description", val_decription);
            map.put("Workplace Name", val_team);
            //FirebaseDatabase.getInstance().getReference().child("Workplaces")
            // .child(uniqueid+LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone).setValue(map);

            FirebaseDatabase.getInstance().getReference().child("Workplaces")
                    .child(uniqueid).setValue(map);

            Map<String, String> map2 = new HashMap<>();

            for (int j = 0; j < members_list.size(); j++) {
                tem = String.valueOf(j);
                map2.clear();
                map2.put("Member Name", members_list.get(j));
                map2.put("Member Key", member_list_user.get(j).getKey());
//                map2.put("Member Image Url",member_list_user.get(j).ImageUrl);
                map2.put("Member Phone Number", member_list_user.get(j).getPhone());
                FirebaseDatabase.getInstance().getReference().child("Workplaces")
                        .child(uniqueid)
                        .child("Members").child(members_list_key.get(j)).setValue(map2);

            }
            Map<String, String> map6 = new HashMap<>();
            map6.put("Member Name", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "+
                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
            map6.put("Member Key", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key);
            map6.put("Member Image Url", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).ImageUrl);
            map6.put("Member Phone Number", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone);
            String myKey = (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key);
            FirebaseDatabase.getInstance().getReference().child("Workplaces")
                    .child(uniqueid)
                    .child("Members")
                    .child(myKey).setValue(map6);

            for (int j = 0; j < members_list_key.size(); j++) {
                Map<String, String> map3 = new HashMap<>();
                map3.clear();
                map3.put("Workplace Id", uniqueid);
                map3.put("Workplace Name", val_team);
                map3.put("Creator", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                        + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
                FirebaseDatabase.getInstance().getReference().child("Users").child(members_list_key.get(j)).child("Workplaces")
                        .child(uniqueid).setValue(map3);
            }
            Map<String, String> map7 = new HashMap<>();
            map7.put("Workplace Id", uniqueid);
            map7.put("Workplace Name", val_team);
            map7.put("Creator", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                    + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName);
            FirebaseDatabase.getInstance().getReference().child("Users").child(myKey).child("Workplaces")
                    .child(uniqueid).setValue(map7);

            return null;
        }
    }

    public class InsertUserTask extends AsyncTask<Void, Void, Void> {
        List<String> PhoneList = new ArrayList<>();

        public InsertUserTask(List<String> phoneList) {
            PhoneList = phoneList;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            prog.setVisibility(View.VISIBLE);

        }

        @Override
        protected Void doInBackground(Void... voids) {
            if (Tools.isNetworkAvailable(CreateWorkplaceActivity.this)) {
                FirebaseDatabase.getInstance().getReference().child("Users").addChildEventListener(new ChildEventListener() {
                    List<User> friendList = new ArrayList<User>();

                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        //Map map=dataSnapshot.getValue(Map.class);
                        if (dataSnapshot.exists() && !Objects.requireNonNull(dataSnapshot.getKey()).equals(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)) {


//                                    friend.ImageUrl = Objects.requireNonNull(dataSnapshot.child("Profile Image").getValue()).toString();
                            if (PhoneList.contains(Objects.requireNonNull(dataSnapshot.child("Phone number").getValue()).toString())) {
                                allUserViewModel.insert(new AllUsers(Objects.requireNonNull(dataSnapshot.getKey()),
                                        Objects.requireNonNull(dataSnapshot.child("F_Name").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("L_Name").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("Phone number").getValue()).toString()));
                            }
                            //    for(int i=0;i<db.getUserFriendList().size();i++){
                            //      hashMap.put(i,0);
                        }
                        // db = new DataContext(getApplicationContext(), null, null, 1);


                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            prog.setVisibility(View.INVISIBLE);
        }
    }

    public class GetUsersTask extends AsyncTask<Void, Void, List<AllUsers>> {

        @Override
        protected List<AllUsers> doInBackground(Void... voids) {
            return allUserViewModel.getAllUsers2();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            prog.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(List<AllUsers> allUsers) {
            super.onPostExecute(allUsers);
            prog.setVisibility(View.INVISIBLE);
            recyclerviewWorkplace.submitList(allUsers);
            for (int i = 0; i < allUsers.size(); i++) {
                hashMap.put(i, 0);
            }

        }
    }
}
