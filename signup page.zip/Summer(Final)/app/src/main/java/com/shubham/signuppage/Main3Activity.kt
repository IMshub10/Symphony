package com.shubham.signuppage

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory
import androidx.navigation.Navigation
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import com.bumptech.glide.Glide
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.iid.FirebaseInstanceId
import com.google.firebase.iid.InstanceIdResult
import com.google.firebase.messaging.FirebaseMessaging
import com.shubham.signuppage.Models.PrefernecesModel
import com.shubham.signuppage.Room.*
import com.shubham.signuppage.Services.LocalUserService
import com.shubham.signuppage.Services.LocalUserService.getLocalUserFromPreferences
import com.shubham.signuppage.ui.feeds.FeedsViewModel


class Main3Activity : AppCompatActivity() {
    var actionBarDrawerToggle: ActionBarDrawerToggle? = null
    var nav_prof_image: ImageView? = null
    var nav_prof_name: TextView? = null
    var nav_prof_phoneNo: TextView? = null
    var nav_current_workplace: TextView? = null
    var auth: FirebaseAuth? = null
    var user: PrefernecesModel? = null
    var sharedPreferences: SharedPreferences? = null
    var l_name: String? = null
    var phoneNo: String? = null
    var f_name: String? = null
    var database: FirebaseDatabase? = null
    var bar: ProgressBar? = null
    var cardView: CardView? = null
    var textView: TextView? = null
    var membersViewModel: MembersViewModel? = null
    var feedsViewModel: FeedsViewModel? = null
    var allUserViewModel: AllUserViewModel? = null
    var groupMemberViewModel: GroupMemberViewModel? = null
    var groupMessageViewModel: GroupMessageViewModel? = null
    var groupsViewModel: GroupsViewModel? = null
    var groupThreadsViewModel: GroupThreadsViewModel? = null
    var messageViewModel: MessageViewModel? = null
    var threadsViewModel: ThreadsViewModel? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId ) {
            setTheme(R.style.MainActivity3_Dark);
        } else {
            setTheme(R.style.AppTheme);
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close)
        drawer.addDrawerListener(actionBarDrawerToggle!!)
        actionBarDrawerToggle!!.syncState()
        val nav_drawer_view = findViewById<NavigationView>(R.id.navigation_drawer)
        val hView = nav_drawer_view.getHeaderView(0)
        nav_prof_image = hView.findViewById<View>(R.id.nav_prof_image) as ImageView
        nav_prof_name = hView.findViewById<View>(R.id.nav_prof_name) as TextView
        nav_prof_phoneNo = hView.findViewById<View>(R.id.nav_prof_phoneNo) as TextView
        nav_current_workplace = hView.findViewById<View>(R.id.nav_current_workplace) as TextView
        auth = FirebaseAuth.getInstance()
        sharedPreferences = getSharedPreferences("LocalUser", 0)
        val notificationManagerCompat = NotificationManagerCompat.from(this)
        notificationManagerCompat.cancelAll()
        val navigationView = findViewById<BottomNavigationView>(R.id.nav_view)
        val appBarConfiguration = AppBarConfiguration.Builder(
                R.id.navigation_feeds, R.id.navigation_groups, R.id.navigation_mails,
                R.id.navigation_schedule)
                .build()
        val navController = Navigation.findNavController(this, R.id.nav_host_fragment)
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration)
        NavigationUI.setupWithNavController(navigationView, navController)


        if (LocalUserService.getLocalUserFromPreferences(this).FirstName == null
                || LocalUserService.getLocalUserFromPreferences(this).LastName == null ||
                LocalUserService.getLocalUserFromPreferences(this).Key == null) {

            LocalUserService.deleteLocalUserFromPreferences(this)
            val intent: Intent = Intent(this, MainActivity::class.java)
            auth!!.signOut();
            startActivity(intent);
        }
        info
        membersViewModel = AndroidViewModelFactory(application).create(MembersViewModel::class.java)
        feedsViewModel = AndroidViewModelFactory(application).create(FeedsViewModel::class.java)
        allUserViewModel = AndroidViewModelFactory(application).create(AllUserViewModel::class.java)
        groupMemberViewModel = AndroidViewModelFactory(application).create(GroupMemberViewModel::class.java)
        groupMessageViewModel = AndroidViewModelFactory(application).create(GroupMessageViewModel::class.java)
        groupsViewModel = AndroidViewModelFactory(application).create(GroupsViewModel::class.java)
        groupThreadsViewModel = AndroidViewModelFactory(application).create(GroupThreadsViewModel::class.java)
        messageViewModel = AndroidViewModelFactory(application).create(MessageViewModel::class.java)
        threadsViewModel = AndroidViewModelFactory(application).create(ThreadsViewModel::class.java)
        expanListView()
        FirebaseInstanceId.getInstance().instanceId.addOnSuccessListener(this@Main3Activity, OnSuccessListener<InstanceIdResult> { instanceIdResult ->
            val newToken = instanceIdResult.token
            Log.e("newToken", newToken)
            storeToken(newToken)
        })
        FirebaseMessaging.getInstance().subscribeToTopic("mails");
    }


    private fun storeToken(s: String) {
        SavedToken.getInstance(applicationContext).storeToken(s)
    }

    @get:SuppressLint("SetTextI18n")
    private val info: Unit
        get() {
            user = getLocalUserFromPreferences(applicationContext)
            phoneNo = user!!.Phone
            f_name = user!!.FirstName
            l_name = user!!.LastName
//            imageUrl = user!!.ImageUrl
            Glide.with(applicationContext).asBitmap().load(R.drawable.dp).into(nav_prof_image!!)
            nav_prof_phoneNo!!.text = phoneNo
            nav_prof_name!!.text = "$f_name $l_name"
            if (getLocalUserFromPreferences(applicationContext).CurrentWorkplaceName != null) {
                nav_current_workplace!!.text = "  " + getLocalUserFromPreferences(applicationContext).CurrentWorkplaceName + "  +  "
                nav_current_workplace!!.setBackgroundColor(Color.RED)
                nav_current_workplace!!.setOnClickListener {
                    val intent = Intent(applicationContext, AddMoreContacts::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK //this will always start your activity as a new task
                    startActivity(intent)
                }
            }
        }

    override fun onBackPressed() {
        val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
        if (drawer!!.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)
        } else {
            /*
            Intent x= new Intent(Main3Activity.this,MainActivity.class);
            auth.signOut();

            SharedPreferences pref = this.getSharedPreferences("LocalUser",0);
            pref.edit().clear().apply();
            db.deleteAllFriendsFromLocalDB();
            db.deleteAllchat();
            startActivity(x);

             */
            val a = Intent(Intent.ACTION_MAIN)
            a.addCategory(Intent.CATEGORY_HOME)
            startActivity(a)
            super.onBackPressed()
        }
    }

    fun expanListView() {
        var expandableListAdapter: ExpandableListAdapter? = null
        val expandableListView = findViewById<ExpandableListView>(R.id.expandable_list_view)
        val listGroup: MutableList<String> = ArrayList<String>()
        val listchild: HashMap<String, List<String>> = HashMap()
        listGroup.add("Workplaces")
        listGroup.add("Add a new Workplace")
        listGroup.add("Dark Mode")
        listGroup.add("Settings")
        listGroup.add("Archive")
        listGroup.add("Help & Support")
        listGroup.add("Log Out ")


        val lisItem: MutableList<String> = ArrayList()

        FirebaseDatabase.getInstance().reference.child("Users").child(FirebaseAuth.getInstance().currentUser!!.uid).child("Workplaces")
                .addChildEventListener(object : ChildEventListener {
                    override fun onChildAdded(dataSnapshot: DataSnapshot, s: String?) {
                        if (dataSnapshot.exists()) {
                            lisItem.add(dataSnapshot.child("Workplace Name").value.toString())
                            sharedPreferences!!.edit().putString(dataSnapshot.child("Workplace Name").value.toString(), dataSnapshot.key).apply()
                            sharedPreferences!!.edit().putString(dataSnapshot.child("Workplace Name").value.toString() + " Creator", dataSnapshot.child("Creator").value.toString()).apply()
                        }
                    }

                    override fun onChildChanged(dataSnapshot: DataSnapshot, s: String?) {}
                    override fun onChildRemoved(dataSnapshot: DataSnapshot) {}
                    override fun onChildMoved(dataSnapshot: DataSnapshot, s: String?) {}
                    override fun onCancelled(databaseError: DatabaseError) {}
                })
        listchild.put(listGroup.get(0), lisItem)
        expandableListAdapter = ExpandableListAdapter(this, listGroup, listchild)
        expandableListView!!.setAdapter(expandableListAdapter)
        expandableListView.setOnGroupClickListener { parent, v, groupPosition, id ->
            if (groupPosition == 1) {
                val intent: Intent = Intent(this, CreateWorkplaceActivity::class.java)
                startActivity(intent)
            }
            if (groupPosition == 2) {
                if (LocalUserService.getLocalUserFromPreferences(this).CurrentWorkplaceKey != null) {
                    FirebaseDatabase.getInstance().getReference().child("Workplaces")
                            .child(getLocalUserFromPreferences(applicationContext).CurrentWorkplaceKey)
                            .addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onCancelled(p0: DatabaseError) {
                                }

                                override fun onDataChange(p0: DataSnapshot) {
                                    if (p0.child("Creator").getValue().toString() == (LocalUserService.getLocalUserFromPreferences(this@Main3Activity).FirstName
                                                    + " " + LocalUserService.getLocalUserFromPreferences(this@Main3Activity).LastName))
                                        Toast.makeText(applicationContext, p0.child("Creator").getValue().toString(), Toast.LENGTH_SHORT).show()
                                }
                            })
                } else {
                    Toast.makeText(this, "Please select a workplace.", Toast.LENGTH_SHORT).show()
                }
            }
            if (groupPosition == 4) {
                if (LocalUserService.getLocalUserFromPreferences(this).CurrentWorkplaceName != null) {
                    Toast.makeText(applicationContext, getLocalUserFromPreferences(applicationContext).CurrentWorkplaceName, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please select a workplace.", Toast.LENGTH_SHORT).show()
                }
            }
            if (groupPosition == 5) {
                if (LocalUserService.getLocalUserFromPreferences(this).CurrentWorkplaceKey != null) {
                    Toast.makeText(applicationContext, getLocalUserFromPreferences(applicationContext).CurrentWorkplaceKey, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please select a workplace.", Toast.LENGTH_SHORT).show()
                }
            }
            if (groupPosition == 6) {
                val intent: Intent = Intent(this, MainActivity::class.java)
                auth!!.signOut();
                var pref: SharedPreferences = this.getSharedPreferences("LocalUser", 0);
                pref.edit().clear().apply();
                membersViewModel!!.deleteall()
                feedsViewModel!!.deleteall()
                allUserViewModel!!.deleteAll()
                groupMemberViewModel!!.deleteAll()
                groupMessageViewModel!!.deleteall()
                groupsViewModel!!.deleteall()
                groupThreadsViewModel!!.deleteall()
                messageViewModel!!.deleteall()
                threadsViewModel!!.deleteall()
                startActivity(intent);
            }
            false
        }

        expandableListView.setOnChildClickListener { parent, v, groupPosition, childPosition, id ->

            sharedPreferences!!.edit().putString("CurrentWorkplaceName", expandableListAdapter.getChild(groupPosition, childPosition).toString()).apply()
            val s: String? = sharedPreferences!!.getString("CurrentWorkplaceName", null)
            val s1: String? = sharedPreferences!!.getString("CurrentWorkplaceName", null) + " Creator"
            sharedPreferences!!.edit().putString("CurrentWorkplaceKey", sharedPreferences!!.getString(s, null)).apply()
            sharedPreferences!!.edit().putString("CurrentWorkplaceCreator", sharedPreferences!!.getString(s1, null)).apply()
            val drawer = findViewById<DrawerLayout>(R.id.drawer_layout)
            bar = findViewById(R.id.bar)
            //bar!!.setVisibility(View.VISIBLE)
            cardView = findViewById(R.id.card_alerrt)
            textView = findViewById(R.id.alerrt)
            textView!!.setText(" Changing Workplace to   " + sharedPreferences!!.getString("CurrentWorkplaceName", null))
            cardView!!.setVisibility(View.VISIBLE)
            if (drawer!!.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START)
            }
            val handler = Handler()
            handler.postDelayed(Runnable {
                val intent = Intent(applicationContext, Main3Activity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK //this will always start your activity as a new task
                startActivity(intent)
            }, 2000)
            false
        }


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }

}