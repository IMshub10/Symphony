package com.shubham.signuppage.TableBuilder;

public enum HighlightMode {
    COLOR,
    IMAGE
}
