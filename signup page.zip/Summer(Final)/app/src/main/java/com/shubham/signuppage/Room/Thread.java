package com.shubham.signuppage.Room;


import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.List;

@Entity(tableName = "thread_table")
public class Thread {
    @PrimaryKey(autoGenerate = false)
    @NonNull
    private String key;

    private String sender;

    private String receiver;

    private  String workplaceKey;

    private String workplace;

    private String create_date;

    private String timestamp;

    private int position;



    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public String getWorkplaceKey() {
        return workplaceKey;
    }

    public String getWorkplace() {
        return workplace;
    }

    public String getCreate_date() {
        return create_date;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public int getPosition() {
        return position;
    }

    public Thread(@NonNull String key, String sender, String receiver, String workplaceKey, String workplace, String create_date, String timestamp, int position) {
        this.key = key;
        this.sender = sender;
        this.receiver = receiver;
        this.workplaceKey = workplaceKey;
        this.workplace = workplace;
        this.create_date = create_date;
        this.timestamp = timestamp;
        this.position = position;
    }
}
