package com.shubham.signuppage.Room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {GroupMessage.class},version = 7,exportSchema = false)
public abstract  class GroupMessageDatabase  extends RoomDatabase {

    private static GroupMessageDatabase instance;

    public  abstract GroupMessageDao groupMessageDao();

    public  static  synchronized GroupMessageDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    GroupMessageDatabase.class,"group_message_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }
    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbTask(instance).execute();
        }
    };

    private  static class  PopulateDbTask extends AsyncTask<Void,Void,Void> {

        private  GroupMessageDao groupMessageDao;
        private PopulateDbTask(GroupMessageDatabase database){
            groupMessageDao = database.groupMessageDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            return null;
        }
    }


}

