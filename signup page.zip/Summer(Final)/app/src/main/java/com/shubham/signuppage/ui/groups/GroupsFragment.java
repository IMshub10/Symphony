package com.shubham.signuppage.ui.groups;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.shubham.signuppage.Groups.CreateGroup;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.Groups;
import com.shubham.signuppage.Room.GroupsDao;
import com.shubham.signuppage.Room.GroupsViewModel;
import com.shubham.signuppage.Services.LocalUserService;

import java.util.List;
import java.util.Objects;

public class GroupsFragment extends Fragment {
    private RecyclerView recyclerView;
    private GroupsViewModel groupsViewModel;
    GroupsDao groupsDao;
    private String WorkplaceKey;
    private String WorkplaceName;
    private String senderTry;
    private TextView nullWorkplace;
    private RelativeLayout parent_fragment_groups;

    public void init(View root){
        parent_fragment_groups= root.findViewById(R.id.parent_fragment_groups);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_groups, container, false);
        setHasOptionsMenu(true);
        init(root);
        nullWorkplace = root.findViewById(R.id.nullWorkplace);
        recyclerView = root.findViewById(R.id.groups_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setHasFixedSize(true);
        final GroupsAdapter adapter = new GroupsAdapter(getContext());
        recyclerView.setAdapter(adapter);
//        recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        groupsViewModel = ViewModelProviders.of(this).get(GroupsViewModel.class);
        String workPlace = LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName;
        groupsViewModel.getAllGroups(workPlace).observe(getViewLifecycleOwner(), new Observer<List<Groups>>() {
            @Override
            public void onChanged(List<Groups> groups) {
                adapter.submitList(groups);
            }
        });
        if (LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName==null){
            nullWorkplace.setVisibility(View.VISIBLE);
        }else {
            nullWorkplace.setVisibility(View.GONE);
        }
        WorkplaceKey = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey;
        WorkplaceName = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceName;
        senderTry = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Fullname;
        new GetGroupsTask().execute();
        new ReceiveLatestMessages().execute();
        return root;

    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.groups_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_group:
                if (WorkplaceKey==null){
                    Toast.makeText(getContext(), "Please select a workplace", Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(getContext(), CreateGroup.class);
                    startActivity(intent);
                }
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    public class GetGroupsTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (WorkplaceKey != null) {
                SharedPreferences timestampPrefernces = getContext().getSharedPreferences("Timestamp", 0);
                FirebaseDatabase.getInstance().getReference().child("Users")
                        .child(LocalUserService.getLocalUserFromPreferences(getContext()).Key).child("Groups").child(WorkplaceKey).addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        long currentTime = Long.parseLong(Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString());
                        if (currentTime > timestampPrefernces.getLong("Groups" + "LatestTimestamp" + WorkplaceName, 0)) {
                            try {
                                groupsViewModel.insert(new Groups(dataSnapshot.getKey(),
                                        Objects.requireNonNull(dataSnapshot.child("Group Name").getValue()).toString(),
                                        LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName,
                                        null,
                                        dataSnapshot.child("Create Date").getValue().toString(),
                                        "",
                                        0,
                                        dataSnapshot.child("Timestamp").getValue().toString()));

                                timestampPrefernces.edit().putLong("Groups" + "LatestTimestamp" + LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName, currentTime).apply();

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                        groupsViewModel.deleteGroup(dataSnapshot.getKey());

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
            return null;
        }
    }

    private class ReceiveLatestMessages extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            if (WorkplaceKey != null) {
                SharedPreferences timestampPrefernces = getContext().getSharedPreferences("Timestamp", 0);
                FirebaseDatabase.getInstance().getReference()
                        .child("Groups")
                        .child(WorkplaceKey)
                        .child("GroupMails")
                        .child("LatestGroupMessages").addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        if (dataSnapshot.exists()) {
                            long currentTime = Long.parseLong(Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString());
                            if (currentTime > timestampPrefernces.getLong("Groups" + "LatestMessageTimestamp" + WorkplaceName, 0)) {

                                if (!Objects.requireNonNull(dataSnapshot.child("Sender").getValue()).toString().equals(senderTry)) {
                                    try {
                                        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                        Ringtone r = RingtoneManager.getRingtone(getContext(), notification);
                                        groupsViewModel.updateGroupsMessageCount(Objects.requireNonNull(dataSnapshot.child("ReceiverKey").getValue()).toString(),
                                                Objects.requireNonNull(dataSnapshot.child("Message").getValue()).toString()
                                                , Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString());

                                        r.play();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                                timestampPrefernces.edit().putLong("Groups" + "LatestMessageTimestamp" + WorkplaceName, currentTime).apply();
                            }

                        }

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
            return null;
        }
    }


}
