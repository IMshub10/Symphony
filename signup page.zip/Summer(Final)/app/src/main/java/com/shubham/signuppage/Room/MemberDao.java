package com.shubham.signuppage.Room;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Entity;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface MemberDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Member member);

    @Update
    void update(Member member);

    @Delete
    void delete(Member member);

    @Query("Delete From member_table ")
    void deleteAllMembers();

    @Query("Delete From member_table WHERE `key`=:memberId ")
    void deleteMessage(String memberId);

    @Query("SELECT * FROM  member_table where workplace=:work   ORDER BY name ASC ")
    List<Member> getAllMembersWork(String work);

    @Query("SELECT * FROM  member_table where workplace=:work   ORDER BY name ASC ")
    LiveData<List<Member>> getAllMembers(String work);

    @Query("SELECT * FROM  member_table WHERE  workplace=:work AND lastMessage!=:lastmess   ORDER BY timestamp DESC")
    LiveData<List<Member>> getAllMembersFrag(String work,String lastmess);

    @Query("UPDATE member_table SET lastMessage=:lastMess,createDate=:createDate,messsageCount=:messageCount,timestamp=:timestam WHERE `key`=:askey")
    void updateMember(String askey,String lastMess,int messageCount,String createDate,String timestam);


    @Query("UPDATE member_table SET lastMessage=:lastMess,createDate=:createDate,messsageCount=messsageCount+1,timestamp=:timestam WHERE `key`=:askey ")
    void updateMemberMessageCOunt(String askey,String lastMess,String createDate,String timestam);

    @Query("UPDATE member_table SET messsageCount=:messageCount WHERE `key`=:askey")
    void updateMemberMessage(String askey,int messageCount);

}
