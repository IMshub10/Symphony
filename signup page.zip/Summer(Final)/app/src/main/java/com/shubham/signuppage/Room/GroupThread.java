package com.shubham.signuppage.Room;


import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "group_thread_table")
public class GroupThread {
    @PrimaryKey(autoGenerate = false)
    @NonNull
    private String key;

    private String sender;

    private String group_receiver;

    private String group_receiver_id;

    private String workplaceKey;

    private String workplace;

    private String create_date;

    private String timestamp;

    private int position;

    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getSender() {
        return sender;
    }

    public String getGroup_receiver() {
        return group_receiver;
    }

    public String getGroup_receiver_id() {
        return group_receiver_id;
    }

    public String getWorkplaceKey() {
        return workplaceKey;
    }

    public String getWorkplace() {
        return workplace;
    }

    public String getCreate_date() {
        return create_date;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public int getPosition() {
        return position;
    }

    public GroupThread(@NonNull String key, String sender, String group_receiver, String group_receiver_id, String workplaceKey, String workplace, String create_date, String timestamp, int position) {
        this.key = key;
        this.sender = sender;
        this.group_receiver = group_receiver;
        this.group_receiver_id = group_receiver_id;
        this.workplaceKey = workplaceKey;
        this.workplace = workplace;
        this.create_date = create_date;
        this.timestamp = timestamp;
        this.position = position;
    }
}
