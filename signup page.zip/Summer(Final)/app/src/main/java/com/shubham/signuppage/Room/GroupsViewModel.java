package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class GroupsViewModel extends AndroidViewModel {

    private GroupsRepository groupsRepository;
    private LiveData<List<Groups>> allGroups;
    private  int count;

    public GroupsViewModel(@NonNull Application application) {
        super(application);
        groupsRepository = new GroupsRepository(application);
    }

    public  void  insert(Groups groups){
        groupsRepository.insert(groups);
    }
    public  void  update(Groups groups){
        groupsRepository.update(groups);
    }
    public  void  delete(Groups groups){
        groupsRepository.delete(groups);
    }
    public  void deleteall(){
        groupsRepository.deleteAllGroups();
    }
    public  LiveData<List<Groups>> getAllGroups(String  work){
        allGroups = groupsRepository.getAllGroups( work);
        return  allGroups;
    }
    public  void  deleteGroup(String groupId){
        groupsRepository.deleteGroup(groupId);
    }
    public int checkGroupAlreadyExists(String groupKey,String work){
        return  groupsRepository.checkGroupAlreadyExists(groupKey, work);
    }

    public  void  updateGroup(String key, String message, int messsageCount,String createDate,String timestamp){
        groupsRepository.updateMember(key,message,messsageCount,createDate,timestamp);
    }
    public  void  updateGroupsMessageCount(String key, String message,String createDate,String timestamp){
        groupsRepository.updateMemberMessage(key,message,createDate,timestamp);
    }
    public  void  updateGroupsMess(String key, int messageCount){
        groupsRepository.updateMemberMess(key,messageCount);
    }



}
