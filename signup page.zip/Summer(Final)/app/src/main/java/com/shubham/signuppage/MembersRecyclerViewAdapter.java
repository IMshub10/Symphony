package com.shubham.signuppage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shubham.signuppage.Room.Member;

import Interfaces.RecyclerViewItemClickListener;
import de.hdodenhof.circleimageview.CircleImageView;

public class MembersRecyclerViewAdapter extends ListAdapter<Member, MembersRecyclerViewAdapter.MembersHolder> {

    private  Context context;
    private RecyclerViewItemClickListener recyclerViewItemClickListener;

    MembersRecyclerViewAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
    }
    private  static  final DiffUtil.ItemCallback<Member>DIFF_CALLBACK = new DiffUtil.ItemCallback<Member>() {
        @Override
        public boolean areItemsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return oldItem.getName().equals(newItem.getName())
                    && oldItem.getWorkplace().equals(newItem.getWorkplace());
        }
    };
    public  void  setOnItemClickListener(RecyclerViewItemClickListener recyclerViewItemClickListener){
        this.recyclerViewItemClickListener= recyclerViewItemClickListener;
    }

    @NonNull
    @Override
    public MembersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.groups_contacts_listitem,parent,false);
        return new MembersHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MembersHolder holder, int position) {
        Member current_member = getItem(position);
        holder.user_name.setText(current_member.getName());
        holder.user_phone.setText(current_member.getPhone());
        Glide.with(holder.user_image.getContext())
                .asBitmap()
                .error(R.drawable.mas)
                .load(R.drawable.dp)
                .into(holder.user_image);
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*
                Intent intent = new Intent(context,ChatFinalActivity.class);
                intent.putExtra("MemberKey",current_member.getKey());
                intent.putExtra("CreateDate",current_member. getCreateDate());
                intent.putExtra("name",current_member.getName());
                intent.putExtra("Phone",current_member.getPhone());
                intent.putExtra("Friend_key",current_member.getMemberKey());
                intent.putExtra("Message",current_member.getLastMessage());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

                 */
            }
        });
    }
    class MembersHolder extends RecyclerView.ViewHolder{
        CircleImageView user_image;
        TextView user_name, user_phone;
        RelativeLayout relativeLayout;

        public MembersHolder(@NonNull View itemView) {
            super(itemView);
            user_image = itemView.findViewById(R.id.user_image);
            user_name = itemView.findViewById(R.id.user_name);
            user_phone = itemView.findViewById(R.id.user_phone);
            relativeLayout= itemView.findViewById(R.id.members_relativeLayout);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MembersRecyclerViewAdapter.this.recyclerViewItemClickListener.onItemClick(itemView,getLayoutPosition());
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    MembersRecyclerViewAdapter.this.recyclerViewItemClickListener.onLongItemClick(itemView,getLayoutPosition());
                    return false;
                }
            });
        }

    }
}
