package com.shubham.signuppage.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Message message);

    @Update
    void update(Message message);

    @Delete
    void delete(Message message);

    @Query("Delete From message_table ")
    void deleteAllMessages();

    @Query("Delete From message_table WHERE `key`=:messageId ")
    void deleteMessage(String messageId);

    @Query("SELECT * FROM  message_table where threadId=:threadId ORDER BY  timestamp DESC")
    List<Message> getThreadMessage(String threadId);

    @Query("SELECT * FROM  message_table where (workplaceKey=:workKey AND workplace =:work  AND ((sender=:sender AND receiver=:receiver)OR (sender=:receiver AND receiver=:sender) )AND threadId=:threadId) ORDER BY timestamp ASC ")
    LiveData<List<Message>> getAllMessages(String workKey,String work,String sender,String receiver,String threadId);

    @Query("SELECT * FROM  message_table where workplace=:work AND((sender=:sender AND receiver=:receiver)OR (sender=:receiver AND receiver=:sender) ) AND (message_text LIKE '%' || :contains ||'%' ) ORDER BY  timestamp DESC")
    List<Message> getMessages(String work,String sender,String receiver, String contains);

    @Query("SELECT * FROM  message_table where workplace=:work AND((sender=:sender AND receiver=:receiver)OR (sender=:receiver AND receiver=:sender) )  ORDER BY  timestamp DESC")
    List<Message> getMessagess(String work,String sender,String receiver);

    @Query("UPDATE message_table SET likes=:likes WHERE `key`=:askey")
    void updateMessageLikeCount(String askey,int likes);

    @Query("UPDATE message_table SET read=:read WHERE workplace=:work AND ((sender=:sender AND receiver=:receiver ) OR (sender=:receiver AND receiver=:sender))")
    void  updateRead(String work,String sender,String receiver,Boolean read);

    @Query("SELECT COUNT(`key`) FROM  message_table where threadId=:threadId ")
    int getThreadMessageCount(String threadId);
}
