package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "search_message_table")

public class SearchMessage {
    @PrimaryKey
    @NonNull
    private String key;

    private String sender;

    private String receiver;

    private String workplaceKey;

    private String workplaceName;

    private String create_date;

    private String message_text;

    private String likes;

    private String timestamp;

    private String threadId;

    private String filter;



    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public String getWorkplaceKey() {
        return workplaceKey;
    }

    public String getWorkplaceName() {
        return workplaceName;
    }

    public String getCreate_date() {
        return create_date;
    }

    public String getMessage_text() {
        return message_text;
    }

    public String getLikes() {
        return likes;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getThreadId() {
        return threadId;
    }

    public String getFilter() {
        return filter;
    }


    public SearchMessage(@NonNull String key, String sender, String receiver, String workplaceKey, String workplaceName, String create_date, String message_text, String likes, String timestamp, String threadId, String filter) {
        this.key = key;
        this.sender = sender;
        this.receiver = receiver;
        this.workplaceKey = workplaceKey;
        this.workplaceName = workplaceName;
        this.create_date = create_date;
        this.message_text = message_text;
        this.likes = likes;
        this.timestamp = timestamp;
        this.threadId = threadId;
        this.filter = filter;
    }
}
