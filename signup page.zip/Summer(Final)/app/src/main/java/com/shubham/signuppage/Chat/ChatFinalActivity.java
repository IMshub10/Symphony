package com.shubham.signuppage.Chat;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.shubham.signuppage.Groups.GroupsChatActivity;
import com.shubham.signuppage.Groups.RecyclerviewGroupMessage;
import com.shubham.signuppage.Models.Files;
import com.shubham.signuppage.Models.FilesUri;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.MembersViewModel;
import com.shubham.signuppage.Room.Message;
import com.shubham.signuppage.Room.MessageViewModel;
import com.shubham.signuppage.Room.ScheduleViewModel;
import com.shubham.signuppage.Room.SearchMessageViewModel;
import com.shubham.signuppage.Room.Thread;
import com.shubham.signuppage.Room.ThreadsViewModel;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.TableBuilder.Schedule;
import com.shubham.signuppage.TableBuilder.Time;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import Helper.DownloadFiles;
import Helper.MyCalendar;
import Interfaces.ChatFinalActivityListener;
import Interfaces.DownloadChatFiles;
import Interfaces.RecyclerviewSwipeListener;
import LayoutsAndViews.MyRelativeLayout;
import de.hdodenhof.circleimageview.CircleImageView;

public class ChatFinalActivity extends AppCompatActivity {
    private static final String CHANNEL_1_ID = "channel1";
    NotificationManagerCompat notificationManagerCompat;
    Toolbar toolbarFinalChatActivity;
    ImageButton sendMessage;
    ImageView add_images;
    String Friend_Key, Friend_Name;
    private ThreadsViewModel threadsViewModel;
    RecyclerView thread_recyclerview;
    RecyclerView message_recyclerview;
    MessageViewModel messageViewModel;
    SharedPreferences sharedPreferences;
    private MembersViewModel membersViewModel;
    RequestQueue requestQueue;
    String url = "https://fcm.googleapis.com/fcm/send";
    Uri imageFile;
    String sender;
    private SearchMessageViewModel searchMessageViewModel;
    LinearLayoutManager layoutManager;
    //BottomSheet
    private BottomSheetBehavior bottomSheetBehavior;
    private EditText bsEditText;
    private String msg;
    LinearLayout layout;
    private static final int REQUEST_CAPTURE_IMAGE = 100;
    HorizontalScrollView scroll;
    ReceiveThreadTask receiveThreadTask = new ReceiveThreadTask();
    ReceiveMessageTask receiveMessageTask = new ReceiveMessageTask();
    RecyclerviewThread recyclerviewThread;
    private List<Uri> imageFiles, imageFilesy;
    private CardView pdfCardView;
    private ImageView imagePdf;
    private TextView namePdf;
    private CardView pdfCardView1;
    private ImageView imagePdf1;
    private TextView namePdf1;
    private CardView pdfCardView2;
    private ImageView imagePdf2;
    private TextView namePdf2;
    private ImageView pdfCancel, pdfCancel1, pdfCancel2;
    private List<FilesUri> files, filesy;
    String editText;
    private ImageView imageCancel, imageCancel1, imageCancel2;
    private ImageView galleryImage, galleryImage1, galleryImage2;
    RelativeLayout pdf_layout, pdf_layout1, pdf_layout2;
    EditText text_editor_edit;
    HorizontalScrollView scrolly;
    LinearLayout layouty;
    private ImageView imageCancely, imageCancel1y, imageCancel2y;
    private ImageView galleryImagey, galleryImage1y, galleryImage2y;
    private CardView pdfCardViewy;
    private ImageView imagePdfy;
    private TextView namePdfy;
    private CardView pdfCardView1y;
    private ImageView imagePdf1y;
    private TextView namePdf1y;
    private CardView pdfCardView2y;
    private ImageView imagePdf2y;
    private TextView namePdf2y;
    private ImageView pdfCancely, pdfCancel1y, pdfCancel2y;
    RelativeLayout pdf_layouty, pdf_layout1y, pdf_layout2y;
    ImageButton cameray, galleryy, attachy;
    LinearLayout lineary;
    ImageButton cameraxy, galleryxy, attachxy, send_threadxy;

    private static final int PICK_FILE_REQUEST = 4;
    private Parcelable recyclerViewState;
    RelativeLayout content;

    ImageView attach, camera, gallery, bsSendMsg;
    int previousPosition = -1;

    MyRelativeLayout chatMain;

    //Schedule
    BottomSheetBehavior bottomSheetBehaviorSchedule;

    //Copy_Delete
    BottomSheetBehavior bottomSheetBehavior_copy_delete;

    LinearLayout layout_delete, layout_copy;

    private CalendarView schedule_calendar_view;
    private TextView calendar_date;
    private EditText event_edit;
    private TextView start_time, end_time;
    private int day;
    private com.shubham.signuppage.TableBuilder.Schedule schedule;

    private Button add_schedule;

    private ScheduleViewModel scheduleViewModel;


    RecyclerviewMessage delete_copy_recyclerviewMessage;
    int delete_copy_message_position, delete_copy_thread_position;

    public void init() {
        toolbarFinalChatActivity = findViewById(R.id.toolbarFinalChatActivity);
        sendMessage = findViewById(R.id.send_thready);
        add_images = findViewById(R.id.add_images);
        content = findViewById(R.id.content);
        thread_recyclerview = findViewById(R.id.thread_recyclerview);
        camera = findViewById(R.id.camera);
        layoutManager = new LinearLayoutManager(this);
        thread_recyclerview.setLayoutManager(layoutManager);
        layoutManager.setItemPrefetchEnabled(true);
        layoutManager.setStackFromEnd(true);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        //layoutManager.setStackFromEnd(true);
        message_recyclerview = findViewById(R.id.recyclerViewMessage);
        layout = findViewById(R.id.layout);
        gallery = findViewById(R.id.gallery);
        scroll = findViewById(R.id.scroll);
        imageCancel = findViewById(R.id.imageCancel);
        imageCancel1 = findViewById(R.id.imageCancel1);
        imageCancel2 = findViewById(R.id.imageCancel2);
        galleryImage = findViewById(R.id.galleryImage);
        galleryImage1 = findViewById(R.id.galleryImage1);
        galleryImage2 = findViewById(R.id.galleryImage2);
        pdfCancel = findViewById(R.id.pdfCancel);
        pdfCancel1 = findViewById(R.id.pdfCancel1);
        pdfCancel2 = findViewById(R.id.pdfCancel2);
        pdfCardView = findViewById(R.id.pdf_card);
        imagePdf = findViewById(R.id.imagePdf);
        namePdf = findViewById(R.id.namePdf);
        pdfCardView1 = findViewById(R.id.pdf_card1);
        imagePdf1 = findViewById(R.id.imagePdf1);
        namePdf1 = findViewById(R.id.namePdf1);
        pdfCardView2 = findViewById(R.id.pdf_card2);
        imagePdf2 = findViewById(R.id.imagePdf2);
        namePdf2 = findViewById(R.id.namePdf2);
        pdf_layout = findViewById(R.id.pdf_layout);
        pdf_layout1 = findViewById(R.id.pdf_layout1);
        pdf_layout2 = findViewById(R.id.pdf_layout2);
        notificationManagerCompat = NotificationManagerCompat.from(getApplicationContext());
        attach = findViewById(R.id.attach);
        imageFiles = new ArrayList<>();
        files = new ArrayList<>();

        imageFilesy = new ArrayList<>();
        filesy = new ArrayList<>();
        text_editor_edit = findViewById(R.id.text_editor_edit);
        lineary = findViewById(R.id.lineary);
        cameray = findViewById(R.id.cameray);
        galleryy = findViewById(R.id.galleryy);
        attachy = findViewById(R.id.attachy);

        cameraxy = findViewById(R.id.cameraxy);
        galleryxy = findViewById(R.id.galleryxy);
        attachxy = findViewById(R.id.attachxy);
        send_threadxy = findViewById(R.id.send_threadxy);

        scrolly = findViewById(R.id.scrolly);
        layouty = findViewById(R.id.layouty);
        imageCancely = findViewById(R.id.imageCancely);
        imageCancel1y = findViewById(R.id.imageCancel1y);
        imageCancel2y = findViewById(R.id.imageCancel2y);
        galleryImagey = findViewById(R.id.galleryImagey);
        galleryImage1y = findViewById(R.id.galleryImage1y);
        galleryImage2y = findViewById(R.id.galleryImage2y);
        pdfCancely = findViewById(R.id.pdfCancely);
        pdfCancel1y = findViewById(R.id.pdfCancel1y);
        pdfCancel2y = findViewById(R.id.pdfCancel2y);
        pdfCardViewy = findViewById(R.id.pdf_cardy);
        imagePdfy = findViewById(R.id.imagePdfy);
        namePdfy = findViewById(R.id.namePdfy);
        pdfCardView1y = findViewById(R.id.pdf_card1y);
        imagePdf1y = findViewById(R.id.imagePdf1y);
        namePdf1y = findViewById(R.id.namePdf1y);
        pdfCardView2y = findViewById(R.id.pdf_card2y);
        imagePdf2y = findViewById(R.id.imagePdf2y);
        namePdf2y = findViewById(R.id.namePdf2y);
        pdf_layouty = findViewById(R.id.pdf_layouty);
        pdf_layout1y = findViewById(R.id.pdf_layout1y);
        pdf_layout2y = findViewById(R.id.pdf_layout2y);
        chatMain = findViewById(R.id.chat_main);

        //BottomSheetCode
        LinearLayout mBottomSheet = findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(mBottomSheet);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        bsSendMsg = findViewById(R.id.add_thread);
        bsEditText = findViewById(R.id.bs_text);

        //Schedule
        LinearLayout mBottomSheetSchedule = findViewById(R.id.bottom_sheet_schedule);
        bottomSheetBehaviorSchedule = BottomSheetBehavior.from(mBottomSheetSchedule);
        bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_HIDDEN);
        start_time = findViewById(R.id.start_time);
        end_time = findViewById(R.id.end_time);
        schedule_calendar_view = findViewById(R.id.schedule_calendar_view);
        calendar_date = findViewById(R.id.calendar_date);
        event_edit = findViewById(R.id.event_edit);
        add_schedule = findViewById(R.id.add_schedule);

        //Bottom Sheet Copy Delete;
        LinearLayout bottomSheetCopyDelete = findViewById(R.id.bottom_sheet_delete_copy);
        bottomSheetBehavior_copy_delete = BottomSheetBehavior.from(bottomSheetCopyDelete);
        bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_HIDDEN);
        layout_copy = findViewById(R.id.layout_copy);
        layout_delete = findViewById(R.id.layout_delete);
        initInputField();

        scheduleViewModel = ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication()).create(ScheduleViewModel.class);
        day = Calendar.getInstance().get(Calendar.YEAR) * 10000 + (Calendar.getInstance().get(Calendar.MONTH) + 1) * 100 + Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
        SetDate(Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.YEAR));
        ScheduleListeners();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            setTheme(R.style.ChatFinalActivity_Dark);
        else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_chat_final);

        init();
        //bottom_tab = findViewById(R.id.bottom_tab);
        //Edit Text
        text_editor_edit.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                cameray.setVisibility(View.GONE);
                galleryy.setVisibility(View.GONE);
                attachy.setVisibility(View.GONE);
                content.setVisibility(View.VISIBLE);
                lineary.setVisibility(View.GONE);
                sendMessage.setVisibility(View.GONE);
            } else {
                cameray.setVisibility(View.VISIBLE);
                galleryy.setVisibility(View.VISIBLE);
                attachy.setVisibility(View.VISIBLE);
                sendMessage.setVisibility(View.VISIBLE);
                lineary.setVisibility(View.VISIBLE);
                content.setVisibility(View.GONE);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(text_editor_edit.getWindowToken(), 0);
            }
        });

        setSupportActionBar(toolbarFinalChatActivity);
        try {
            Objects.requireNonNull(getSupportActionBar()).setTitle(null);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Intent intent = getIntent();
        Friend_Key = intent.getStringExtra("Friend_key");
        Friend_Name = intent.getStringExtra("name");
        recyclerviewThread = new RecyclerviewThread(this, Friend_Key, Friend_Name, text_editor_edit);
        thread_recyclerview.setAdapter(recyclerviewThread);


        ((SimpleItemAnimator) thread_recyclerview.getItemAnimator()).setSupportsChangeAnimations(false);
        thread_recyclerview.setNestedScrollingEnabled(false);

        View toolView = toolbarFinalChatActivity.getRootView();
        CircleImageView groups_prof_image = toolView.findViewById(R.id.groups_prof_image);
        Glide.with(groups_prof_image.getContext())
                .asBitmap()
                .error(R.drawable.dp)
                .load(intent.getStringExtra("ImageUrl"))
                .into(groups_prof_image);
        TextView groups_prof_text = toolView.findViewById(R.id.groups_prof_text);
        groups_prof_text.setText(intent.getStringExtra("name"));

        ImageView groups_toolbar_navigation = toolView.findViewById(R.id.groups_toolbar_navigation);
        membersViewModel = ViewModelProviders.of(this).get(MembersViewModel.class);
        membersViewModel.updateMemberMess(intent.getStringExtra("MemberKey"), 0);
        messageViewModel = ViewModelProviders.of(this).get(MessageViewModel.class);
        searchMessageViewModel = ViewModelProviders.of(this).get(SearchMessageViewModel.class);
        threadsViewModel = ViewModelProviders.of(this).get(ThreadsViewModel.class);


        bottomSheetBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(bsEditText.getWindowToken(), 0);
                    bsEditText.clearFocus();
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });
        bottomSheetBehaviorSchedule.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(event_edit.getWindowToken(), 0);
                    event_edit.clearFocus();
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });
        threadsViewModel.getAllThreads(LocalUserService.getLocalUserFromPreferences(this).CurrentWorkplaceKey, LocalUserService.getLocalUserFromPreferences(this).CurrentWorkplaceName, intent.getStringExtra("name"),
                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname)
                .observe(this, threads -> {
                    recyclerviewThread.submitList(threads);
                });

        FirebaseMessaging.getInstance().subscribeToTopic(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key + Friend_Key);
        requestQueue = Volley.newRequestQueue(this);
        sharedPreferences = getSharedPreferences("Selectedthread", 0);
        sharedPreferences.edit().putString("SelectedthreadKey" + intent.getStringExtra("name"), null).apply();

        text_editor_edit.setVisibility(View.INVISIBLE);
        galleryy.setVisibility(View.INVISIBLE);
        cameray.setVisibility(View.INVISIBLE);
        attachy.setVisibility(View.INVISIBLE);
        //New Thread Message Create
        //BotoomSheetAddThread

        bsSendMsg.setOnClickListener(v -> {
            msg = bsEditText.getText().toString();
            if (msg.trim().length() > 0) {
                try {
                    SendMessageTaskNew sendMessageTask = new SendMessageTaskNew(imageFiles, files, msg);
                    sendMessageTask.execute();
                    imageFiles = new ArrayList<>();
                    files = new ArrayList<>();
                    //SendMessageTask sendMessageTask = new SendMessageTask();
                    //sendMessageTask.execute(editText);
                    bsEditText.setText("");
                    scroll.setVisibility(View.GONE);
                    layout.setVisibility(View.GONE);
                    galleryImage.setImageBitmap(null);
                    galleryImage.setVisibility(View.GONE);
                    imageCancel.setVisibility(View.GONE);
                    galleryImage1.setImageBitmap(null);
                    galleryImage1.setVisibility(View.GONE);
                    imageCancel1.setVisibility(View.GONE);
                    galleryImage2.setImageBitmap(null);
                    galleryImage2.setVisibility(View.GONE);
                    imageCancel2.setVisibility(View.GONE);
                    pdfCardView.setVisibility(View.GONE);
                    imagePdf.setVisibility(View.GONE);
                    imagePdf.setImageBitmap(null);
                    namePdf.setVisibility(View.GONE);
                    pdfCancel.setVisibility(View.GONE);
                    pdf_layout.setVisibility(View.GONE);
                    pdfCardView1.setVisibility(View.GONE);
                    imagePdf1.setVisibility(View.GONE);
                    imagePdf1.setImageBitmap(null);
                    namePdf1.setVisibility(View.GONE);
                    pdfCancel1.setVisibility(View.GONE);
                    pdf_layout1.setVisibility(View.GONE);
                    pdfCardView2.setVisibility(View.GONE);
                    imagePdf2.setVisibility(View.GONE);
                    imagePdf2.setImageBitmap(null);
                    namePdf2.setVisibility(View.GONE);
                    pdfCancel2.setVisibility(View.GONE);
                    pdf_layout2.setVisibility(View.GONE);
                    bsEditText.clearFocus();
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(bsEditText.getWindowToken(), 0);
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                        }
                    }, 600);
                } catch (Exception e) {
                    Log.e("exception", e.toString());
                }

            } else {
                Toast.makeText(getApplicationContext(), "Field cannot be blank.", Toast.LENGTH_LONG).show();
            }
        });
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageFiles.size() < 3) {
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 1);
                    } else {
                        getPhoto();
                    }
                } else {
                    Toast.makeText(ChatFinalActivity.this, "A maximum of 3 images and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        attach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (files.size() < 3) {
                    if (ContextCompat.checkSelfPermission(ChatFinalActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 4);
                    } else {
                        getFile();
                    }
                } else {
                    Toast.makeText(ChatFinalActivity.this, "A maximum of 3 images and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        text_editor_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                editText = text_editor_edit.getText().toString().trim();
                if (editText.length() > 0) {
                    sendMessage.setBackgroundResource(R.drawable.ic_arrow_up_circle);
                } else {
                    sendMessage.setBackgroundResource(R.drawable.ic_edit);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        sendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText = text_editor_edit.getText().toString().trim();
                if (editText.trim().length() > 0) {
                    if (sharedPreferences.getString("SelectedthreadKey" + Friend_Key, null) != null) {
                        try {
                            new ReadThreadMessagesTask(messageViewModel, sharedPreferences.getString("SelectedthreadKey" + Friend_Key, null), editText).execute();
                        } catch (Exception e) {
                            Log.e("Error", e.toString());
                        }
                    } else {
                        Toast.makeText(ChatFinalActivity.this, "Please select a thread.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Toast.makeText(ChatFinalActivity.this, "Enter some Message", Toast.LENGTH_SHORT).show();
                    if (bottomSheetBehaviorSchedule.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                        bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_HIDDEN);
                    }
                    if (bottomSheetBehavior_copy_delete.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                        bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_HIDDEN);
                    }
                    bsEditText.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(bsEditText, InputMethodManager.RESULT_SHOWN);
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                    }, 600);
                }
            }
        });
        send_threadxy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText = text_editor_edit.getText().toString().trim();
                if (editText.trim().length() > 0) {
                    if (sharedPreferences.getString("SelectedthreadKey" + Friend_Key, null) != null) {
                        try {
                            new ReadThreadMessagesTask(messageViewModel, sharedPreferences.getString("SelectedthreadKey" + Friend_Key, null), editText).execute();
                        } catch (Exception e) {
                            Log.e("Error", e.toString());
                        }
                    } else {
                        Toast.makeText(ChatFinalActivity.this, "Please select a thread.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ChatFinalActivity.this, "Field cannot be blank.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        galleryy.setOnClickListener(v -> {
            if (imageFilesy.size() < 3) {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 11);
                } else {
                    getPhotoy();
                }
            } else {
                Toast.makeText(ChatFinalActivity.this, "A maximum of 3 images and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
            }
//
        });
        galleryxy.setOnClickListener(v -> {
            if (imageFilesy.size() < 3) {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 11);
                } else {
                    getPhotoy();
                }
            } else {
                Toast.makeText(ChatFinalActivity.this, "A maximum of 3 images and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
            }
//
        });
        cameray.setOnClickListener(v -> {
        });
        attachy.setOnClickListener(v -> {
            if (filesy.size() < 3) {
                if (ContextCompat.checkSelfPermission(ChatFinalActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 41);
                } else {
                    getFiley();
                }
            } else {
                Toast.makeText(ChatFinalActivity.this, "A maximum of 3 images and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
            }
        });
        attachxy.setOnClickListener(v -> {
            if (filesy.size() < 3) {
                if (ContextCompat.checkSelfPermission(ChatFinalActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 41);
                } else {
                    getFiley();
                }
            } else {
                Toast.makeText(ChatFinalActivity.this, "A maximum of 3 images and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
            }
        });

        sharedPreferences.edit().putString("SelectedthreadKey" + Friend_Key, null).apply();
        recyclerviewThread.setOnItemClickListener(new ChatFinalActivityListener() {
            @Override
            public void onItemClick(View view, int position) {
            }

            @Override
            public void onLongItemClick(RecyclerviewMessage recyclerviewMessage, View view, int thread_position, int message_position) {

                delete_copy_recyclerviewMessage = recyclerviewMessage;
                delete_copy_message_position = message_position;
                delete_copy_thread_position = thread_position;
                if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_HIDDEN) {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                    bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else if (event_edit.hasFocus()) {
                    event_edit.clearFocus();
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(event_edit.getWindowToken(), 0);
                    event_edit.clearFocus();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                    }, 600);
                } else if (bottomSheetBehaviorSchedule.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_HIDDEN);
                    bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else if (text_editor_edit.hasFocus()) {
                    text_editor_edit.clearFocus();
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(text_editor_edit.getWindowToken(), 0);
                    text_editor_edit.clearFocus();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                    }, 600);
                } else {
                    bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_EXPANDED);

                }
            }


            @Override
            public void onSwipeRight(RecyclerView recyclerView, View view, int layoutPosition, int swipePosition) {
                if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_HIDDEN) {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                if (bottomSheetBehaviorSchedule.getState() != BottomSheetBehavior.STATE_HIDDEN) {
                    bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                if (bottomSheetBehavior_copy_delete.getState() != BottomSheetBehavior.STATE_HIDDEN) {
                    bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                text_editor_edit.setVisibility(View.VISIBLE);
                galleryy.setVisibility(View.VISIBLE);
                cameray.setVisibility(View.VISIBLE);
                attachy.setVisibility(View.VISIBLE);
                lineary.setVisibility(View.INVISIBLE);
                text_editor_edit.requestFocus();
                sharedPreferences.edit().putString("SelectedthreadKey" + Friend_Key, recyclerviewThread.getItem(layoutPosition).getKey()).apply();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(text_editor_edit, InputMethodManager.SHOW_IMPLICIT);
                if (layoutPosition != previousPosition) {
                    RecyclerView.ViewHolder recyclerViewViewHolderForItemIdOther = thread_recyclerview.findViewHolderForAdapterPosition(layoutPosition);
                    LinearLayout threadLayout2 = null;
                    if (recyclerViewViewHolderForItemIdOther != null) {
                        threadLayout2 = recyclerViewViewHolderForItemIdOther.itemView.findViewById(R.id.threadLayout);
                    }
                    if (threadLayout2 != null) {
                        threadLayout2.setBackgroundColor(0xCCB8E0F6);
                    }
                    if (previousPosition != -1) {
                        RecyclerView.ViewHolder recyclerViewViewHolderForItemIdOther1 = thread_recyclerview.findViewHolderForAdapterPosition(previousPosition);
                        LinearLayout threadLayout21 = null;
                        if (recyclerViewViewHolderForItemIdOther1 != null) {
                            threadLayout21 = recyclerViewViewHolderForItemIdOther1.itemView.findViewById(R.id.threadLayout);
                        }
                        if (threadLayout21 != null) {
                            threadLayout21.setBackgroundColor(0xf2f2f5);
                        }
                    }
                    previousPosition = layoutPosition;
                }
            }
            @Override
            public void onSwipeLeft(RecyclerView recyclerView, View view, int layoutPosition, int swipePosition) {
                if (bottomSheetBehavior_copy_delete.getState() != BottomSheetBehavior.STATE_HIDDEN) {
                    bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_HIDDEN);
                }
                SetStartTime_EndTime();
                schedule = new Schedule();
                schedule.setStartTime(new Time(Calendar.getInstance().get(Calendar.HOUR_OF_DAY), Calendar.getInstance().get(Calendar.MINUTE)));
                if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 23) {
                    schedule.setEndTime(new Time(Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + 1, Calendar.getInstance().get(Calendar.MINUTE)));
                } else {
                    schedule.setEndTime(new Time(Calendar.getInstance().get(Calendar.HOUR_OF_DAY), Calendar.getInstance().get(Calendar.MINUTE)));
                }
                if (text_editor_edit.hasFocus()) {
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(text_editor_edit.getWindowToken(), 0);
                    text_editor_edit.clearFocus();
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                    }, 600);
                }else if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_HIDDEN) {
                    bsEditText.clearFocus();
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(bsEditText.getWindowToken(), 0);

                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                    }, 600);
                }  else {
                    bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });
        layout_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getSender().trim().equals(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Fullname.trim())) {
                        if (LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).ThemeId) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(ChatFinalActivity.this, android.R.style.Theme_Material_Dialog_Alert);
                            builder.setTitle("Delete Message");

                            builder.setMessage("Are You Sure you want to delete this message");
                            builder.setNegativeButton("NO",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {

                                        }
                                    });
                            builder.setPositiveButton("Yes",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            messageViewModel.deleteMessage(delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getKey());
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Key)
                                                    .child(delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getKey()).removeValue();
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceKey)
                                                    .child("OwnMessages").child(Friend_Key)
                                                    .child(delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getKey()).removeValue();
                                            new DeleteThread(messageViewModel, recyclerviewThread.getItem(delete_copy_thread_position).getKey(), recyclerviewThread.getItem(delete_copy_thread_position).getSender()).execute();
                                        }
                                    });
                            builder.show();
                        } else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(ChatFinalActivity.this);
                            builder.setTitle("Delete Message");

                            builder.setMessage("Are You Sure you want to delete this message");
                            builder.setNegativeButton("NO",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {

                                        }
                                    });
                            builder.setPositiveButton("Yes",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            messageViewModel.deleteMessage(delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getKey());
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Key)
                                                    .child(delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getKey()).removeValue();
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceKey)
                                                    .child("OwnMessages").child(Friend_Key)
                                                    .child(delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getKey()).removeValue();
                                            new DeleteThread(messageViewModel, recyclerviewThread.getItem(delete_copy_thread_position).getKey(), recyclerviewThread.getItem(delete_copy_thread_position).getSender()).execute();
                                        }
                                    });
                            builder.show();
                        }
                    } else {
                        Toast.makeText(ChatFinalActivity.this, "You cannot Delete this message", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_HIDDEN);
            }
        });
        layout_copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Copy", delete_copy_recyclerviewMessage.getItem(delete_copy_message_position).getMessage_text());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(ChatFinalActivity.this, "Message Copied to ClipBoard", Toast.LENGTH_SHORT).show();
                bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_HIDDEN);
            }
        });
        groups_toolbar_navigation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        HandlerThread handlerThread = new HandlerThread("QAClient");
        handlerThread.start();

        //Listener for file Download
        Download();
        receiveThreadTask.execute();
        receiveMessageTask.execute();
        new ReceiveOwnMessageTask().execute();
    }


    public void Download() {
        recyclerviewThread.addFileDownloadListener(new DownloadChatFiles() {
            @Override
            public void onItemClick(Message message, int item_position, int file_position) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{(Manifest.permission.WRITE_EXTERNAL_STORAGE)}, 100);
                } else {
                    new DownloadFiles(ChatFinalActivity.this).
                            DownloadChatFile(message.getFilesUrl().get(file_position).getUrl(),
                                    message.getFilesUrl().get(file_position).getName(),
                                    message.getFilesUrl().get(file_position).getType());
                }

            }
        });
    }

    private class DeleteThread extends AsyncTask<Void, Void, Integer> {

        MessageViewModel messageViewModel;
        String currentThread;
        String creator;

        public DeleteThread(MessageViewModel messageViewModel, String currentThread, String creator) {
            this.messageViewModel = messageViewModel;
            this.currentThread = currentThread;
            this.creator = creator;
        }

        @Override
        protected Integer doInBackground(Void... voids) {
            return messageViewModel.getThreadMessageCount(currentThread);
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if (integer == 0) {
                threadsViewModel.deleteThread(currentThread);
                if (creator.equals(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Fullname)) {
                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceKey)
                            .child("Threads").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Key)
                            .child(currentThread).removeValue();
                } else {
                    try {
                        FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).Key)
                                .child("Mails").child(LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceKey)
                                .child("Threads").child(Friend_Key)
                                .child(currentThread).removeValue();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    public void getFile() {
        String[] mimetypes = {"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/pdf", "text/plain", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"};
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimetypes);
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        recyclerViewState = thread_recyclerview.getLayoutManager().onSaveInstanceState();
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        thread_recyclerview.getLayoutManager().onRestoreInstanceState(recyclerViewState);
    }

    public void getFiley() {
        String[] mimetypes = {"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/pdf", "text/plain", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"};
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimetypes);
        startActivityForResult(intent, 41);

    }

    public void getVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 3);
    }

    public void getPhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 2);
    }

    public void getPhotoy() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 21);
    }

    private float getNavigationBarHeight() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float usableHeight = metrics.heightPixels;
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        float realHeight = metrics.heightPixels;
        if (realHeight > usableHeight)
            return realHeight - usableHeight;
        else
            return 0;
    }

    private void openCameraIntent() {
        Intent pictureIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE
        );
        if (pictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(pictureIntent,
                    REQUEST_CAPTURE_IMAGE);
        }
    }

    public void sendNotification(String sender, String message) {
        //JSON DATA
        JSONObject mainObject = new JSONObject();
        try {
            mainObject.put("to", "/topics/" + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey + Friend_Key + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key);
            JSONObject notificationObject = new JSONObject();
            notificationObject.put("title", sender);
            notificationObject.put("body", message);
            notificationObject.put("sound", "default");
            notificationObject.put("click_action", "OPEN_ACTIVITY_1");
            mainObject.put("notification", notificationObject);
            JSONObject optionsObject = new JSONObject();
            optionsObject.put("collapse_key", "mails");
            optionsObject.put("priority", "high");
            Log.e("Go", "try");
            mainObject.put("android", optionsObject);

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, mainObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "key=AAAA-_Cat5Y:APA91bGEcfdD8kpodmKYJUDp41iDtZJHJMGfMJJKeLSMWUfnc_B9sFSIueBE3GCl8MLoBH4pqaVarDhZH1OdxRMoZcCWc2SEFbnzfm6T3jlrKM4AzjJ2eM8SVkBSaVe0GJuL-sUTRoLX");
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            requestQueue.add(request);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("Go", String.valueOf(e));
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{(Manifest.permission.WRITE_EXTERNAL_STORAGE)}, 100);
        }
        Intent intent = getIntent();
        sender = intent.getStringExtra("name");
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        receiveThreadTask.cancel(true);
        receiveMessageTask.cancel(true);
        new color().execute();
    }

    public class color extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            messageViewModel.updateRead(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                    Friend_Name, LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                    true);
            return null;
        }
    }

    public static class GetThreadPositionTask extends AsyncTask<Void, Void, Integer> {

        private String threadId;
        private ThreadsViewModel threadsViewModel;
        int cThread;
        RecyclerView thread_recyclerview;

        public GetThreadPositionTask(String threadId, ThreadsViewModel threadsViewModel, RecyclerView thread_recyclerview) {
            this.threadId = threadId;
            this.threadsViewModel = threadsViewModel;
            this.thread_recyclerview = thread_recyclerview;
        }

        @Override
        protected Integer doInBackground(Void... voids) {
            cThread = threadsViewModel.getThread(threadId);
            Log.e("Position", String.valueOf(cThread));
            return cThread;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            final Handler handler = new Handler();

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //Do something after 300ms
                    thread_recyclerview.smoothScrollToPosition(cThread);
                    //layoutManager.scrollToPositionWithOffset(cThread,0);

                }
            }, 600);

        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getPhoto();
            }
        } else if (requestCode == 2) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getVideo();
            }
        } else if (requestCode == 3) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCameraIntent();
            }
        } else if (requestCode == 4) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getFile();
            }
        } else if (requestCode == 11) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getPhotoy();
            }
        } else if (requestCode == 41) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getFiley();
            }
            //TODO: Check this permission
        } else if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.getMenuInflater().inflate(R.menu.chat_final_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.search_thread:
                thread_recyclerview.scrollToPosition(0);
                thread_recyclerview.smoothScrollToPosition(recyclerviewThread.getItemCount() - 1);
                searchMessageViewModel.deleteall();
                Intent intent = new Intent(this, SearchActivity.class);
                intent.putExtra("Sender", sender);
                intent.putExtra("Activity", "Mails");
                startActivityForResult(intent, 1);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                try {
                    String threadId = "";
                    if (data.getStringExtra("MessageKey") != null) {
                        threadId = data.getStringExtra("MessageKey");
                    }
                    new GetThreadPositionTask(threadId, threadsViewModel, thread_recyclerview).execute();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (requestCode == 2 && resultCode == Activity.RESULT_OK && data != null) {
            try {
                imageFile = data.getData();
                scroll.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageFile);
                //rofImageView.setImageBitmap(bitmap);

                if (galleryImage.getVisibility() == View.GONE) {
                    Uri uri = data.getData();
                    imageFiles.add(data.getData());
                    galleryImage.setVisibility(View.VISIBLE);
                    imageCancel.setVisibility(View.VISIBLE);
                    galleryImage.setImageBitmap(getResizedBitmap(bitmap, 250));
                    imageCancel.setOnClickListener(v -> {
                        galleryImage.setImageBitmap(null);
                        galleryImage.setVisibility(View.GONE);
                        imageCancel.setVisibility(View.GONE);
                        imageFiles.remove(uri);
                    });
                } else if (galleryImage1.getVisibility() == View.GONE) {
                    imageFiles.add(data.getData());
                    Uri uri = data.getData();
                    galleryImage1.setVisibility(View.VISIBLE);
                    imageCancel1.setVisibility(View.VISIBLE);
                    galleryImage1.setImageBitmap(getResizedBitmap(bitmap, 250));
                    imageCancel1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            galleryImage1.setImageBitmap(null);
                            galleryImage1.setVisibility(View.GONE);
                            imageCancel1.setVisibility(View.GONE);
                            imageFiles.remove(uri);
                        }
                    });
                } else if (galleryImage2.getVisibility() == View.GONE) {
                    Uri uri = data.getData();
                    imageFiles.add(data.getData());
                    galleryImage2.setVisibility(View.VISIBLE);
                    imageCancel2.setVisibility(View.VISIBLE);
                    galleryImage2.setImageBitmap(getResizedBitmap(bitmap, 250));
                    imageCancel2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            galleryImage2.setImageBitmap(null);
                            galleryImage2.setVisibility(View.GONE);
                            imageCancel2.setVisibility(View.GONE);
                            imageFiles.remove(uri);
                        }
                    });
                }

                //ImageView imageView = new ImageView(this.getContext());
                //imageView.setId(View.generateViewId());

                //imageView.setImageBitmap(getResizedBitmap(bitmap, 250));
                //this.addViewX(imageView, 400, 400);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (requestCode == PICK_FILE_REQUEST && resultCode == Activity.RESULT_OK && data.getData() != null) {
            if (files.size() <= 2) {
                scroll.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                if (imagePdf.getVisibility() == View.GONE) {
                    pdfCardView.setVisibility(View.VISIBLE);
                    pdf_layout.setVisibility(View.VISIBLE);
                    namePdf.setVisibility(View.VISIBLE);
                    imagePdf.setVisibility(View.VISIBLE);
                    pdfCancel.setVisibility(View.VISIBLE);
                    try {
                        String path = new File(data.getData().getPath()).getAbsolutePath();
                        Uri uri = data.getData();
                        String filename;
                        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                        String mime = getContentResolver().getType(uri);
                        if (mime != null) {
                            switch (mime) {
                                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_docx_file_format);
                                    imagePdf.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/pdf": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_pdf_file_format_symbol);
                                    imagePdf.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "text/plain": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                                    imagePdf.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_xls_file_format_symbol);
                                    imagePdf.setImageDrawable(myDrawable);
                                    break;
                                }
                                default: {
                                    Drawable myDrawable = getDrawable(R.drawable.file);
                                    imagePdf.setImageDrawable(myDrawable);
                                    break;
                                }
                            }
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();
                            namePdf.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            files.add(filesUri);

                            imagePdf.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            });
                            pdfCancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // layout1.removeView(v);
                                    pdfCardView.setVisibility(View.GONE);
                                    pdf_layout.setVisibility(View.GONE);
                                    namePdf.setVisibility(View.GONE);
                                    imagePdf.setVisibility(View.GONE);
                                    imagePdf.setImageBitmap(null);
                                    files.remove(filesUri);
                                }
                            });

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (imagePdf1.getVisibility() == View.GONE) {
                    pdfCardView1.setVisibility(View.VISIBLE);
                    pdf_layout1.setVisibility(View.VISIBLE);
                    namePdf1.setVisibility(View.VISIBLE);
                    imagePdf1.setVisibility(View.VISIBLE);
                    pdfCancel1.setVisibility(View.VISIBLE);
                    try {
                        String path = new File(data.getData().getPath()).getAbsolutePath();
                        Uri uri = data.getData();
                        String filename;
                        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                        String mime = getContentResolver().getType(uri);
                        if (mime.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
                            Drawable myDrawable = getDrawable(R.drawable.ic_docx_file_format);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else if (mime.equals("application/pdf")) {
                            Drawable myDrawable = getDrawable(R.drawable.ic_pdf_file_format_symbol);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else if (mime.equals("text/plain")) {
                            Drawable myDrawable = getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else if (mime.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                            Drawable myDrawable = getDrawable(R.drawable.ic_xls_file_format_symbol);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else {
                            Drawable myDrawable = getDrawable(R.drawable.file);
                            imagePdf1.setImageDrawable(myDrawable);
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();
                            namePdf1.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            files.add(filesUri);
                            pdfCancel1.setOnClickListener(v -> {
                                //Toast.makeText(getContext(), "card", Toast.LENGTH_SHORT).show();
                                // layout1.removeView(v);
                                pdfCardView1.setVisibility(View.GONE);
                                pdf_layout1.setVisibility(View.GONE);
                                namePdf1.setVisibility(View.GONE);
                                imagePdf1.setVisibility(View.GONE);
                                imagePdf1.setImageBitmap(null);
                                files.remove(filesUri);
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (imagePdf2.getVisibility() == View.GONE) {
                    pdfCardView2.setVisibility(View.VISIBLE);
                    pdf_layout2.setVisibility(View.VISIBLE);
                    namePdf2.setVisibility(View.VISIBLE);
                    imagePdf2.setVisibility(View.VISIBLE);
                    pdfCancel2.setVisibility(View.VISIBLE);
                    try {

                        if (data.getData().getPath() != null) {
                            String path = new File(data.getData().getPath()).getAbsolutePath();
                        }
                        Uri uri = data.getData();

                        String filename;
                        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                        String mime = getContentResolver().getType(uri);
                        if (mime != null) {


                            switch (mime) {
                                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_docx_file_format);
                                    imagePdf2.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/pdf": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_pdf_file_format_symbol);
                                    imagePdf2.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "text/plain": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                                    imagePdf2.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_xls_file_format_symbol);
                                    imagePdf2.setImageDrawable(myDrawable);
                                    break;
                                }
                                default: {
                                    Drawable myDrawable = getDrawable(R.drawable.file);
                                    imagePdf2.setImageDrawable(myDrawable);
                                    break;
                                }
                            }
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();

                            namePdf2.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            files.add(filesUri);
                            pdfCancel2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Toast.makeText(getContext(), "card", Toast.LENGTH_SHORT).show();
                                    // layout1.removeView(v);
                                    pdfCardView2.setVisibility(View.GONE);
                                    pdf_layout2.setVisibility(View.GONE);
                                    namePdf2.setVisibility(View.GONE);
                                    imagePdf2.setVisibility(View.GONE);
                                    imagePdf2.setImageBitmap(null);
                                    files.remove(filesUri);
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }
        } else if (requestCode == 21 && resultCode == Activity.RESULT_OK && data != null) {

            imageFile = data.getData();
            scrolly.setVisibility(View.VISIBLE);
            layouty.setVisibility(View.VISIBLE);
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageFile);
            } catch (IOException e) {
                Log.e("Error", e.toString());
            }
            //rofImageView.setImageBitmap(bitmap);
            if (galleryImagey.getVisibility() == View.GONE) {
                Uri uri = data.getData();
                imageFilesy.add(data.getData());
                galleryImagey.setVisibility(View.VISIBLE);
                imageCancely.setVisibility(View.VISIBLE);
                galleryImagey.setImageBitmap(getResizedBitmap(bitmap, 250));
                imageCancely.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        galleryImagey.setImageBitmap(null);
                        galleryImagey.setVisibility(View.GONE);
                        imageCancely.setVisibility(View.GONE);
                        imageFilesy.remove(uri);
                        if (imageFilesy.size() == 0 && filesy.size() == 0) {
                            scrolly.setVisibility(View.GONE);
                            layouty.setVisibility(View.GONE);
                        }
                    }
                });
            } else if (galleryImage1y.getVisibility() == View.GONE) {
                imageFilesy.add(data.getData());
                Uri uri = data.getData();
                galleryImage1y.setVisibility(View.VISIBLE);
                imageCancel1y.setVisibility(View.VISIBLE);
                if (bitmap != null) {
                    galleryImage1y.setImageBitmap(getResizedBitmap(bitmap, 250));
                }
                imageCancel1y.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        galleryImage1y.setImageBitmap(null);
                        galleryImage1y.setVisibility(View.GONE);
                        imageCancel1y.setVisibility(View.GONE);
                        imageFilesy.remove(uri);
                        if (imageFilesy.size() == 0 && filesy.size() == 0) {
                            scrolly.setVisibility(View.GONE);
                            layouty.setVisibility(View.GONE);
                        }
                    }
                });
            } else if (galleryImage2y.getVisibility() == View.GONE) {
                Uri uri = data.getData();
                imageFilesy.add(data.getData());
                galleryImage2y.setVisibility(View.VISIBLE);
                imageCancel2y.setVisibility(View.VISIBLE);
                galleryImage2y.setImageBitmap(getResizedBitmap(bitmap, 250));
                imageCancel2y.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        galleryImage2y.setImageBitmap(null);
                        galleryImage2y.setVisibility(View.GONE);
                        imageCancel2y.setVisibility(View.GONE);
                        imageFilesy.remove(uri);
                        if (imageFilesy.size() == 0 && filesy.size() == 0) {
                            scrolly.setVisibility(View.GONE);
                            layouty.setVisibility(View.GONE);
                        }
                    }
                });
            }
        } else if (requestCode == 41 && resultCode == Activity.RESULT_OK && data.getData() != null) {
            if (files.size() <= 2) {
                scrolly.setVisibility(View.VISIBLE);
                layouty.setVisibility(View.VISIBLE);
                if (imagePdfy.getVisibility() == View.GONE) {
                    pdfCardViewy.setVisibility(View.VISIBLE);
                    pdf_layouty.setVisibility(View.VISIBLE);
                    namePdfy.setVisibility(View.VISIBLE);
                    imagePdfy.setVisibility(View.VISIBLE);
                    pdfCancely.setVisibility(View.VISIBLE);
                    try {
                        String path = new File(data.getData().getPath()).getAbsolutePath();
                        Uri uri = data.getData();
                        String filename;
                        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                        String mime = getContentResolver().getType(uri);
                        if (mime != null) {
                            switch (mime) {
                                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_docx_file_format);
                                    imagePdfy.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/pdf": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_pdf_file_format_symbol);
                                    imagePdfy.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "text/plain": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                                    imagePdfy.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_xls_file_format_symbol);
                                    imagePdfy.setImageDrawable(myDrawable);
                                    break;
                                }
                                default: {
                                    Drawable myDrawable = getDrawable(R.drawable.file);
                                    imagePdfy.setImageDrawable(myDrawable);
                                    break;
                                }
                            }
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();
                            namePdfy.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            filesy.add(filesUri);

                            pdfCancely.setOnClickListener(v -> {
                                // layout1.removeView(v);
                                pdfCardViewy.setVisibility(View.GONE);
                                pdf_layouty.setVisibility(View.GONE);
                                namePdfy.setVisibility(View.GONE);
                                imagePdfy.setVisibility(View.GONE);
                                imagePdfy.setImageBitmap(null);
                                filesy.remove(filesUri);
                                if (imageFilesy.size() == 0 && filesy.size() == 0) {
                                    scrolly.setVisibility(View.GONE);
                                    layouty.setVisibility(View.GONE);
                                }
                            });

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (imagePdf1y.getVisibility() == View.GONE) {
                    pdfCardView1y.setVisibility(View.VISIBLE);
                    pdf_layout1y.setVisibility(View.VISIBLE);
                    namePdf1y.setVisibility(View.VISIBLE);
                    imagePdf1y.setVisibility(View.VISIBLE);
                    pdfCancel1y.setVisibility(View.VISIBLE);
                    try {
                        if (data.getData().getPath() != null) {
                            String path = new File(data.getData().getPath()).getAbsolutePath();
                        }
                        Uri uri = data.getData();
                        String filename;
                        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                        String mime = getContentResolver().getType(uri);
                        if (mime != null) {
                            switch (mime) {
                                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_docx_file_format);
                                    imagePdf1y.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/pdf": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_pdf_file_format_symbol);
                                    imagePdf1y.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "text/plain": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                                    imagePdf1y.setImageDrawable(myDrawable);
                                    break;
                                }
                                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                                    Drawable myDrawable = getDrawable(R.drawable.ic_xls_file_format_symbol);
                                    imagePdf1y.setImageDrawable(myDrawable);
                                    break;
                                }
                                default: {
                                    Drawable myDrawable = getDrawable(R.drawable.file);
                                    imagePdf1y.setImageDrawable(myDrawable);
                                    break;
                                }
                            }
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();
                            namePdf1y.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            filesy.add(filesUri);
                            pdfCancel1y.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // layout1.removeView(v);
                                    pdfCardView1y.setVisibility(View.GONE);
                                    pdf_layout1y.setVisibility(View.GONE);
                                    namePdf1y.setVisibility(View.GONE);
                                    imagePdf1y.setVisibility(View.GONE);
                                    imagePdf1y.setImageBitmap(null);
                                    filesy.remove(filesUri);
                                    if (imageFilesy.size() == 0 && filesy.size() == 0) {
                                        scrolly.setVisibility(View.GONE);
                                        layouty.setVisibility(View.GONE);
                                    }
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (imagePdf2y.getVisibility() == View.GONE) {
                    pdfCardView2y.setVisibility(View.VISIBLE);
                    pdf_layout2y.setVisibility(View.VISIBLE);
                    namePdf2y.setVisibility(View.VISIBLE);
                    imagePdf2y.setVisibility(View.VISIBLE);
                    pdfCancel2y.setVisibility(View.VISIBLE);
                    try {

                        String path = new File(data.getData().getPath()).getAbsolutePath();

                        Uri uri = data.getData();

                        String filename;
                        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                        String mime = getContentResolver().getType(uri);
                        switch (mime) {
                            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                                Drawable myDrawable = getDrawable(R.drawable.ic_docx_file_format);
                                imagePdf2y.setImageDrawable(myDrawable);
                                break;
                            }
                            case "application/pdf": {
                                Drawable myDrawable = getDrawable(R.drawable.ic_pdf_file_format_symbol);
                                imagePdf2y.setImageDrawable(myDrawable);
                                break;
                            }
                            case "text/plain": {
                                Drawable myDrawable = getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                                imagePdf2y.setImageDrawable(myDrawable);
                                break;
                            }
                            case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                                Drawable myDrawable = getDrawable(R.drawable.ic_xls_file_format_symbol);
                                imagePdf2y.setImageDrawable(myDrawable);
                                break;
                            }
                            default: {
                                Drawable myDrawable = getDrawable(R.drawable.file);
                                imagePdf2y.setImageDrawable(myDrawable);
                                break;
                            }
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();

                            namePdf2y.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            filesy.add(filesUri);
                            Toast.makeText(this, filename, Toast.LENGTH_SHORT).show();
                            pdfCancel2y.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // layout1.removeView(v);
                                    pdfCardView2y.setVisibility(View.GONE);
                                    pdf_layout2y.setVisibility(View.GONE);
                                    namePdf2y.setVisibility(View.GONE);
                                    imagePdf2y.setVisibility(View.GONE);
                                    imagePdf2y.setImageBitmap(null);
                                    filesy.remove(filesUri);
                                    if (imageFilesy.size() == 0 && filesy.size() == 0) {
                                        scrolly.setVisibility(View.GONE);
                                        layouty.setVisibility(View.GONE);
                                    }
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }
        }
    }


    public class ReadThreadMessagesTask extends AsyncTask<Void, Void, List<Message>> {
        List<Message> messageList;
        MessageViewModel messageViewModel;
        String cThread;
        String message;

        public ReadThreadMessagesTask(MessageViewModel messageViewModel, String cThread, String message) {
            this.messageViewModel = messageViewModel;
            this.cThread = cThread;
            messageList = new ArrayList<>();
            this.message = message;
        }

        @Override
        protected List<Message> doInBackground(Void... voids) {
            messageList = messageViewModel.getThreadMessages(cThread);
            Log.e("Message Received", "x");
            return messageList;
        }

        @Override
        protected void onPostExecute(List<Message> messages) {
            super.onPostExecute(messages);
            Log.e("Message Received", String.valueOf(messages.size()));
            for (int i = 0; i < messages.size(); i++) {
                if (messages.get(i).getMessage_text().equals(message)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(ChatFinalActivity.this);
                    builder.setTitle("Same Message Already Exists.");

                    builder.setMessage("Are You Sure you want to send  this message?");
                    builder.setNegativeButton("NO",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                    builder.setPositiveButton("Yes",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    try {
                                        //Create_Feed.FeedTask feedTask = new Create_Feed.FeedTask();
                                        //feedTask.execute();
                                        SendMessageTask sendMessageTask = new SendMessageTask(cThread, message, imageFilesy, filesy);
                                        sendMessageTask.execute();
                                        //SendMessageTask sendMessageTask = new SendMessageTask();
                                        //sendMessageTask.execute(editText);
                                        text_editor_edit.setText("");
                                        imageFilesy = new ArrayList<>();
                                        filesy = new ArrayList<>();
                                        scrolly.setVisibility(View.GONE);
                                        layouty.setVisibility(View.GONE);
                                        galleryImagey.setImageBitmap(null);
                                        galleryImagey.setVisibility(View.GONE);
                                        imageCancely.setVisibility(View.GONE);
                                        galleryImage1y.setImageBitmap(null);
                                        galleryImage1y.setVisibility(View.GONE);
                                        imageCancel1y.setVisibility(View.GONE);
                                        galleryImage2y.setImageBitmap(null);
                                        galleryImage2y.setVisibility(View.GONE);
                                        imageCancel2y.setVisibility(View.GONE);
                                        pdfCardViewy.setVisibility(View.GONE);
                                        imagePdfy.setVisibility(View.GONE);
                                        imagePdfy.setImageBitmap(null);
                                        namePdfy.setVisibility(View.GONE);
                                        pdfCancely.setVisibility(View.GONE);
                                        pdf_layouty.setVisibility(View.GONE);
                                        pdfCardView1y.setVisibility(View.GONE);
                                        imagePdf1y.setVisibility(View.GONE);
                                        imagePdf1y.setImageBitmap(null);
                                        namePdf1y.setVisibility(View.GONE);
                                        pdfCancel1y.setVisibility(View.GONE);
                                        pdf_layout1y.setVisibility(View.GONE);
                                        pdfCardView2y.setVisibility(View.GONE);
                                        imagePdf2y.setVisibility(View.GONE);
                                        imagePdf2y.setImageBitmap(null);
                                        namePdf2y.setVisibility(View.GONE);
                                        pdfCancel2y.setVisibility(View.GONE);
                                        pdf_layout2y.setVisibility(View.GONE);
                                    } catch (Exception e) {
                                        Log.e("exception", e.toString());
                                    }
                                }
                            });
                    builder.show();
                    break;
                } else {
                    if (i == messages.size() - 1) {
                        try {
                            SendMessageTask sendMessageTask = new SendMessageTask(cThread, message, imageFilesy, filesy);
                            sendMessageTask.execute();

                            text_editor_edit.setText("");
                            imageFilesy = new ArrayList<>();
                            filesy = new ArrayList<>();
                            scrolly.setVisibility(View.GONE);
                            layouty.setVisibility(View.GONE);
                            galleryImagey.setImageBitmap(null);
                            galleryImagey.setVisibility(View.GONE);
                            imageCancely.setVisibility(View.GONE);
                            galleryImage1y.setImageBitmap(null);
                            galleryImage1y.setVisibility(View.GONE);
                            imageCancel1y.setVisibility(View.GONE);
                            galleryImage2y.setImageBitmap(null);
                            galleryImage2y.setVisibility(View.GONE);
                            imageCancel2y.setVisibility(View.GONE);
                            pdfCardViewy.setVisibility(View.GONE);
                            imagePdfy.setVisibility(View.GONE);
                            imagePdfy.setImageBitmap(null);
                            namePdfy.setVisibility(View.GONE);
                            pdfCancely.setVisibility(View.GONE);
                            pdf_layouty.setVisibility(View.GONE);
                            pdfCardView1y.setVisibility(View.GONE);
                            imagePdf1y.setVisibility(View.GONE);
                            imagePdf1y.setImageBitmap(null);
                            namePdf1y.setVisibility(View.GONE);
                            pdfCancel1y.setVisibility(View.GONE);
                            pdf_layout1y.setVisibility(View.GONE);
                            pdfCardView2y.setVisibility(View.GONE);
                            imagePdf2y.setVisibility(View.GONE);
                            imagePdf2y.setImageBitmap(null);
                            namePdf2y.setVisibility(View.GONE);
                            pdfCancel2y.setVisibility(View.GONE);
                            pdf_layout2y.setVisibility(View.GONE);
                        } catch (Exception e) {
                            Log.e("exception", e.toString());
                        }
                    }
                }
            }
        }
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    private class SendMessageTask extends AsyncTask<Void, Void, Void> {
        int i = 0;
        int x = 0;
        private List<Uri> imageFiles1;
        private List<FilesUri> files1;
        Intent intent = getIntent();

        private List<String> URLs = new ArrayList<>();
        private List<Files> FilesURLs = new ArrayList<>();
        String keyyy = UUID.randomUUID().toString();
        String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String string2 = new SimpleDateFormat("dd MM yy hh:mm a").format(new Date());

        String msg;
        Map<String, String> hashMap = new HashMap();
        Map<String, String> hashMap1 = new HashMap();

        String currentThread;

        public SendMessageTask(String currentThread, String msg, List<Uri> imageFiles1, List<FilesUri> files1) {
            this.imageFiles1 = imageFiles1;
            this.files1 = files1;
            this.msg = msg;
            this.currentThread = currentThread;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            hashMap.put("MessageKey", keyyy + intent.getStringExtra("name"));
            hashMap.put("Sender", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname);
            hashMap.put("Receiver", intent.getStringExtra("name"));
            hashMap.put("Workplace", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName);
            hashMap.put("Create Date", string2);
            hashMap.put("Message", msg);
            hashMap.put("Timestamp", timestamp);
            hashMap.put("ThreadKey", currentThread);
            if (imageFiles1.size() != 0) {
                hashMap.put("ImagesNumber", String.valueOf(imageFiles1.size()));
            } else {
                hashMap.put("ImagesNumber", String.valueOf(0));
            }
            if (files1.size() != 0) {
                hashMap.put("FilesNumber", String.valueOf(files1.size()));
            } else {
                hashMap.put("FilesNumber", String.valueOf(0));
            }
            hashMap1.put("Sender", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname);
            hashMap1.put("Receiver", intent.getStringExtra("name"));
            hashMap1.put("ReceiverKey", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key);
            hashMap1.put("Workplace", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName);
            hashMap1.put("Create Date", string2);
            hashMap1.put("Message", msg);
            hashMap1.put("Timestamp", timestamp);
            if (imageFiles1.size() != 0) {
                hashMap1.put("ImagesNumber", String.valueOf(imageFiles1.size()));
            } else {
                hashMap1.put("ImagesNumber", String.valueOf(0));
            }
            if (files1.size() != 0) {
                hashMap1.put("FilesNumber", String.valueOf(files1.size()));
            } else {
                hashMap1.put("FilesNumber", String.valueOf(0));
            }
            //for future ref
            if (imageFiles1.size() == 0 && files1.size() == 0) {
                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("LatestMessages")
                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
            }
            //for future ref
            if (imageFiles1.size() == 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(1));
                messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                        intent.getStringExtra("name"),
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                        string2,
                        msg,
                        1,
                        timestamp,
                        currentThread,
                        "", null, null, true));

                membersViewModel.updateMember(intent.getStringExtra("MemberKey"), msg,
                        0, string2, timestamp);
                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child(keyyy + intent.getStringExtra("name"))
                        .child("Likes").child("x").setValue("1");

                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("OwnMessages").child(Friend_Key)
                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child("Mails")
                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("OwnMessages")
                        .child(Friend_Key)
                        .child(keyyy + intent.getStringExtra("name"))
                        .child("Likes").child("x").setValue("1");

                sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
            } else if (imageFiles1.size() == 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(2));
            } else if (imageFiles1.size() != 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(3));
            } else if (imageFiles1.size() != 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(4));
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {

                if (imageFiles1.size() != 0) {
                    while (i < imageFiles1.size()) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Chat")
                                .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                .child(string2).child("Images").child(String.valueOf(i));
                        storageReference.putFile(imageFiles1.get(i)).addOnSuccessListener(taskSnapshot -> storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                            x++;
                            URLs.add(uri.toString());
                            hashMap.put("ImageUrl" + x, uri.toString());


                            if (x == (imageFiles1.size())) {
                                if (files1.size() == 0) {
                                    while (URLs.size() <= imageFiles1.size()) {
                                        if (URLs.size() == imageFiles1.size()) {
                                            Uri uri1 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                            messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                    intent.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                    string2,
                                                    msg,
                                                    1,
                                                    timestamp,
                                                    currentThread,
                                                    "", URLs, null, true));

                                            membersViewModel.updateMember(intent.getStringExtra("MemberKey"),
                                                    msg,
                                                    0, string2, timestamp);

                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");

                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages").child(Friend_Key)
                                                    .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages")
                                                    .child(Friend_Key)
                                                    .child(keyyy + intent.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");

                                            sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("LatestMessages")
                                                    .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
                                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                    .setSmallIcon(R.drawable.smiley)
                                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                    .setContentTitle(" Success")
                                                    .setSound(uri1)
                                                    .setContentText(" Feed Created ")
                                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                    .build();
                                            notificationManagerCompat.notify(1, notification);

                                        }
                                        break;
                                    }

                                } else {
                                    while (URLs.size() <= imageFiles1.size()) {
                                        if (URLs.size() == imageFiles1.size()) {
                                            StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                    .child(string2).child("Files").child(String.valueOf(1));
                                            storageReference1.putFile(files1.get(0).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                    storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                        @Override
                                                        public void onSuccess(Uri uri) {
                                                            Files files = new Files(files1.get(0).getName(), files1.get(0).getType(), uri.toString());
                                                            FilesURLs.add(files);

                                                            hashMap.put("FileUrl1", uri.toString());
                                                            hashMap.put("FileName1", files1.get(0).getName());
                                                            hashMap.put("FileType1", files1.get(0).getType());
                                                            if (files1.size() == 1) {
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages").child(Friend_Key)
                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages")
                                                                        .child(Friend_Key)
                                                                        .child(keyyy + intent.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("LatestMessages")
                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
                                                                messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                        intent.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                        string2,
                                                                        msg,
                                                                        1,
                                                                        timestamp,
                                                                        currentThread,
                                                                        "", URLs, FilesURLs, true));


                                                                membersViewModel.updateMember(intent.getStringExtra("MemberKey"),
                                                                        msg,
                                                                        0, string2, timestamp);
                                                                sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);

                                                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                        .setSmallIcon(R.drawable.smiley)
                                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                        .setContentTitle(" Success")
                                                                        .setContentText(" Message Sent ")
                                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                        .build();
                                                                notificationManagerCompat.notify(1, notification);
                                                            } else {
                                                                StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                                        .child(string2).child("Files").child(String.valueOf(2));
                                                                storageReference1.putFile(files1.get(1).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                                        storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                                            @Override
                                                                            public void onSuccess(Uri uri) {
                                                                                Files files = new Files(files1.get(1).getName(), files1.get(1).getType(), uri.toString());
                                                                                FilesURLs.add(files);

                                                                                hashMap.put("FileUrl2", uri.toString());
                                                                                hashMap.put("FileName2", files1.get(1).getName());
                                                                                hashMap.put("FileType2", files1.get(1).getType());
                                                                                if (files1.size() == 2) {
                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child(keyyy + intent.getStringExtra("name"))
                                                                                            .child("Likes").child("x").setValue("1");

                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("OwnMessages").child(Friend_Key)
                                                                                            .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child("Mails")
                                                                                            .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("OwnMessages")
                                                                                            .child(Friend_Key)
                                                                                            .child(keyyy + intent.getStringExtra("name"))
                                                                                            .child("Likes").child("x").setValue("1");

                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("LatestMessages")
                                                                                            .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
                                                                                    messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                            intent.getStringExtra("name"),
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                            string2,
                                                                                            msg,
                                                                                            1,
                                                                                            timestamp,
                                                                                            currentThread,
                                                                                            "", URLs, FilesURLs, true));


                                                                                    membersViewModel.updateMember(intent.getStringExtra("MemberKey"),
                                                                                            msg,
                                                                                            0, string2, timestamp);

                                                                                    sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                            .setSmallIcon(R.drawable.smiley)
                                                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                            .setContentTitle(" Success")
                                                                                            .setContentText(" Message Sent ")
                                                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                            .build();
                                                                                    notificationManagerCompat.notify(1, notification);
                                                                                } else {
                                                                                    StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                                                            .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                                                            .child(string2).child("Files").child(String.valueOf(3));
                                                                                    storageReference1.putFile(files1.get(2).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                                                        @Override
                                                                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                                                            storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                                                                @Override
                                                                                                public void onSuccess(Uri uri) {
                                                                                                    Files files = new Files(files1.get(2).getName(), files1.get(2).getType(), uri.toString());
                                                                                                    FilesURLs.add(files);

                                                                                                    hashMap.put("FileUrl3", uri.toString());
                                                                                                    hashMap.put("FileName3", files1.get(2).getName());
                                                                                                    hashMap.put("FileType3", files1.get(2).getType());

                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child(keyyy + intent.getStringExtra("name"))
                                                                                                            .child("Likes").child("x").setValue("1");

                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("OwnMessages").child(Friend_Key)
                                                                                                            .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child("Mails")
                                                                                                            .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("OwnMessages")
                                                                                                            .child(Friend_Key)
                                                                                                            .child(keyyy + intent.getStringExtra("name"))
                                                                                                            .child("Likes").child("x").setValue("1");
                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("LatestMessages")
                                                                                                            .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
                                                                                                    messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                                            intent.getStringExtra("name"),
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                                            string2,
                                                                                                            msg,
                                                                                                            1,
                                                                                                            timestamp,
                                                                                                            currentThread,
                                                                                                            "", URLs, FilesURLs, true));


                                                                                                    membersViewModel.updateMember(intent.getStringExtra("MemberKey"),
                                                                                                            msg,
                                                                                                            0, string2, timestamp);

                                                                                                    sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                                                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                                            .setSmallIcon(R.drawable.smiley)
                                                                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                                            .setContentTitle(" Success")
                                                                                                            .setContentText(" Message Sent ")
                                                                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                                            .build();
                                                                                                    notificationManagerCompat.notify(1, notification);

                                                                                                }
                                                                                            });
                                                                                        }
                                                                                    })
                                                                                            .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                                                                @Override
                                                                                                public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                                                                    long max = taskSnapshot.getTotalByteCount();
                                                                                                    long current = taskSnapshot.getBytesTransferred();
                                                                                                    int asd = (int) max;
                                                                                                    int asdCurrent = (int) current;
                                                                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                                            .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                                                                            .setContentTitle("Uploading Files")
                                                                                                            .setContentText("Upload in Progress")
                                                                                                            .setOngoing(true)
                                                                                                            .setOnlyAlertOnce(true)
                                                                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                                            .setProgress(asd, asdCurrent, false).build();
                                                                                                    notificationManagerCompat.notify(1, notification);
                                                                                                }
                                                                                            }).addOnFailureListener(new OnFailureListener() {
                                                                                        @Override
                                                                                        public void onFailure(@NonNull Exception e) {
                                                                                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                                    .setSmallIcon(R.drawable.smiley)
                                                                                                    .setContentTitle(" Failed")
                                                                                                    .setContentText(" Message Send Failed ")
                                                                                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                                    .build();
                                                                                            notificationManagerCompat.notify(1, notification);
                                                                                        }
                                                                                    });
                                                                                    ;
                                                                                }
                                                                            }
                                                                        });
                                                                    }
                                                                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                                        long max = taskSnapshot.getTotalByteCount();
                                                                        long current = taskSnapshot.getBytesTransferred();
                                                                        int asd = (int) max;
                                                                        int asdCurrent = (int) current;
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                                                .setContentTitle("Uploading Files")
                                                                                .setContentText("Upload in Progress")
                                                                                .setOngoing(true)
                                                                                .setOnlyAlertOnce(true)
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                .setProgress(asd, asdCurrent, false).build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                }).addOnFailureListener(new OnFailureListener() {
                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.smiley)
                                                                                .setContentTitle(" Failed")
                                                                                .setContentText(" Message Send Failed ")
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                .build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                });
                                                                ;
                                                            }
                                                        }
                                                    });
                                                }
                                            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                    long max = taskSnapshot.getTotalByteCount();
                                                    long current = taskSnapshot.getBytesTransferred();
                                                    int asd = (int) max;
                                                    int asdCurrent = (int) current;
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                            .setContentTitle("Uploading Files")
                                                            .setContentText("Upload in Progress")
                                                            .setOngoing(true)
                                                            .setOnlyAlertOnce(true)
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                            .setProgress(asd, asdCurrent, false).build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.smiley)
                                                            .setContentTitle(" Failed")
                                                            .setContentText(" Message Send Failed ")
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                            .build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            });
                                            break;
                                        }
                                    }
                                }
                            }
                        })).addOnFailureListener(e -> {
                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                    .setSmallIcon(R.drawable.smiley)
                                    .setContentTitle(" Failed")
                                    .setContentText(" Message Sent Failed ")
                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                    .build();
                            notificationManagerCompat.notify(1, notification);
                        }).addOnProgressListener(taskSnapshot -> {
                            long max = taskSnapshot.getTotalByteCount();
                            long current = taskSnapshot.getBytesTransferred();
                            int asd = (int) max;
                            int asdCurrent = (int) current;
                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                    .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                    .setContentTitle("Uploading Images")
                                    .setContentText("Upload in Progress")
                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                    .setOngoing(true)
                                    .setOnlyAlertOnce(true)
                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                    .setProgress(asd, asdCurrent, false).build();
                            notificationManagerCompat.notify(1, notification);
                        });
                        i++;
                    }
                } else {
                    if (files1.size() != 0) {

                        StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                .child(string2).child("Files").child(String.valueOf(1));
                        storageReference1.putFile(files1.get(0).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        Files files = new Files(files1.get(0).getName(), files1.get(0).getType(), uri.toString());
                                        FilesURLs.add(files);

                                        hashMap.put("FileUrl1", uri.toString());
                                        hashMap.put("FileName1", files1.get(0).getName());
                                        hashMap.put("FileType1", files1.get(0).getType());
                                        if (files1.size() == 1) {
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");

                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages").child(Friend_Key)
                                                    .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages")
                                                    .child(Friend_Key)
                                                    .child(keyyy + intent.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");

                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("LatestMessages")
                                                    .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
                                            messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                    intent.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                    string2,
                                                    msg,
                                                    1,
                                                    timestamp,
                                                    currentThread,
                                                    "", null, FilesURLs, true));

                                            sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);

                                            membersViewModel.updateMember(intent.getStringExtra("MemberKey"),
                                                    msg,
                                                    0, string2, timestamp);

                                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                    .setSmallIcon(R.drawable.smiley)
                                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                    .setContentTitle(" Success")
                                                    .setContentText(" Message Sent ")
                                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                    .build();
                                            notificationManagerCompat.notify(1, notification);
                                        } else {
                                            StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                    .child(string2).child("Files").child(String.valueOf(2));
                                            storageReference1.putFile(files1.get(1).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                    storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                        @Override
                                                        public void onSuccess(Uri uri) {
                                                            Files files = new Files(files1.get(1).getName(), files1.get(1).getType(), uri.toString());
                                                            FilesURLs.add(files);

                                                            hashMap.put("FileUrl2", uri.toString());
                                                            hashMap.put("FileName2", files1.get(1).getName());
                                                            hashMap.put("FileType2", files1.get(1).getType());
                                                            if (files1.size() == 2) {
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages").child(Friend_Key)
                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages")
                                                                        .child(Friend_Key)
                                                                        .child(keyyy + intent.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("LatestMessages")
                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
                                                                messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                        intent.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                        string2,
                                                                        msg,
                                                                        1,
                                                                        timestamp,
                                                                        currentThread,
                                                                        "", null, FilesURLs, true));


                                                                sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                                                membersViewModel.updateMember(intent.getStringExtra("MemberKey"),
                                                                        msg,
                                                                        0, string2, timestamp);

                                                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                        .setSmallIcon(R.drawable.smiley)
                                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                        .setContentTitle(" Success")
                                                                        .setContentText(" Message Sent ")
                                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                        .build();
                                                                notificationManagerCompat.notify(1, notification);
                                                            } else {
                                                                StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                                        .child(string2).child("Files").child(String.valueOf(3));
                                                                storageReference1.putFile(files1.get(2).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                                        storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                                            @Override
                                                                            public void onSuccess(Uri uri) {
                                                                                Files files = new Files(files1.get(2).getName(), files1.get(2).getType(), uri.toString());
                                                                                FilesURLs.add(files);

                                                                                hashMap.put("FileUrl3", uri.toString());
                                                                                hashMap.put("FileName3", files1.get(2).getName());
                                                                                hashMap.put("FileType3", files1.get(2).getType());

                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child(keyyy + intent.getStringExtra("name"))
                                                                                        .child("Likes").child("x").setValue("1");

                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("OwnMessages").child(Friend_Key)
                                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap);
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child("Mails")
                                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("OwnMessages")
                                                                                        .child(Friend_Key)
                                                                                        .child(keyyy + intent.getStringExtra("name"))
                                                                                        .child("Likes").child("x").setValue("1");
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("LatestMessages")
                                                                                        .child(keyyy + intent.getStringExtra("name")).setValue(hashMap1);
                                                                                messageViewModel.insert(new Message(keyyy + intent.getStringExtra("name"),
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                        intent.getStringExtra("name"),
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                        string2,
                                                                                        msg,
                                                                                        1,
                                                                                        timestamp,
                                                                                        currentThread,
                                                                                        "", null, FilesURLs, true));


                                                                                sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                                                                membersViewModel.updateMember(intent.getStringExtra("MemberKey"),
                                                                                        msg,
                                                                                        0, string2, timestamp);

                                                                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                        .setSmallIcon(R.drawable.smiley)
                                                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                        .setContentTitle(" Success")
                                                                                        .setContentText(" Message Sent ")
                                                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                        .build();
                                                                                notificationManagerCompat.notify(1, notification);

                                                                            }
                                                                        });
                                                                    }
                                                                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                                        long max = taskSnapshot.getTotalByteCount();
                                                                        long current = taskSnapshot.getBytesTransferred();
                                                                        int asd = (int) max;
                                                                        int asdCurrent = (int) current;
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                                                .setContentTitle("Uploading Files")
                                                                                .setContentText("Upload in Progress")
                                                                                .setOngoing(true)
                                                                                .setOnlyAlertOnce(true)
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                .setProgress(asd, asdCurrent, false).build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                }).addOnFailureListener(new OnFailureListener() {
                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.smiley)
                                                                                .setContentTitle(" Failed")
                                                                                .setContentText(" Message Send Failed ")
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                .build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                });
                                                                ;
                                                            }
                                                        }
                                                    });
                                                }
                                            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                    long max = taskSnapshot.getTotalByteCount();
                                                    long current = taskSnapshot.getBytesTransferred();
                                                    int asd = (int) max;
                                                    int asdCurrent = (int) current;
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                            .setContentTitle("Uploading Files")
                                                            .setContentText("Upload in Progress")
                                                            .setOngoing(true)
                                                            .setOnlyAlertOnce(true)
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                            .setProgress(asd, asdCurrent, false).build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.smiley)
                                                            .setContentTitle(" Failed")
                                                            .setContentText(" Message Send Failed ")
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                            .build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            });
                                            ;
                                        }
                                    }
                                });
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                long max = taskSnapshot.getTotalByteCount();
                                long current = taskSnapshot.getBytesTransferred();
                                int asd = (int) max;
                                int asdCurrent = (int) current;
                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                        .setContentTitle("Uploading Files")
                                        .setContentText("Upload in Progress")
                                        .setOngoing(true)
                                        .setOnlyAlertOnce(true)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setProgress(asd, asdCurrent, false).build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.smiley)
                                        .setContentTitle(" Failed")
                                        .setContentText(" Message Send Failed ")
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        });

                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                Log.e("error", e.toString());
            }
            return null;
        }
    }

    private class SendMessageTaskNew extends AsyncTask<Void, Void, Void> {
        private List<Uri> imageFiles1;
        int i = 0;
        int x = 0;
        String msg;
        private List<FilesUri> files1;
        String keyyy = UUID.randomUUID().toString();
        Intent intent1 = getIntent();
        private List<String> URLs = new ArrayList<>();
        private List<Files> FilesURLs = new ArrayList<>();
        String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String string21 = new SimpleDateFormat("dd MM yy hh:mm a").format(new Date());

        Map<String, String> hashMap = new HashMap();
        Map<String, String> hashMap2 = new HashMap();
        Map<String, String> hashMap1 = new HashMap();

        private SendMessageTaskNew(List<Uri> imageFiles1, List<FilesUri> files1, String msg) {
            this.imageFiles1 = imageFiles1;
            this.files1 = files1;
            this.msg = msg;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            hashMap2.put("ThreadKey", keyyy + intent1.getStringExtra("name"));
            hashMap2.put("Sender", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname);
            hashMap2.put("Receiver", intent1.getStringExtra("name"));
            hashMap2.put("Workplace", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName);
            hashMap2.put("Create Date", string21);
            hashMap2.put("Timestamp", timestamp);
            if (imageFiles1.size() != 0) {
                hashMap2.put("ImagesNumber", String.valueOf(imageFiles1.size()));
            } else {
                hashMap2.put("ImagesNumber", String.valueOf(0));
            }
            if (files1.size() != 0) {
                hashMap2.put("FilesNumber", String.valueOf(files1.size()));
            } else {
                hashMap2.put("FilesNumber", String.valueOf(0));
            }
            if (imageFiles1.size() == 0 && files1.size() == 0) {
                hashMap2.put("Ready", String.valueOf(1));

            } else if (imageFiles1.size() == 0 && files1.size() != 0) {
                hashMap2.put("Ready", String.valueOf(2));
            } else if (imageFiles1.size() != 0 && files1.size() == 0) {
                hashMap2.put("Ready", String.valueOf(3));
            } else if (imageFiles1.size() != 0 && files1.size() != 0) {
                hashMap2.put("Ready", String.valueOf(4));
            }

            hashMap.put("MessageKey", keyyy + intent1.getStringExtra("name"));
            hashMap.put("Sender", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname);
            hashMap.put("Receiver", intent1.getStringExtra("name"));
            hashMap.put("Workplace", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName);
            hashMap.put("Create Date", string21);
            hashMap.put("Message", msg);
            hashMap.put("Timestamp", timestamp);
            hashMap.put("ThreadKey", keyyy + intent1.getStringExtra("name"));
            if (imageFiles1.size() != 0) {
                hashMap.put("ImagesNumber", String.valueOf(imageFiles1.size()));
            } else {
                hashMap.put("ImagesNumber", String.valueOf(0));
            }
            if (files1.size() != 0) {
                hashMap.put("FilesNumber", String.valueOf(files1.size()));
            } else {
                hashMap.put("FilesNumber", String.valueOf(0));
            }
            if (imageFiles1.size() == 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(1));
                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);
            } else if (imageFiles1.size() == 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(2));
            } else if (imageFiles1.size() != 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(3));
            } else if (imageFiles1.size() != 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(4));
            }

            hashMap1.put("Sender", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname);
            hashMap1.put("Receiver", intent1.getStringExtra("name"));
            hashMap1.put("ReceiverKey", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key);
            hashMap1.put("Workplace", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName);
            hashMap1.put("Create Date", string21);
            hashMap1.put("Message", msg);
            hashMap1.put("Timestamp", timestamp);
            if (imageFiles1.size() != 0) {
                hashMap1.put("ImagesNumber", String.valueOf(imageFiles1.size()));
            } else {
                hashMap1.put("ImagesNumber", String.valueOf(0));
            }
            if (files1.size() != 0) {
                hashMap1.put("FilesNumber", String.valueOf(files1.size()));
            } else {
                hashMap1.put("FilesNumber", String.valueOf(0));
            }
            if (imageFiles1.size() == 0 && files1.size() == 0) {
                threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                        intent1.getStringExtra("name"),
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                        string21, timestamp, recyclerviewThread.getItemCount()));
                membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                        msg,
                        0, string21, timestamp);
                messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                        intent1.getStringExtra("name"),
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                        string21,
                        msg,
                        1,
                        timestamp,
                        keyyy + intent1.getStringExtra("name"),
                        "", null, null, true));
                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child(keyyy + intent1.getStringExtra("name"))
                        .child("Likes").child("x").setValue("1");

                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("OwnMessages").child(Friend_Key)
                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child("Mails")
                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("OwnMessages")
                        .child(Friend_Key)
                        .child(keyyy + intent1.getStringExtra("name"))
                        .child("Likes").child("x").setValue("1");
                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("LatestMessages")
                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);
            } else if (imageFiles1.size() == 0 && files1.size() != 0) {
                hashMap1.put("Ready", String.valueOf(2));
            } else if (imageFiles1.size() != 0 && files1.size() == 0) {
                hashMap1.put("Ready", String.valueOf(3));
            } else if (imageFiles1.size() != 0 && files1.size() != 0) {
                hashMap1.put("Ready", String.valueOf(4));
            }

        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {

                if (imageFiles1.size() != 0) {
                    while (i < imageFiles1.size()) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Chat")
                                .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                .child(string21).child("Images").child(String.valueOf(i));
                        storageReference.putFile(imageFiles1.get(i)).addOnSuccessListener(taskSnapshot -> storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                            x++;
                            URLs.add(uri.toString());
                            hashMap.put("ImageUrl" + x, uri.toString());
                            if (x == (imageFiles1.size())) {
                                if (files1.size() == 0) {
                                    while (URLs.size() <= imageFiles1.size()) {
                                        if (URLs.size() == imageFiles1.size()) {
                                            threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                    intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                    string21, timestamp, recyclerviewThread.getItemCount()));
                                            membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                                                    msg,
                                                    0, string21, timestamp);
                                            messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                    intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                    string21,
                                                    msg,
                                                    1,
                                                    timestamp,
                                                    keyyy + intent1.getStringExtra("name"),
                                                    "", URLs, null, true));
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);

                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent1.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");

                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages").child(Friend_Key)
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages")
                                                    .child(Friend_Key)
                                                    .child(keyyy + intent1.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("LatestMessages")
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);

                                            sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("LatestMessages")
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);
                                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                    .setSmallIcon(R.drawable.smiley)
                                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                    .setContentTitle(" Success")
                                                    .setContentText(" Feed Created ")
                                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                    .build();
                                            notificationManagerCompat.notify(1, notification);
                                            break;
                                        }
                                    }

                                } else {
                                    while (URLs.size() <= imageFiles1.size()) {
                                        if (URLs.size() == imageFiles1.size()) {
                                            StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                    .child(string21).child("Files").child(String.valueOf(1));
                                            storageReference1.putFile(files1.get(0).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                    storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                        @Override
                                                        public void onSuccess(Uri uri) {
                                                            Files files = new Files(files1.get(0).getName(), files1.get(0).getType(), uri.toString());
                                                            FilesURLs.add(files);

                                                            hashMap.put("FileUrl1", uri.toString());
                                                            hashMap.put("FileName1", files1.get(0).getName());
                                                            hashMap.put("FileType1", files1.get(0).getType());
                                                            if (files1.size() == 1) {
                                                                threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                        intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                        string21, timestamp, recyclerviewThread.getItemCount()));
                                                                membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                                                                        msg,
                                                                        0, string21, timestamp);
                                                                messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                        intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                        string21,
                                                                        msg,
                                                                        1,
                                                                        timestamp,
                                                                        keyyy + intent1.getStringExtra("name"),
                                                                        "", URLs, FilesURLs, true));

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent1.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages").child(Friend_Key)
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages")
                                                                        .child(Friend_Key)
                                                                        .child(keyyy + intent1.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("LatestMessages")
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);
                                                                sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);

                                                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                        .setSmallIcon(R.drawable.smiley)
                                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                        .setContentTitle(" Success")
                                                                        .setContentText(" Message Sent ")
                                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                        .build();
                                                                notificationManagerCompat.notify(1, notification);
                                                            } else {
                                                                StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                                        .child(string21).child("Files").child(String.valueOf(2));
                                                                storageReference1.putFile(files1.get(1).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                                        storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                                            @Override
                                                                            public void onSuccess(Uri uri) {
                                                                                Files files = new Files(files1.get(1).getName(), files1.get(1).getType(), uri.toString());
                                                                                FilesURLs.add(files);

                                                                                hashMap.put("FileUrl2", uri.toString());
                                                                                hashMap.put("FileName2", files1.get(1).getName());
                                                                                hashMap.put("FileType2", files1.get(1).getType());
                                                                                if (files1.size() == 2) {
                                                                                    threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                            intent1.getStringExtra("name"),
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                            string21, timestamp, recyclerviewThread.getItemCount()));
                                                                                    membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                                                                                            msg,
                                                                                            0, string21, timestamp);
                                                                                    messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                            intent1.getStringExtra("name"),
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                            string21,
                                                                                            msg,
                                                                                            1,
                                                                                            timestamp,
                                                                                            keyyy + intent1.getStringExtra("name"),
                                                                                            "", URLs, FilesURLs, true));
                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);

                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child(keyyy + intent1.getStringExtra("name"))
                                                                                            .child("Likes").child("x").setValue("1");

                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("OwnMessages").child(Friend_Key)
                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                            .child("Mails")
                                                                                            .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("OwnMessages")
                                                                                            .child(Friend_Key)
                                                                                            .child(keyyy + intent1.getStringExtra("name"))
                                                                                            .child("Likes").child("x").setValue("1");
                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child("LatestMessages")
                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);

                                                                                    sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                            .setSmallIcon(R.drawable.smiley)
                                                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                            .setContentTitle(" Success")
                                                                                            .setContentText(" Message Sent ")
                                                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                            .build();
                                                                                    notificationManagerCompat.notify(1, notification);
                                                                                } else {
                                                                                    StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                                                            .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                            .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                                                            .child(string21).child("Files").child(String.valueOf(3));
                                                                                    storageReference1.putFile(files1.get(2).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                                                        @Override
                                                                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                                                            storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                                                                @Override
                                                                                                public void onSuccess(Uri uri) {
                                                                                                    Files files = new Files(files1.get(2).getName(), files1.get(2).getType(), uri.toString());
                                                                                                    FilesURLs.add(files);

                                                                                                    hashMap.put("FileUrl3", uri.toString());
                                                                                                    hashMap.put("FileName3", files1.get(2).getName());
                                                                                                    hashMap.put("FileType3", files1.get(2).getType());

                                                                                                    threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                                            intent1.getStringExtra("name"),
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                                            string21, timestamp, recyclerviewThread.getItemCount()));
                                                                                                    membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                                                                                                            msg,
                                                                                                            0, string21, timestamp);
                                                                                                    messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                                            intent1.getStringExtra("name"),
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                                            string21,
                                                                                                            msg,
                                                                                                            1,
                                                                                                            timestamp,
                                                                                                            keyyy + intent1.getStringExtra("name"),
                                                                                                            "", null, null, true));
                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);

                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child(keyyy + intent1.getStringExtra("name"))
                                                                                                            .child("Likes").child("x").setValue("1");

                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("OwnMessages").child(Friend_Key)
                                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                                            .child("Mails")
                                                                                                            .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("OwnMessages")
                                                                                                            .child(Friend_Key)
                                                                                                            .child(keyyy + intent1.getStringExtra("name"))
                                                                                                            .child("Likes").child("x").setValue("1");
                                                                                                    FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                                            .child("LatestMessages")
                                                                                                            .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);

                                                                                                    sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                                                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                                            .setSmallIcon(R.drawable.smiley)
                                                                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                                            .setContentTitle(" Success")
                                                                                                            .setContentText(" Message Sent ")
                                                                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                                            .build();
                                                                                                    notificationManagerCompat.notify(1, notification);

                                                                                                }
                                                                                            });
                                                                                        }
                                                                                    })
                                                                                            .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                                                                @Override
                                                                                                public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                                                                    long max = taskSnapshot.getTotalByteCount();
                                                                                                    long current = taskSnapshot.getBytesTransferred();
                                                                                                    int asd = (int) max;
                                                                                                    int asdCurrent = (int) current;
                                                                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                                            .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                                                                            .setContentTitle("Uploading Files")
                                                                                                            .setContentText("Upload in Progress")
                                                                                                            .setOngoing(true)
                                                                                                            .setOnlyAlertOnce(true)
                                                                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                                            .setProgress(asd, asdCurrent, false).build();
                                                                                                    notificationManagerCompat.notify(1, notification);
                                                                                                }
                                                                                            }).addOnFailureListener(new OnFailureListener() {
                                                                                        @Override
                                                                                        public void onFailure(@NonNull Exception e) {
                                                                                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                                    .setSmallIcon(R.drawable.smiley)
                                                                                                    .setContentTitle(" Failed")
                                                                                                    .setContentText(" Message Send Failed ")
                                                                                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                                    .build();
                                                                                            notificationManagerCompat.notify(1, notification);
                                                                                        }
                                                                                    });
                                                                                    ;
                                                                                }
                                                                            }
                                                                        });
                                                                    }
                                                                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                                        long max = taskSnapshot.getTotalByteCount();
                                                                        long current = taskSnapshot.getBytesTransferred();
                                                                        int asd = (int) max;
                                                                        int asdCurrent = (int) current;
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                                                .setContentTitle("Uploading Files")
                                                                                .setContentText("Upload in Progress")
                                                                                .setOngoing(true)
                                                                                .setOnlyAlertOnce(true)
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                .setProgress(asd, asdCurrent, false).build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                }).addOnFailureListener(new OnFailureListener() {
                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.smiley)
                                                                                .setContentTitle(" Failed")
                                                                                .setContentText(" Message Send Failed ")
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                .build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                });
                                                                ;
                                                            }
                                                        }
                                                    });
                                                }
                                            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                    long max = taskSnapshot.getTotalByteCount();
                                                    long current = taskSnapshot.getBytesTransferred();
                                                    int asd = (int) max;
                                                    int asdCurrent = (int) current;
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                            .setContentTitle("Uploading Files")
                                                            .setContentText("Upload in Progress")
                                                            .setOngoing(true)
                                                            .setOnlyAlertOnce(true)
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                            .setProgress(asd, asdCurrent, false).build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.smiley)
                                                            .setContentTitle(" Failed")
                                                            .setContentText(" Message Send Failed ")
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                            .build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            });
                                            break;
                                        }
                                    }
                                }
                            }
                        })).addOnFailureListener(e -> {
                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                    .setSmallIcon(R.drawable.smiley)
                                    .setContentTitle(" Failed")
                                    .setContentText(" Message Sent Failed ")
                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                    .build();
                            notificationManagerCompat.notify(1, notification);
                        }).addOnProgressListener(taskSnapshot -> {
                            long max = taskSnapshot.getTotalByteCount();
                            long current = taskSnapshot.getBytesTransferred();
                            int asd = (int) max;
                            int asdCurrent = (int) current;
                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                    .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                    .setContentTitle("Uploading Images")
                                    .setContentText("Upload in Progress")
                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                    .setOngoing(true)
                                    .setOnlyAlertOnce(true)
                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                    .setProgress(asd, asdCurrent, false).build();
                            notificationManagerCompat.notify(1, notification);
                        });
                        i++;
                    }
                } else {
                    if (files1.size() != 0) {

                        StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                .child(string21).child("Files").child(String.valueOf(1));
                        storageReference1.putFile(files1.get(0).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        Files files = new Files(files1.get(0).getName(), files1.get(0).getType(), uri.toString());
                                        FilesURLs.add(files);

                                        hashMap.put("FileUrl1", uri.toString());
                                        hashMap.put("FileName1", files1.get(0).getName());
                                        hashMap.put("FileType1", files1.get(0).getType());
                                        if (files1.size() == 1) {

                                            threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                    intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                    string21, timestamp, recyclerviewThread.getItemCount()));
                                            membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                                                    msg,
                                                    0, string21, timestamp);
                                            messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                    intent1.getStringExtra("name"),
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                    string21,
                                                    msg,
                                                    1,
                                                    timestamp,
                                                    keyyy + intent1.getStringExtra("name"),
                                                    "", null, FilesURLs, true));
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child(keyyy + intent1.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");

                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages").child(Friend_Key)
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                    .child("Mails")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("OwnMessages")
                                                    .child(Friend_Key)
                                                    .child(keyyy + intent1.getStringExtra("name"))
                                                    .child("Likes").child("x").setValue("1");
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("LatestMessages")
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);

                                            sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);
                                            FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                    .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child("LatestMessages")
                                                    .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);


                                            Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                    .setSmallIcon(R.drawable.smiley)
                                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                    .setContentTitle(" Success")
                                                    .setContentText(" Message Sent ")
                                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                    .build();
                                            notificationManagerCompat.notify(1, notification);
                                        } else {
                                            StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                    .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                    .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                    .child(string21).child("Files").child(String.valueOf(2));
                                            storageReference1.putFile(files1.get(1).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                    storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                        @Override
                                                        public void onSuccess(Uri uri) {
                                                            Files files = new Files(files1.get(1).getName(), files1.get(1).getType(), uri.toString());
                                                            FilesURLs.add(files);

                                                            hashMap.put("FileUrl2", uri.toString());
                                                            hashMap.put("FileName2", files1.get(1).getName());
                                                            hashMap.put("FileType2", files1.get(1).getType());
                                                            if (files1.size() == 2) {


                                                                threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                        intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                        string21, timestamp, recyclerviewThread.getItemCount()));
                                                                membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                                                                        msg,
                                                                        0, string21, timestamp);
                                                                messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                        intent1.getStringExtra("name"),
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                        string21,
                                                                        msg,
                                                                        1,
                                                                        timestamp,
                                                                        keyyy + intent1.getStringExtra("name"),
                                                                        "", null, FilesURLs, true));
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child(keyyy + intent1.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages").child(Friend_Key)
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                        .child("Mails")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("OwnMessages")
                                                                        .child(Friend_Key)
                                                                        .child(keyyy + intent1.getStringExtra("name"))
                                                                        .child("Likes").child("x").setValue("1");
                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("LatestMessages")
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);

                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child("LatestMessages")
                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);
                                                                sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);

                                                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                        .setSmallIcon(R.drawable.smiley)
                                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                        .setContentTitle(" Success")
                                                                        .setContentText(" Message Sent ")
                                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                        .build();
                                                                notificationManagerCompat.notify(1, notification);
                                                            } else {
                                                                StorageReference storageReference1 = FirebaseStorage.getInstance().getReference().child("Chat")
                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                        .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Phone))
                                                                        .child(string21).child("Files").child(String.valueOf(3));
                                                                storageReference1.putFile(files1.get(2).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                                        storageReference1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                                            @Override
                                                                            public void onSuccess(Uri uri) {
                                                                                Files files = new Files(files1.get(2).getName(), files1.get(2).getType(), uri.toString());
                                                                                FilesURLs.add(files);

                                                                                hashMap.put("FileUrl3", uri.toString());
                                                                                hashMap.put("FileName3", files1.get(2).getName());
                                                                                hashMap.put("FileType3", files1.get(2).getType());

                                                                                threadsViewModel.insert(new Thread(keyyy + intent1.getStringExtra("name"),
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                        intent1.getStringExtra("name"),
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                        string21, timestamp, recyclerviewThread.getItemCount()));
                                                                                membersViewModel.updateMember(intent1.getStringExtra("MemberKey"),
                                                                                        msg,
                                                                                        0, string21, timestamp);
                                                                                messageViewModel.insert(new Message(keyyy + intent1.getStringExtra("name"),
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                                                        intent1.getStringExtra("name"),
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                                                        string21,
                                                                                        msg,
                                                                                        1,
                                                                                        timestamp,
                                                                                        keyyy + intent1.getStringExtra("name"),
                                                                                        "", null, FilesURLs, true));
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("Threads").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap2);

                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("Messages").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child(keyyy + intent1.getStringExtra("name"))
                                                                                        .child("Likes").child("x").setValue("1");

                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("OwnMessages").child(Friend_Key)
                                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap);
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                                                                                        .child("Mails")
                                                                                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("OwnMessages")
                                                                                        .child(Friend_Key)
                                                                                        .child(keyyy + intent1.getStringExtra("name"))
                                                                                        .child("Likes").child("x").setValue("1");
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("LatestMessages")
                                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);
                                                                                FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                                                                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                                                                                        .child("LatestMessages")
                                                                                        .child(keyyy + intent1.getStringExtra("name")).setValue(hashMap1);
                                                                                sendNotification(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname, msg);


                                                                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                        .setSmallIcon(R.drawable.smiley)
                                                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                        .setContentTitle(" Success")
                                                                                        .setContentText(" Message Sent ")
                                                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                        .build();
                                                                                notificationManagerCompat.notify(1, notification);

                                                                            }
                                                                        });
                                                                    }
                                                                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                                    @Override
                                                                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                                        long max = taskSnapshot.getTotalByteCount();
                                                                        long current = taskSnapshot.getBytesTransferred();
                                                                        int asd = (int) max;
                                                                        int asdCurrent = (int) current;
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                                                .setContentTitle("Uploading Files")
                                                                                .setContentText("Upload in Progress")
                                                                                .setOngoing(true)
                                                                                .setOnlyAlertOnce(true)
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                                                .setProgress(asd, asdCurrent, false).build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                }).addOnFailureListener(new OnFailureListener() {
                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {
                                                                        Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                                                .setSmallIcon(R.drawable.smiley)
                                                                                .setContentTitle(" Failed")
                                                                                .setContentText(" Message Send Failed ")
                                                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                                                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                                                .build();
                                                                        notificationManagerCompat.notify(1, notification);
                                                                    }
                                                                });
                                                                ;
                                                            }
                                                        }
                                                    });
                                                }
                                            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                                    long max = taskSnapshot.getTotalByteCount();
                                                    long current = taskSnapshot.getBytesTransferred();
                                                    int asd = (int) max;
                                                    int asdCurrent = (int) current;
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                                            .setContentTitle("Uploading Files")
                                                            .setContentText("Upload in Progress")
                                                            .setOngoing(true)
                                                            .setOnlyAlertOnce(true)
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                            .setProgress(asd, asdCurrent, false).build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                                            .setSmallIcon(R.drawable.smiley)
                                                            .setContentTitle(" Failed")
                                                            .setContentText(" Message Send Failed ")
                                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                            .build();
                                                    notificationManagerCompat.notify(1, notification);
                                                }
                                            });
                                            ;
                                        }
                                    }
                                });
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                long max = taskSnapshot.getTotalByteCount();
                                long current = taskSnapshot.getBytesTransferred();
                                int asd = (int) max;
                                int asdCurrent = (int) current;
                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                        .setContentTitle("Uploading Files")
                                        .setContentText("Upload in Progress")
                                        .setOngoing(true)
                                        .setOnlyAlertOnce(true)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setProgress(asd, asdCurrent, false).build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Notification notification = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.smiley)
                                        .setContentTitle(" Failed")
                                        .setContentText(" Message Send Failed ")
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        });

                    }
                }
            } catch (Exception e) {
                Log.e("Error", e.toString());
            }
            return null;
        }
    }

    public class ReceiveThreadTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {

            if (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName != null) {
                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Threads").child(Friend_Key).addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        if (dataSnapshot.exists()) {
                            Intent intent = getIntent();
                            String key = Objects.requireNonNull(dataSnapshot.getKey());
                            String createDate = Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString();
                            String times = Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString();
                            threadsViewModel.insert(new Thread(key,
                                    intent.getStringExtra("name"),
                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                    LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                    createDate,
                                    times, recyclerviewThread.getItemCount()));
                        }

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            threadsViewModel.deleteThread(dataSnapshot.getKey());
                        }
                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }


            return null;
        }
    }

    public class ReceiveMessageTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            //SharedPreferences timestampPrefernces = getSharedPreferences("Timestamp", 0);
            if (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName != null) {
                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child("Mails").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Messages").child(Friend_Key).addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        if (dataSnapshot.exists()) {
                            Intent intent = getIntent();
                            if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(1))) {
                                messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                        intent.getStringExtra("name"),
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                        dataSnapshot.child("Create Date").getValue(String.class),
                                        dataSnapshot.child("Message").getValue(String.class),
                                        Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                        dataSnapshot.child("Timestamp").getValue(String.class),
                                        dataSnapshot.child("ThreadKey").getValue(String.class),
                                        "", null, null, false));
                            } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(2))) {
                                try {
                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());
                                    List<Files> fileUrls = new ArrayList<>();
                                    if (filesCount != 0) {
                                        for (int i = 1; i <= filesCount; i++) {
                                            Files files = new Files(Objects.requireNonNull(dataSnapshot.child("FileName" + i).getValue()).toString(),
                                                    Objects.requireNonNull(dataSnapshot.child("FileType" + i).getValue()).toString(),
                                                    Objects.requireNonNull(dataSnapshot.child("FileUrl" + i).getValue()).toString());
                                            fileUrls.add(files);
                                        }
                                        messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                                intent.getStringExtra("name"),
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                dataSnapshot.child("Create Date").getValue(String.class),
                                                dataSnapshot.child("Message").getValue(String.class),
                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                dataSnapshot.child("Timestamp").getValue(String.class),
                                                dataSnapshot.child("ThreadKey").getValue(String.class),
                                                "", null, fileUrls, false));
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(3))) {

                                try {
                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                    if (imagesCount != 0) {
                                        List<String> imageUrls = new ArrayList<>();
                                        for (int i = 1; i <= imagesCount; i++) {
                                            imageUrls.add(Objects.requireNonNull(dataSnapshot.child("ImageUrl" + i).getValue()).toString());
                                        }
                                        messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                                intent.getStringExtra("name"),
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                dataSnapshot.child("Create Date").getValue(String.class),
                                                dataSnapshot.child("Message").getValue(String.class),
                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                dataSnapshot.child("Timestamp").getValue(String.class),
                                                dataSnapshot.child("ThreadKey").getValue(String.class),
                                                "", imageUrls, null, false));
                                    }
                                } catch (Exception e) {
                                    Log.e("Error", e.toString());
                                }
                            } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(4))) {
                                try {
                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());

                                    List<String> imageUrls = new ArrayList<>();
                                    for (int i = 1; i <= imagesCount; i++) {
                                        imageUrls.add(Objects.requireNonNull(dataSnapshot.child("ImageUrl" + i).getValue()).toString());
                                    }
                                    List<Files> fileUrls = new ArrayList<>();
                                    for (int i = 1; i <= filesCount; i++) {
                                        Files files = new Files(Objects.requireNonNull(dataSnapshot.child("FileName" + i).getValue()).toString(),
                                                Objects.requireNonNull(dataSnapshot.child("FileType" + i).getValue()).toString(),
                                                Objects.requireNonNull(dataSnapshot.child("FileUrl" + i).getValue()).toString());
                                        fileUrls.add(files);
                                    }
                                    messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                            intent.getStringExtra("name"),
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                            dataSnapshot.child("Create Date").getValue(String.class),
                                            dataSnapshot.child("Message").getValue(String.class),
                                            Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                            dataSnapshot.child("Timestamp").getValue(String.class),
                                            dataSnapshot.child("ThreadKey").getValue(String.class),
                                            "", imageUrls, fileUrls, false));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }


                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        messageViewModel.updateMessageLikeCount(dataSnapshot.getKey(), Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())));
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            messageViewModel.deleteMessage(dataSnapshot.getKey());
                        }
                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }
            return null;
        }
    }

    public class ReceiveOwnMessageTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName != null) {
                FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)
                        .child("Mails")
                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("OwnMessages")
                        .child(Friend_Key).addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        if (dataSnapshot.exists()) {
                            Intent intent = getIntent();

                            if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(1))) {

                                messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                        intent.getStringExtra("name"),
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                        dataSnapshot.child("Create Date").getValue(String.class),
                                        dataSnapshot.child("Message").getValue(String.class),
                                        Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                        dataSnapshot.child("Timestamp").getValue(String.class),
                                        dataSnapshot.child("ThreadKey").getValue(String.class),
                                        "", null, null, true));
                            } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(2))) {
                                try {
                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());
                                    if (filesCount != 0) {
                                        List<Files> fileUrls = new ArrayList<>();
                                        for (int i = 1; i <= filesCount; i++) {
                                            Files files = new Files(Objects.requireNonNull(dataSnapshot.child("FileName" + i).getValue()).toString(),
                                                    Objects.requireNonNull(dataSnapshot.child("FileType" + i).getValue()).toString(),
                                                    Objects.requireNonNull(dataSnapshot.child("FileUrl" + i).getValue()).toString());
                                            fileUrls.add(files);
                                        }
                                        messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                intent.getStringExtra("name"),
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                dataSnapshot.child("Create Date").getValue(String.class),
                                                dataSnapshot.child("Message").getValue(String.class),
                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                dataSnapshot.child("Timestamp").getValue(String.class),
                                                dataSnapshot.child("ThreadKey").getValue(String.class),
                                                "", null, fileUrls, true));
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(3))) {

                                try {
                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                    List<String> imageUrls = new ArrayList<>();
                                    if (imagesCount != 0) {
                                        for (int i = 1; i <= imagesCount; i++) {
                                            imageUrls.add(Objects.requireNonNull(dataSnapshot.child("ImageUrl" + i).getValue()).toString());
                                        }
                                        messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                                intent.getStringExtra("name"),
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                                LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                                dataSnapshot.child("Create Date").getValue(String.class),
                                                dataSnapshot.child("Message").getValue(String.class),
                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                dataSnapshot.child("Timestamp").getValue(String.class),
                                                dataSnapshot.child("ThreadKey").getValue(String.class),
                                                "", imageUrls, null, true));
                                    }
                                } catch (Exception e) {
                                    Log.e("Error", e.toString());
                                }
                            } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(4))) {
                                try {
                                    List<Files> fileUrls = new ArrayList<>();
                                    List<String> imageUrls = new ArrayList<>();
                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());
                                    for (int i = 1; i <= imagesCount; i++) {
                                        imageUrls.add(Objects.requireNonNull(dataSnapshot.child("ImageUrl" + i).getValue()).toString());
                                    }
                                    for (int i = 1; i <= filesCount; i++) {
                                        Files files = new Files(Objects.requireNonNull(dataSnapshot.child("FileName" + i).getValue()).toString(),
                                                Objects.requireNonNull(dataSnapshot.child("FileType" + i).getValue()).toString(),
                                                Objects.requireNonNull(dataSnapshot.child("FileUrl" + i).getValue()).toString());
                                        fileUrls.add(files);
                                    }
                                    messageViewModel.insert(new Message(Objects.requireNonNull(dataSnapshot.child("MessageKey").getValue(String.class)),
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname,
                                            intent.getStringExtra("name"),
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey,
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                            dataSnapshot.child("Create Date").getValue(String.class),
                                            dataSnapshot.child("Message").getValue(String.class),
                                            Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                            dataSnapshot.child("Timestamp").getValue(String.class),
                                            dataSnapshot.child("ThreadKey").getValue(String.class),
                                            "", imageUrls, fileUrls, true));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        messageViewModel.updateMessageLikeCount(dataSnapshot.getKey(), Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())));
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            messageViewModel.deleteMessage(dataSnapshot.getKey());
                        }
                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        if (text_editor_edit.hasFocus()) {
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(text_editor_edit.getWindowToken(), 0);
            text_editor_edit.clearFocus();
        }
        else if (bsEditText.hasFocus()) {
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(bsEditText.getWindowToken(), 0);
            bsEditText.clearFocus();
        }
        else if (bottomSheetBehaviorSchedule.getState() != BottomSheetBehavior.STATE_HIDDEN) {
            event_edit.clearFocus();
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(event_edit.getWindowToken(), 0);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_HIDDEN);
                }
            }, 600);
        } else if (bottomSheetBehavior_copy_delete.getState() != BottomSheetBehavior.STATE_HIDDEN) {
            bottomSheetBehavior_copy_delete.setState(BottomSheetBehavior.STATE_HIDDEN);
        }else if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_HIDDEN) {
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        } else {
            super.onBackPressed();
            new color().execute();
        }

    }

    private void initInputField() {
        // Let the layout know we are going to be overriding the back button
        MyRelativeLayout.ThisActivity(this);
    }

    public static float dpToPx(Context context, float valueInDp) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, valueInDp, metrics);
    }


    //Scheduler Functions
    public void ScheduleListeners() {
        start_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog dialog = new TimePickerDialog(ChatFinalActivity.this, listener, schedule.getStartTime().getHour(), schedule.getStartTime().getMinute(), false);
                dialog.show();
            }

            private TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    String hour;
                    String min;
                    if (hourOfDay < 10) {
                        hour = "0" + hourOfDay;
                    } else {
                        hour = String.valueOf(hourOfDay);
                    }
                    if (minute < 10) {
                        min = "0" + minute;
                    } else {
                        min = String.valueOf(minute);
                    }
                    String text = hour + ":" + min;
                    start_time.setText(text);
                    schedule.getStartTime().setHour(hourOfDay);
                    schedule.getStartTime().setMinute(minute);
                }
            };
        });
        end_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog dialog = new TimePickerDialog(ChatFinalActivity.this, listener, schedule.getEndTime().getHour(), schedule.getEndTime().getMinute(), false);
                dialog.show();
            }

            private TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    String hour;
                    String min;
                    if (hourOfDay < 10) {
                        hour = "0" + String.valueOf(hourOfDay);
                    } else {
                        hour = String.valueOf(hourOfDay);
                    }
                    if (minute < 10) {
                        min = "0" + String.valueOf(minute);
                    } else {
                        min = String.valueOf(minute);
                    }
                    String text = hour + ":" + min;
                    end_time.setText(text);
                    schedule.getEndTime().setHour(hourOfDay);
                    schedule.getEndTime().setMinute(minute);

                }
            };
        });
        calendar_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                //Find the currently focused view, so we can grab the correct window token from it.
                schedule_calendar_view.setVisibility(View.VISIBLE);
                imm.hideSoftInputFromWindow(event_edit.getWindowToken(), 0);
            }
        });
        schedule_calendar_view.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                SetDate(dayOfMonth, month, year);
                day = year * 10000 + (month + 1) * 100 + dayOfMonth;
            }
        });
        add_schedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (event_edit.getText().toString().trim().length() > 0) {
                    String uniqueId = UUID.randomUUID().toString();
                    scheduleViewModel.insert(new com.shubham.signuppage.Room.Schedule(uniqueId,
                            event_edit.getText().toString(),
                            day,
                            schedule.getStartTime().getHour(),
                            schedule.getStartTime().getMinute(),
                            schedule.getEndTime().getHour(),
                            schedule.getEndTime().getMinute(),
                            LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceKey,
                            LocalUserService.getLocalUserFromPreferences(ChatFinalActivity.this).CurrentWorkplaceName));
                    bottomSheetBehaviorSchedule.setState(BottomSheetBehavior.STATE_HIDDEN);
                } else {
                    Toast.makeText(ChatFinalActivity.this, "Field cannot be blank.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    //Scheduler Functions
    public void SetDate(int day_of_month, int mon, int year) {
        String day = String.valueOf(day_of_month);
        if (day_of_month < 10) {
            day = "0" + day;
        }
        String month = String.valueOf(mon + 1);
        if (mon + 1 < 10) {
            month = "0" + month;
        }
        String currentDate = " " + day + "/" + month + "/" + String.valueOf(year) + " ";
        calendar_date.setText(currentDate);
    }

    //Scheduler Functions
    public void SetStartTime_EndTime() {
        String startTime = new MyCalendar().StartTime();
        String endTime = new MyCalendar().EndTime();
        start_time.setText(startTime);
        end_time.setText(endTime);
    }

}
