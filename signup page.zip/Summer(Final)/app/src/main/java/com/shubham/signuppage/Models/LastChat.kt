package com.shubham.signuppage.Models

class LastChat {
    @JvmField
    var Phone: String? = null
    @JvmField
    var Key: String? = null
    @JvmField
    var Message: String? = null
    @JvmField
    var SentDate: String? = null
    @JvmField
    var FriendFullName: String? = null
    @JvmField
    var rowid = 0
    @JvmField
    var ImageUrl: String? = null
}