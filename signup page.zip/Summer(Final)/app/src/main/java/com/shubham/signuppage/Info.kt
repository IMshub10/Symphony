package com.shubham.signuppage

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.shubham.signuppage.Services.LocalUserService
import java.util.*

class Info : AppCompatActivity() {
    var imageName = UUID.randomUUID().toString() + ".jpg"
    var database: FirebaseDatabase? = null
    var storage: FirebaseStorage? = null
    var auth: FirebaseAuth? = null
    var databaseReference: DatabaseReference? = null
    var sharedPreferences: SharedPreferences? = null
    var f_name: EditText? = null
    var l_name: EditText? = null
    var profImageView: ImageView? = null
    var next: Button? = null
    private var downloadUrl: String? = null
    var ref: StorageReference? = null
    var phoneNo: String? = null
    var first: String? = null
    var last: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId == true) {
            setTheme(R.style.Info_Dark);
        } else {
            setTheme(R.style.AppTheme);
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)
        //Firebase initialization
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        databaseReference = database!!.reference
        storage = FirebaseStorage.getInstance()
        //Input
        f_name = findViewById(R.id.f_name)
        l_name = findViewById(R.id.l_name)
        profImageView = findViewById(R.id.prof)
        next = findViewById(R.id.button)
        downloadUrl = ""
        sharedPreferences = getSharedPreferences("LocalUser", 0)
    }
/*

//    fun choose(view: View?) {
//        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
//            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
//        } else {
//            photo
//        }
//    }

//    val photo: Unit
//        get() {
//            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//            startActivityForResult(intent, 1)
//        }
//
//    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (requestCode == 1) {
//            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                photo
//            }
//        }
//    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        imageFile = data!!.data
//        if (requestCode == 1 && resultCode == Activity.RESULT_OK && data != null) {
//            try {
//                val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, imageFile)
//                profImageView!!.setImageBitmap(bitmap)
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }
//    }

 */

    fun start(view: View?) {}
    fun upload(view: View?) {
        first = f_name!!.text.toString().trim()
        last = l_name!!.text.toString()
        if ( first != "" && last != "") {

            val intent = intent
                    val code = intent.getStringExtra("countrycode")
            val phone = intent.getStringExtra("phone")
            databaseReference!!.child("Users").child(auth!!.currentUser!!.uid).child("Phone number").setValue(code + phone)
            databaseReference!!.child("Users").child(auth!!.currentUser!!.uid).child("F_Name").setValue(f_name!!.text.toString())
            databaseReference!!.child("Users").child(auth!!.currentUser!!.uid).child("L_Name").setValue(l_name!!.text.toString())
            sharedPreferences!!.edit().putString("FirstName", f_name!!.text.toString()).apply()
            sharedPreferences!!.edit().putString("LastName", l_name!!.text.toString()).apply()
            sharedPreferences!!.edit().putString("FullName",f_name!!.text.toString()+" "+l_name!!.text.toString()).apply()
            sharedPreferences!!.edit().putString("Key",auth!!.currentUser!!.uid).apply()
            val intent1 = Intent(this@Info, Main3Activity::class.java)
            startActivity(intent1)

        } else {
            Toast.makeText(this, "Name cannot be blank.", Toast.LENGTH_SHORT).show()
        }
    }
/*
//    private fun uploadImage(imageFile: Uri) {
//        progressDialog = ProgressDialog(this)
//        progressDialog!!.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
//        progressDialog!!.setTitle("Uploading File")
//        progressDialog!!.progress = 0
//        progressDialog!!.show()
//        ref = storage!!.reference.child("Users").child(f_name!!.text.toString() + "" + l_name!!.text.toString())
//        ref!!.putFile(imageFile).addOnSuccessListener {
//            progressDialog!!.dismiss()
//            ref!!.downloadUrl.addOnSuccessListener { uri ->
//                downloadUrl = uri.toString()
//                first = f_name!!.text.toString()
//                last = l_name!!.text.toString()
//                if (first != "" && last != "") {
//                    val intent = intent
//                    val code = intent.getStringExtra("countrycode")
//                    val phone = intent.getStringExtra("phone")
//                    databaseReference!!.child("Users").child(auth!!.currentUser!!.uid)
//                            .child("Phone number").setValue(code + phone)
//                    databaseReference!!.child("Users").child(auth!!.currentUser!!.uid).child("F_Name").setValue(f_name!!.text.toString())
//                    databaseReference!!.child("Users").child(auth!!.currentUser!!.uid).child("L_Name").setValue(l_name!!.text.toString())
//                    databaseReference!!.child("Users").child(auth!!.currentUser!!.uid).child("Profile Image").setValue(downloadUrl)
//                    sharedPreferences!!.edit().putString("FirstName", f_name!!.text.toString()).apply()
//                    sharedPreferences!!.edit().putString("LastName", l_name!!.text.toString()).apply()
//                    sharedPreferences!!.edit().putString("FullName",f_name!!.text.toString()+" "+l_name!!.text.toString()).apply()
//                    sharedPreferences!!.edit().putString("ImageUrl", downloadUrl).apply()
//                    sharedPreferences!!.edit().putString("Key",auth!!.currentUser!!.uid).apply()
//                    val intent1 = Intent(this@Info, Main3Activity::class.java)
//                    startActivity(intent1)
//                } else {
//                    Toast.makeText(applicationContext, "Pls add Image & Name", Toast.LENGTH_SHORT).show()
//                }
//            }
//        }.addOnFailureListener { Toast.makeText(this@Info, "Inside failure to store file", Toast.LENGTH_SHORT).show() }
//                .addOnProgressListener { taskSnapshot ->
//            val currentProgress = (100 * taskSnapshot.bytesTransferred / taskSnapshot.totalByteCount).toInt()
//            progressDialog!!.progress = currentProgress
//        }.addOnCompleteListener { }
//    }

 */

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this@Info, Main2Activity::class.java)
        startActivity(intent)
        super.onBackPressed()
    }
}