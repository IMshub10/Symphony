package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class GroupThreadsViewModel extends AndroidViewModel {
    private  GroupThreadRepository groupThreadRepository;
    private LiveData<List<GroupThread>> allThreads;

    public GroupThreadsViewModel(@NonNull Application application) {
        super(application);
        groupThreadRepository = new GroupThreadRepository(application);
    }

    public  void  deleteThread(String threadId){
        groupThreadRepository.deleteThread(threadId);
    }
    public  void  insert(GroupThread groupThread){
        groupThreadRepository.insert(groupThread);
    }
    public  void  update(GroupThread groupThread){
        groupThreadRepository.update(groupThread);
    }
    public  void  delete(GroupThread groupThread){
        groupThreadRepository.delete(groupThread);
    }
    public  void deleteall(){
        groupThreadRepository.deleteAllThreads();
    }
    public  LiveData<List<GroupThread>> getAllThreads(String workKey,String work,String receiverid){
        allThreads = groupThreadRepository.getAllThread(workKey,work,receiverid);
        return  allThreads;
    }
    public  void  updatePositionsOfThread(String threadId,int position){
        groupThreadRepository.updatePositionsOfThread(threadId,position);
    }
}

