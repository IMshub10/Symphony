package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ThreadsViewModel extends AndroidViewModel {
    private  ThreadRepository threadRepository;
    private LiveData<List<Thread>> allThreads;

    public ThreadsViewModel(@NonNull Application application) {
        super(application);

        threadRepository = new ThreadRepository(application);

    }

    public  void  deleteThread(String threadId){
        threadRepository.deleteThread(threadId);
    }
    public  void  insert(Thread thread){
        threadRepository.insert(thread);
    }
    public  void  update(Thread thread){
        threadRepository.update(thread);
    }
    public  void  delete(Thread thread){
        threadRepository.delete(thread);
    }
    public  void deleteall(){
        threadRepository.deleteAllThreads();
    }
    public  LiveData<List<Thread>> getAllThreads(String workKey, String work, String sender,String receiver){
        allThreads = threadRepository.getAllThread(workKey,work,sender,receiver);
        return  allThreads;
    }
    public int getThread(String threaId){
        return  threadRepository.getThread(threaId);
    }

    public  List<Thread> getAllThreadss(String work, String sender,String receiver,int position){

        return  threadRepository.getAllThreads(work,sender,receiver,position);
    }
    public  void  updatePositionsOfThread(String threadId,int position){
        threadRepository.updatePositionsOfThread(threadId,position);
    }
}
