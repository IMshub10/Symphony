package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class GroupsRepository {
    private GroupsDao groupsDao;
    private LiveData<List<Groups>> allgroups;
    int count;

    public GroupsRepository(Application application) {
        GroupsDatabase groupsDatabase = GroupsDatabase.getInstance(application);
        groupsDao = groupsDatabase.groupsDao();
    }

    public  void insert(Groups groups){
        new InsertGroupsTask(groupsDao).execute(groups);
    }
    public  void delete(Groups groups){
        new DeleteGroupsTask(groupsDao).execute(groups);
    }
    public  void update(Groups groups){
        new UpdateGroupTask(groupsDao).execute(groups);
    }
    public  void deleteAllGroups(){
        new DeleteAllGroupsTask(groupsDao).execute();
    }
    public  LiveData<List<Groups>> getAllGroups(String work){
        allgroups = groupsDao.getAllGroups(work);
        return  allgroups;
    }
    public int checkGroupAlreadyExists(String groupKey,String work){
        return  groupsDao.checkGroupAlreadyExists(groupKey, work);
    }
    public  void  deleteGroup(String id){
        new DeleteGroupTask(groupsDao).execute(id);
    }

    public void updateMember(String key,String message,int messageCount,String createDate,String timestamp){

        new UpdateMemberIdTask(groupsDao,key,message,messageCount,createDate,timestamp).execute();
    }
    public void updateMemberMessage(String key,String message,String createDate,String timestamp){

        new UpdateMemberCountTask(groupsDao,key,message,createDate,timestamp).execute();
    }
    public void updateMemberMess(String key,int messageCount){

        new UpdateMemberMessageTask(groupsDao,key,messageCount).execute();
    }

    private  static  class UpdateMemberIdTask extends  AsyncTask<String,Void,Void>{
        private GroupsDao groupsDao;
        private String message;
        private String key;
        private String createDate;
        private int messageCount;
        private String timestamp;
        public UpdateMemberIdTask(GroupsDao groupsDao,String key,String message,int messageCount,String createDate,String timestamp){
            this.groupsDao = groupsDao;
            this.message = message;
            this.key = key;
            this.messageCount = messageCount;
            this.createDate=createDate;
            this.timestamp = timestamp;
        }

        @Override
        protected Void doInBackground(String... strings) {
            groupsDao.updateMember(key,message,messageCount,createDate,timestamp);
            return null;
        }
    }
    private  static  class UpdateMemberMessageTask extends  AsyncTask<String,Void,Void>{
        private GroupsDao groupsDao;
        private String message;
        private String key;
        private int messageCount;
        public UpdateMemberMessageTask(GroupsDao groupsDao,String key,int messageCount){
            this.groupsDao = groupsDao;
            this.message = message;
            this.key = key;
        }

        @Override
        protected Void doInBackground(String... strings) {
            groupsDao.updateMemberMessage(key,messageCount);
            return null;
        }
    }
    private  static  class UpdateMemberCountTask extends  AsyncTask<String,Void,Void>{
        private GroupsDao groupsDao;
        private String message;
        private String key;
        private String createDate;
        private String timestamp;
        public UpdateMemberCountTask(GroupsDao groupsDao,String key,String message,String createDate,String timestamp){
            this.groupsDao = groupsDao;
            this.message = message;
            this.key = key;
            this.createDate = createDate;
            this.timestamp = timestamp;
        }

        @Override
        protected Void doInBackground(String... strings) {
            groupsDao.updateMemberMessageCOunt(key,message,createDate,timestamp);
            return null;
        }
    }

    private  static  class DeleteGroupTask extends  AsyncTask<String,Void,Void>{

        private GroupsDao groupsDao;
        private  DeleteGroupTask(GroupsDao groupsDao){
            this.groupsDao = groupsDao;
        }

        @Override
        protected Void doInBackground(String... strings) {
            groupsDao.deleteGroup(strings[0]);
            return null;
        }

    }

    private class InsertGroupsTask extends AsyncTask<Groups,Void,Void> {

        private GroupsDao groupsDao;
        public InsertGroupsTask(GroupsDao groupsDao) {
            this.groupsDao = groupsDao;
        }

        @Override
        protected Void doInBackground(Groups... groups) {
            groupsDao.insert(groups[0]);
            return null;
        }
    }

    private class DeleteGroupsTask extends AsyncTask<Groups,Void,Void>{

        private GroupsDao groupsDao;
        public DeleteGroupsTask(GroupsDao groupsDao) {
            this.groupsDao = groupsDao;
        }

        @Override
        protected Void doInBackground(Groups... groups) {
            groupsDao.delete(groups[0]);
            return null;
        }
    }

    private class UpdateGroupTask extends AsyncTask<Groups,Void,Void>{

        private GroupsDao groupsDao;
        public UpdateGroupTask(GroupsDao groupsDao) {
            this.groupsDao = groupsDao;
        }

        @Override
        protected Void doInBackground(Groups... groups) {
            groupsDao.update(groups[0]);
            return null;
        }
    }

    private class DeleteAllGroupsTask extends AsyncTask<Void,Void,Void>{

        private GroupsDao groupsDao;
        public DeleteAllGroupsTask(GroupsDao groupsDao) {
            this.groupsDao = groupsDao;
        }
        @Override
        protected Void doInBackground(Void... voids) {
            groupsDao.deleteAllGroups();
            return null;
        }
    }
}
