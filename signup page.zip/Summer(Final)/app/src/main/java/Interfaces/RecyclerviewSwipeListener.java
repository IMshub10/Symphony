package Interfaces;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public interface RecyclerviewSwipeListener {
    void onItemClick(View view, int position);
    void  onLongItemClick(View view,int position);
    void  onSwipeRight(RecyclerView recyclerView,View view, int layoutPosition,int swipePosition);
    void  onSwipeLeft(RecyclerView recyclerView,View view, int layoutPosition,int swipePosition);
}
