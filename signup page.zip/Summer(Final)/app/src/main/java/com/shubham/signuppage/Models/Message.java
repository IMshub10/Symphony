package com.shubham.signuppage.Models;

public class Message {
    public String Name;
    public String FromPhone;
    public String ToPhone;
    public String Message;
    public String SentDate;
    public String FriendFullName;


    public int rowid;

}
