package com.shubham.signuppage.TableBuilder;

import java.io.Serializable;

public class Schedule implements Serializable {
    static final int MON = 0;
    static final int TUE = 1;
    static final int WED = 2;
    static final int THU = 3;
    static final int FRI = 4;
    static final int SAT = 5;
    static final int SUN = 6;

    String event="";
    private int day = 0;
    private Time startTime;
    private Time endTime;

    public Schedule() {
        this.startTime = new Time();
        this.endTime = new Time();
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public Time getStartTime() {
        return startTime;
    }

    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

    public Schedule(String event, int day, Time startTime, Time endTime) {
        this.event = event;
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
    }
}
