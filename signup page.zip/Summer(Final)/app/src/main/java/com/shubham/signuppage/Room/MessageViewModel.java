package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class MessageViewModel extends AndroidViewModel {

    private  MessageRepository messageRepository;
    private LiveData<List<Message>> allMessages;

    public MessageViewModel(@NonNull Application application) {
        super(application);
        messageRepository = new MessageRepository(application);
    }
    public List<Message> getThreadMessages(String threadId){
        return messageRepository.getThreadMessages(threadId);
    };

    public List<Message> getMessages(String work,String sender,String receiver,String contains) {
        return messageRepository.getMessages( work, sender, receiver, contains);
    }

    public  void  deleteMessage(String messageId){
        messageRepository.deleteMessage(messageId);
    }
    public  void  insert(Message message){
        messageRepository.insert(message);
    }
    public  void  update(Message message){
        messageRepository.update(message);
    }
    public  void  delete(Message message){
        messageRepository.delete(message);
    }
    public  void deleteall(){
        messageRepository.deleteAllThreads();
    }
    public  LiveData<List<Message>> getAllMessages(String workKey,String work, String sender, String receiver,String threadId){
        allMessages = messageRepository.getAllMessages(workKey,work,sender,receiver,threadId);
        return  allMessages;
    }

    public List<Message> getMessagess(String work,String sender,String receiver) {
        return messageRepository.getMessagess( work, sender, receiver);
    }
    public  void updateMessageLikeCount(String asKey,int likes){
        messageRepository.updateMessageLikeCount(asKey,likes);
    }
    public  void  updateRead(String work,String sender,String receiver,Boolean read){
        messageRepository.updateRead( work, sender, receiver, read);
    }
    public  int getThreadMessageCount(String threadId){
        return  messageRepository.getThreadMessageCount(threadId);
    }

}

