package com.shubham.signuppage.Chat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.shubham.signuppage.R;
import Interfaces.RecyclerViewItemClickListener;
import com.shubham.signuppage.Room.GroupMessage;
import com.shubham.signuppage.Room.GroupMessageViewModel;
import com.shubham.signuppage.Room.Message;
import com.shubham.signuppage.Room.MessageViewModel;
import com.shubham.signuppage.Room.SearchMessage;
import com.shubham.signuppage.Room.SearchMessageViewModel;
import com.shubham.signuppage.Room.ThreadsViewModel;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.ml.QaAnswer;
import com.shubham.signuppage.ml.QaClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SearchActivity extends AppCompatActivity {

    Toolbar toolbarSearchActivity;
    SearchView searchView;
    private ThreadsViewModel threadsViewModel;
    private MessageViewModel messageViewModel;
    private GroupMessageViewModel groupMessageViewModel;

    String currentWorkplace,currentWorkplaceKey;
    String sender;
    String me;
    String activity;


    TextView searchCount;
    private static final String QUESTIONS_PATH = "Questions.txt";
    private static final String PREPOSITIONS_PATH = "Prepositions.txt";
    List<String> questions_list = new ArrayList<>();
    List<String> prepositions_list = new ArrayList<>();
    //List<String> query_words_list = new ArrayList<>();
    //List<String> keyword_list = new ArrayList<>();
    // List<String> answers_list = new ArrayList<>();
    //List<String> contains_answers_list = new ArrayList<>();
    private Handler handler;
    private QaClient qaClient;
    private boolean questionAnswered = false;
    private LinearLayout search_parent;
    private static final boolean DISPLAY_RUNNING_TIME = false;
    SearchMessageViewModel searchMessageViewModel;

    int sx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            setTheme(R.style.MainActivity3_Dark);
        else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_search);
        me = LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Fullname;
        toolbarSearchActivity = findViewById(R.id.toolbarSearchActivity);
        setSupportActionBar(toolbarSearchActivity);
        searchCount = findViewById(R.id.searchCount);
        try {
            getSupportActionBar().setTitle(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        View toolView = toolbarSearchActivity.getRootView();
        ImageView search_toolbar_navigation = toolView.findViewById(R.id.search_toolbar_navigation);
        //CircleImageView circleImageView = toolView.find
        search_parent = findViewById(R.id.search_parent);
        TextView textView = toolView.findViewById(R.id.searchText);
        textView.setText("Search");
        search_toolbar_navigation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        RecyclerView recyclerView = findViewById(R.id.search_recyclerview);

        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayout.VERTICAL));
        threadsViewModel = ViewModelProviders.of(this).get(ThreadsViewModel.class);
        messageViewModel = ViewModelProviders.of(this).get(MessageViewModel.class);
        groupMessageViewModel = ViewModelProviders.of(this).get(GroupMessageViewModel.class);
        searchMessageViewModel = ViewModelProviders.of(this).get(SearchMessageViewModel.class);
        currentWorkplace = LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName;
        currentWorkplaceKey = LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey;
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        RecyclerViewSearch recyclerViewSearch = new RecyclerViewSearch(this);
        recyclerView.setAdapter(recyclerViewSearch);
        Intent intent = getIntent();
        sender = intent.getStringExtra("Sender");
        activity = intent.getStringExtra("Activity");
        if (activity.equals("Mails")){
            searchMessageViewModel.getAllMessages(currentWorkplaceKey, sender, me).observe(this, new Observer<List<SearchMessage>>() {
                @Override
                public void onChanged(List<SearchMessage> searchMessages) {
                    recyclerViewSearch.submitList(searchMessages);

                }
            });
        }else if(activity.equals("Groups")){
            searchMessageViewModel.getMessages(currentWorkplaceKey,sender).observe(this, new Observer<List<SearchMessage>>() {
                @Override
                public void onChanged(List<SearchMessage> searchMessages) {
                    recyclerViewSearch.submitList(searchMessages);
                }
            });
        }

        recyclerViewSearch.setOnItemClickListener(new RecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent returnIntent = new Intent();
                returnIntent.putExtra("MessageKey",recyclerViewSearch.getItem(position).getThreadId());
                setResult(Activity.RESULT_OK, returnIntent);
                finish();
            }
            @Override
            public void onLongItemClick(View view, int position) {
            }
        });


        loadQuestionsDictionary();
        loadPrepositionsDictionary();
        HandlerThread handlerThread = new HandlerThread("QAClient");
        handlerThread.start();
        handler = new Handler(handlerThread.getLooper());
        qaClient = new QaClient(this);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.getMenuInflater().inflate(R.menu.search_menu, menu);
        MenuItem myActionMenuItem = menu.findItem(R.id.search_thread);
        searchView = (SearchView) myActionMenuItem.getActionView();
        myActionMenuItem.expandActionView();
        searchView.setQueryHint("Search here");
        searchView.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    searchMessageViewModel.deleteall();
                }
            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Toast like print
                    queryFunction(query);
                //myActionMenuItem.collapseActionView();

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        return true;
    }

    private void queryFunction(String query) {
        searchView.clearFocus();
        String question = query.trim().toLowerCase();
        if (!question.equals("")) {
            String questionmark = question.substring(question.length() - 1);
            Log.e("Question Mark", questionmark);

            if (question.substring(question.length() - 1).equals("?")) {
                question = question.substring(0, question.length() - 1);
            }
            question = question + " ";
            List<String> query_words_list = new ArrayList<>();
            List<String> keyword_list = new ArrayList<>();
            query_words_list.clear();
            int z = 0;
            while (question.length() != 0) {
                int index = question.indexOf(" ");
                query_words_list.add(z, question.substring(0, index).trim());
                int length = question.length();
                question = question.substring(index + 1, length);
                Log.e("index", query_words_list.get(z));
            }
            if (questionmark.equals("?") || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(0)) || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(1))
                    || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(2)) || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(3))
                    || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(4)) || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(5))
                    || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(6)) || query_words_list.get(query_words_list.size() - 1).equals(questions_list.get(7))) {


                for (int j = 0; j < query_words_list.size(); j++) {
                    for (int i = 0; i < prepositions_list.size(); i++) {
                        if (prepositions_list.get(i).equals(query_words_list.get(j))) {
                            break;
                        } else {
                            if (prepositions_list.size() - 1 == i) {
                                //last.append(list2.get(z)).append(" ");
                                keyword_list.add(query_words_list.get(j));
                            }
                        }
                    }
                }
                if (keyword_list.size() != 0) {
                    if (activity.equals("Mails")){
                        new GetMessagessTask(keyword_list, query).execute();
                    }else if(activity.equals("Groups")){
                       new   GetGroupMessagessTask(keyword_list, query).execute();
                    }
                }
            } else {
                if (activity.equals("Mails")){
                    new GetMessagesTask(query.trim()).execute();
                }else if (activity.equals("Groups")){
                    new GetGroupMessageTask(query.trim()).execute();
                }

            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = getIntent();

        handler.post(
                () -> {
                    qaClient.loadModel();
                    qaClient.loadDictionary();
                });
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.post(() -> qaClient.unload());
    }

    public class GetGroupMessageTask extends AsyncTask<Void,Void,List<GroupMessage>>{

        private String contains;

        public GetGroupMessageTask(String contains) {
            this.contains = contains;
        }
        @Override
        protected List<GroupMessage> doInBackground(Void... voids) {
            List<GroupMessage> groupMessages = new ArrayList<>();
            groupMessages = groupMessageViewModel.getMessages(currentWorkplace,sender,contains);
            //Toast.makeText(SearchActivity.this,String.valueOf(messages.size()),Toast.LENGTH_SHORT).show();
            Log.e("Size", String.valueOf(groupMessages.size()));
            return groupMessages ;
        }

        @Override
        protected void onPostExecute(List<GroupMessage> groupMessages) {
            super.onPostExecute(groupMessages);
            Log.e("Size", String.valueOf(groupMessages.size()));
            for (int i = 0; i < groupMessages.size(); i++) {
                GroupMessage groupMessage = groupMessages.get(i);
                String uniquid = UUID.randomUUID().toString();
                searchMessageViewModel.insert(new SearchMessage(uniquid,
                        groupMessage.getSender(),
                        groupMessage.getGroup_receiverId(),
                        currentWorkplaceKey,
                        currentWorkplace,
                        groupMessage.getCreate_date(),
                        groupMessage.getMessage_text(),
                        String.valueOf(groupMessage.getLikes()),
                        groupMessage.getTimestamp(),
                        groupMessage.getThreadId(),
                        contains));
                Log.e("Insert", "Inserted");
            }

            searchCount.setVisibility(View.VISIBLE);
            searchCount.setText("  " + String.valueOf(groupMessages.size()) + " Results Found" + "  ");
        }
    }
    public class GetMessagesTask extends AsyncTask<Void, Void, List<Message>> {

        private String contains;

        public GetMessagesTask(String contains) {
            this.contains = contains;
        }

        @Override
        protected List<Message> doInBackground(Void... voids) {
            List<Message> messages = new ArrayList<>();
            messages = messageViewModel.getMessages(currentWorkplace, sender, me, contains);
            //Toast.makeText(SearchActivity.this,String.valueOf(messages.size()),Toast.LENGTH_SHORT).show();
            Log.e("Size", String.valueOf(messages.size()));
            return messages;
        }

        @Override
        protected void onPostExecute(List<Message> messages) {
            super.onPostExecute(messages);

            Log.e("Size", String.valueOf(messages.size()));
            for (int i = 0; i < messages.size(); i++) {
                Message message = messages.get(i);
                String uniquid = UUID.randomUUID().toString();
                searchMessageViewModel.insert(new SearchMessage(uniquid,
                        message.getSender(),
                        message.getReceiver(),
                        currentWorkplaceKey,
                        currentWorkplace,
                        message.getCreate_date(),
                        message.getMessage_text(),
                        String.valueOf(message.getLikes()),
                        message.getTimestamp(),
                        message.getThreadId(),
                        contains));
                Log.e("Insert", "Inserted");
            }

            searchCount.setVisibility(View.VISIBLE);
            searchCount.setText("  " + String.valueOf(messages.size()) + " Results Found" + "  ");
            /*
            recyclerViewSearch.setOnItemClickListener(new RecyclerViewItemClickListener() {
                @Override
                public void onItemClick(View view, int position) {
                    //Toast.makeText(SearchActivity.this,String.valueOf(position), Toast.LENGTH_SHORT).show();
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("MessageKey",recyclerViewSearch.getItem(position).getThreadId());
                    setResult(Activity.RESULT_OK, returnIntent);
                    finish();
                }

                @Override
                public void onLongItemClick(View view, int position) {

                }
            });

             */

        }
    }
    public class GetGroupMessagessTask extends AsyncTask<Void, Void, List<GroupMessage>> {


        private List<String> keyword_list;
        private String query;

        public GetGroupMessagessTask(List<String> keyword_list, String query) {
            this.keyword_list = keyword_list;
            this.query = query;
        }


        @Override
        protected List<GroupMessage> doInBackground(Void... voids) {
            List<GroupMessage> groupMessages = new ArrayList<>();
            groupMessages = groupMessageViewModel.getMess(currentWorkplace, sender);
            //Toast.makeText(SearchActivity.this,String.valueOf(messages.size()),Toast.LENGTH_SHORT).show();
            Log.e("Size", String.valueOf(groupMessages.size()));
            return groupMessages;
        }

        @Override
        protected void onPostExecute(List<GroupMessage> groupMessages) {
            super.onPostExecute(groupMessages);


            List<GroupMessage> contains_message_list = new ArrayList<>();
            Log.e("Size", String.valueOf(groupMessages.size()));


            for (int j = groupMessages.size() - 1; j >= 0; j--) {
                for (int i = 0; i < keyword_list.size(); i++) {
                    if (!groupMessages.get(j).getMessage_text().toLowerCase().contains(keyword_list.get(i))) {
                        break;
                    } else {
                        if (keyword_list.size() - 1 == i) {
                            contains_message_list.add(groupMessages.get(j));

                            //answers_list.add(messages.get(j).getMessage_text());
                            searchCount.setVisibility(View.VISIBLE);
                            searchCount.setText("  " + String.valueOf(contains_message_list.size()) + " Results Found" + "  ");
                        }
                    }
                }
            }
            sx = 0;
            for (sx = 0; sx < contains_message_list.size(); sx++) {
                answerGroupQuestion(query, contains_message_list.get(sx));
            }

        }
    }
    private void answerGroupQuestion(String question, GroupMessage message) {
        question = question.trim();
        if (question.isEmpty()) {
            // question_edit.setText(question);
            return;
        }

        // Append question mark '?' if not ended with '?'.
        // This aligns with question format that trains the model.
        if (!question.endsWith("?")) {
            question += '?';
        }
        final String questionToAsk = question;
        //question_edit.setText(questionToAsk);

        // Delete all pending tasks.
        //handler.removeCallbacksAndMessages(null);

        // Hide keyboard and dismiss focus on text edit.
        InputMethodManager imm =
                (InputMethodManager) getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
        View focusView = getCurrentFocus();
        if (focusView != null) {
            focusView.clearFocus();
        }

        // Reset content text view
        //textV.setText(content);



        Snackbar runningSnackbar = Snackbar.make(search_parent, "Looking up answer...", BaseTransientBottomBar.LENGTH_SHORT);
        runningSnackbar.show();

        // Run TF Lite model to get the answer.
        handler.post(
                () -> {
                    final List<QaAnswer> answers = qaClient.predict(questionToAsk, message.getMessage_text());
                    if (!answers.isEmpty()) {
                        // Get the top answer

                        Log.e("Insert", "Inserted");

                        // Show the answer.
                        runOnUiThread(
                                () -> {
                                    /*
                                    if (!answers.get(1).text.equals("")) {
                                        textView1.setText(answers.get(1).text);
                                    }if (!answers.get(2).text.equals("")) {
                                        textView2.setText(answers.get(2).text);
                                    }

                                     */
                                    QaAnswer topAnswer = answers.get(0);
                                    String uniquid = UUID.randomUUID().toString();
                                    searchMessageViewModel.insert(new SearchMessage(uniquid,
                                            message.getSender(),
                                            message.getGroup_receiverId(),
                                            currentWorkplaceKey,
                                            currentWorkplace,
                                            message.getCreate_date(),
                                            message.getMessage_text(),
                                            String.valueOf(message.getLikes()),
                                            message.getTimestamp(),
                                            message.getThreadId(),
                                            topAnswer.text));
                                    runningSnackbar.dismiss();
                                    //presentAnswer(topAnswer,textV);
                                });
                    }
                });
    }


    public class GetMessagessTask extends AsyncTask<Void, Void, List<Message>> {

        private List<String> keyword_list;
        private String query;

        public GetMessagessTask(List<String> keyword_list, String query) {
            this.keyword_list = keyword_list;
            this.query = query;
        }

        @Override
        protected List<Message> doInBackground(Void... voids) {

            List<Message> messages = new ArrayList<>();
            messages = messageViewModel.getMessagess(currentWorkplace, sender, me);
            //Toast.makeText(SearchActivity.this,String.valueOf(messages.size()),Toast.LENGTH_SHORT).show();
            Log.e("Size", String.valueOf(messages.size()));
            return messages;
        }

        @Override
        protected void onPostExecute(List<Message> messages) {
            super.onPostExecute(messages);
            List<Message> contains_message_list = new ArrayList<>();
            Log.e("Size", String.valueOf(messages.size()));


            for (int j = messages.size() - 1; j >= 0; j--) {
                for (int i = 0; i < keyword_list.size(); i++) {
                    if (!messages.get(j).getMessage_text().toLowerCase().contains(keyword_list.get(i))) {
                        break;
                    } else {
                        if (keyword_list.size() - 1 == i) {
                            contains_message_list.add(messages.get(j));

                            //answers_list.add(messages.get(j).getMessage_text());
                            searchCount.setVisibility(View.VISIBLE);
                            searchCount.setText("  " + String.valueOf(contains_message_list.size()) + " Results Found" + "  ");
                        }
                    }
                }
            }
            sx = 0;
            for (sx = 0; sx < contains_message_list.size(); sx++) {
                answerQuestion(query, contains_message_list.get(sx));
            }

        }
    }

    private void answerQuestion(String question, Message message) {
        question = question.trim();
        if (question.isEmpty()) {
            // question_edit.setText(question);
            return;
        }

        // Append question mark '?' if not ended with '?'.
        // This aligns with question format that trains the model.
        if (!question.endsWith("?")) {
            question += '?';
        }
        final String questionToAsk = question;
        //question_edit.setText(questionToAsk);

        // Delete all pending tasks.
        //handler.removeCallbacksAndMessages(null);

        // Hide keyboard and dismiss focus on text edit.
        InputMethodManager imm =
                (InputMethodManager) getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
        View focusView = getCurrentFocus();
        if (focusView != null) {
            focusView.clearFocus();
        }

        // Reset content text view
        //textV.setText(content);



        Snackbar runningSnackbar = Snackbar.make(search_parent, "Looking up answer...", BaseTransientBottomBar.LENGTH_SHORT);
        runningSnackbar.show();

        // Run TF Lite model to get the answer.
        handler.post(
                () -> {
                    final List<QaAnswer> answers = qaClient.predict(questionToAsk, message.getMessage_text());
                    if (!answers.isEmpty()) {
                        // Get the top answer

                        Log.e("Insert", "Inserted");

                        // Show the answer.
                        runOnUiThread(
                                () -> {
                                    /*
                                    if (!answers.get(1).text.equals("")) {
                                        textView1.setText(answers.get(1).text);
                                    }if (!answers.get(2).text.equals("")) {
                                        textView2.setText(answers.get(2).text);
                                    }

                                     */
                                    QaAnswer topAnswer = answers.get(0);
                                    String uniquid = UUID.randomUUID().toString();
                                    searchMessageViewModel.insert(new SearchMessage(uniquid,
                                            message.getSender(),
                                            message.getReceiver(),
                                            currentWorkplaceKey,
                                            currentWorkplace,
                                            message.getCreate_date(),
                                            message.getMessage_text(),
                                            String.valueOf(message.getLikes()),
                                            message.getTimestamp(),
                                            message.getThreadId(),
                                            topAnswer.text));
                                    runningSnackbar.dismiss();
                                    //presentAnswer(topAnswer,textV);
                                });
                    }
                });
    }

    public void loadQuestionsDictionaryFile(AssetManager assetManager) throws IOException {
        try (InputStream ins = assetManager.open(QUESTIONS_PATH);
             BufferedReader reader = new BufferedReader(new InputStreamReader(ins))) {

            while (reader.ready()) {
                String key = reader.readLine();
                //       dic.put( index++,key);
                //x = x + key;
                //textView.setText("Hello");
                questions_list.add(key);

            }
        }
    }

    public synchronized void loadQuestionsDictionary() {
        try {
            loadQuestionsDictionaryFile(this.getApplicationContext().getAssets());
            Log.e("Hello", "Dictionary loaded.");
        } catch (IOException ex) {
            //Log.e("Hello", ex.getMessage());
        }
    }

    public void loadPrepositionsDictionaryFile(AssetManager assetManager) throws IOException {
        try (InputStream ins = assetManager.open(PREPOSITIONS_PATH);
             BufferedReader reader = new BufferedReader(new InputStreamReader(ins))) {
            int index = 0;
            while (reader.ready()) {
                String key = reader.readLine();
                //       dic.put( index++,key);
                //x = x + key;
                //textView.setText("Hello");
                prepositions_list.add(index, key);
                index++;
            }
        }
    }

    public synchronized void loadPrepositionsDictionary() {
        try {
            loadPrepositionsDictionaryFile(this.getApplicationContext().getAssets());
            Log.e("Hello", "Dictionary loaded.");
        } catch (IOException ex) {
            //Log.e("Hello", ex.getMessage());
        }
    }
}
