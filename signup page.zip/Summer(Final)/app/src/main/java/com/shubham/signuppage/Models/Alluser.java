package com.shubham.signuppage.Models;

public class Alluser {
    private  String key;

    private String f_name;

    private String l_name;

    private String  phone;

    public void setKey(String key) {
        this.key = key;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getKey() {
        return key;
    }

    public String getF_name() {
        return f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public String getPhone() {
        return phone;
    }

    public Alluser(String key, String f_name, String l_name, String phone) {
        this.key = key;
        this.f_name = f_name;
        this.l_name = l_name;
        this.phone = phone;
    }
}
