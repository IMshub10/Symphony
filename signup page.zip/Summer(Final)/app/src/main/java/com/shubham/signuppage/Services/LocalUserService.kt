package com.shubham.signuppage.Services

import android.content.Context
import com.shubham.signuppage.Models.PrefernecesModel

object LocalUserService {
    @JvmStatic
    fun getLocalUserFromPreferences(context: Context): PrefernecesModel {
        val pref = context.getSharedPreferences("LocalUser", 0)
        val prefernecesModel = PrefernecesModel()
        prefernecesModel.Phone = pref.getString("Phone", null)
        prefernecesModel.FirstName = pref.getString("FirstName", null)
        prefernecesModel.LastName = pref.getString("LastName", null)
//        prefernecesModel.ImageUrl = pref.getString("ImageUrl", null)
        prefernecesModel.Key = pref.getString("Key", null)
        prefernecesModel.CurrentWorkplaceKey=pref.getString("CurrentWorkplaceKey", null)
        prefernecesModel.CurrentWorkplaceName = pref.getString("CurrentWorkplaceName",null)
        prefernecesModel.CurrentWorkplaceCreator=pref.getString("CurrentWorkplaceCreator",null)
        prefernecesModel.Fullname=pref.getString("FullName",null);
        prefernecesModel.ThemeId = pref.getBoolean("ThemeId", false);
        return prefernecesModel
    }

    fun deleteLocalUserFromPreferences(context: Context): Boolean {
        return try {
            val pref = context.getSharedPreferences("LocalUser", 0)
            val editor = pref.edit()
            editor.clear()
            editor.apply()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            true
        }
    }
}