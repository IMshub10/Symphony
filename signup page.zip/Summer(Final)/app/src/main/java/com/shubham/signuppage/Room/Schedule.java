package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.shubham.signuppage.TableBuilder.Time;

@Entity(tableName = "schedule_table")
public class Schedule {

    @PrimaryKey(autoGenerate = false)
    @NonNull
    private  String key;

    private String event="";

    private int day ;

    private int startThour;

    private int startTMinute;

    private int endHour;

    private int endMinute;

    private String workplaceKey;

    private String workplace;

    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getEvent() {
        return event;
    }

    public int getDay() {
        return day;
    }

    public int getStartThour() {
        return startThour;
    }

    public int getStartTMinute() {
        return startTMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public String getWorkplaceKey() {
        return workplaceKey;
    }

    public String getWorkplace() {
        return workplace;
    }

    public Schedule(@NonNull String key, String event, int day, int startThour, int startTMinute, int endHour, int endMinute, String workplaceKey, String workplace) {
        this.key = key;
        this.event = event;
        this.day = day;
        this.startThour = startThour;
        this.startTMinute = startTMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
        this.workplaceKey = workplaceKey;
        this.workplace = workplace;
    }
    
}
