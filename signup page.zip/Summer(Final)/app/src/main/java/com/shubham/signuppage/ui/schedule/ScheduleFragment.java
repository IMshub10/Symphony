package com.shubham.signuppage.ui.schedule;

import android.app.Activity;
import android.app.Application;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.ScheduleViewModel;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.TableBuilder.Schedule;
import com.shubham.signuppage.TableBuilder.Time;
import com.shubham.signuppage.TableBuilder.TimetableView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import Helper.MyCalendar;

public class ScheduleFragment extends Fragment {

    private TextView month_year;
    private String s_month, s_year;
    private int month;
    private LinearLayout parent_schedule;
    private HorizontalScrollView horizontal_schedule;
    private TimetableView timetableView;
    private ProgressBar progress_schedule;
    private ScheduleViewModel scheduleViewModel;
    private Application applicationContext;
    private String CurrentWorkplaceKey;
    private String CurrentWorkplaceName;
    private LinearLayout bottom_sheet_schedule;
    private BottomSheetBehavior bottomSheetBehavior;
    private BottomNavigationView nav_view;
    private CalendarView schedule_calendar_view;
    private TextView calendar_date;
    private EditText event_edit;
    private TextView start_time, end_time;
    private int day;
    private com.shubham.signuppage.TableBuilder.Schedule schedule;

    private Button add_schedule;

    private void init(View root) {
        month_year = root.findViewById(R.id.month_year);
        parent_schedule = root.findViewById(R.id.parent_schedule);
        progress_schedule = root.findViewById(R.id.progress_schedule);
        horizontal_schedule = root.findViewById(R.id.horizontal_schedule);
        bottom_sheet_schedule = root.findViewById(R.id.bottom_sheet_schedule);
        bottomSheetBehavior = BottomSheetBehavior.from(bottom_sheet_schedule);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        nav_view = getActivity().findViewById(R.id.nav_view);
        add_schedule = root.findViewById(R.id.add_schedule);
        bottomSheetBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                    nav_view.animate().translationY(nav_view.getHeight()).setDuration(500).start();
                } else if (newState == BottomSheetBehavior.STATE_COLLAPSED || newState == BottomSheetBehavior.STATE_HIDDEN) {
                    nav_view.animate()
                            .translationY(0).setDuration(500).start();
                    nav_view.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });
        start_time = root.findViewById(R.id.start_time);
        end_time = root.findViewById(R.id.end_time);
        schedule_calendar_view = root.findViewById(R.id.schedule_calendar_view);
        calendar_date = root.findViewById(R.id.calendar_date);
        event_edit = root.findViewById(R.id.event_edit);

        SetDate(Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.YEAR));


        day = Calendar.getInstance().get(Calendar.YEAR) * 10000 + (Calendar.getInstance().get(Calendar.MONTH) + 1) * 100 + Calendar.getInstance().get(Calendar.DAY_OF_MONTH);

        scheduleViewModel = ViewModelProvider.AndroidViewModelFactory.getInstance(applicationContext).create(ScheduleViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_schedule, container, false);
        setHasOptionsMenu(true);
        applicationContext = getActivity().getApplication();
        CurrentWorkplaceKey = LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceKey;
        CurrentWorkplaceName = LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName;
        init(root);
        Calendar c = Calendar.getInstance();
        SetMonthYear(c);
        List<String> headerTitle = new ArrayList<>();
        headerTitle.add("");
        for (int i = 1; i < 8; i++) {
            String day = sWeek(c).get(i - 1) + String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + i - 1);
            headerTitle.add(day);
        }
        final Handler handler = new Handler();
        timetableView = new TimetableView(getActivity(), null, 24, 8, headerTitle,LocalUserService.getLocalUserFromPreferences(getContext()).ThemeId);
        progress_schedule.setVisibility(View.VISIBLE);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                progress_schedule.setVisibility(View.GONE);
                timetableView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                horizontal_schedule.addView(timetableView);
            }
        }, 300);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                timetableView.verticalScroll(c.get(Calendar.HOUR_OF_DAY));
            }
        },1000);
        scheduleViewModel.getAllSchedule(CurrentWorkplaceKey).observe(getViewLifecycleOwner(), new Observer<List<com.shubham.signuppage.Room.Schedule>>() {
            @Override
            public void onChanged(List<com.shubham.signuppage.Room.Schedule> schedules) {
                ArrayList<Schedule> schs = new ArrayList<>();
                int day = Calendar.getInstance().get(Calendar.YEAR) * 10000 +
                        (Calendar.getInstance().get(Calendar.MONTH) + 1) * 100
                        + Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
                for (int i = 0; i < schedules.size(); i++) {
                    com.shubham.signuppage.Room.Schedule schedule = schedules.get(i);
                    if (schedule.getDay() - day < 7 && schedule.getDay() - day >= 0) {
                        Schedule sch = new Schedule(schedule.getEvent(),
                                schedule.getDay() - day, new Time(schedule.getStartThour(), schedule.getStartTMinute()),
                                new Time(schedule.getEndHour(), schedule.getEndMinute()));
                        Log.e("Place", "Inside");
                        schs.add(sch);
                    }
                }
                timetableView.add(schs);
                Log.e("Place", "Outside");
            }
        });
        start_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog dialog = new TimePickerDialog(getContext(), listener, schedule.getStartTime().getHour(), schedule.getStartTime().getMinute(), false);
                dialog.show();
            }

            private TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    String hour;
                    String min;
                    if (hourOfDay < 10) {
                        hour = "0" + hourOfDay;
                    } else {
                        hour = String.valueOf(hourOfDay);
                    }
                    if (minute < 10) {
                        min = "0" + minute;
                    } else {
                        min = String.valueOf(minute);
                    }
                    String text = hour + ":" + min;
                    start_time.setText(text);
                    schedule.getStartTime().setHour(hourOfDay);
                    schedule.getStartTime().setMinute(minute);
                }
            };
        });
        end_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog dialog = new TimePickerDialog(getContext(), listener, schedule.getEndTime().getHour(), schedule.getEndTime().getMinute(), false);
                dialog.show();
            }

            private TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    String hour;
                    String min;
                    if (hourOfDay < 10) {
                        hour = "0" + String.valueOf(hourOfDay);
                    } else {
                        hour = String.valueOf(hourOfDay);
                    }
                    if (minute < 10) {
                        min = "0" + String.valueOf(minute);
                    } else {
                        min = String.valueOf(minute);
                    }
                    String text = hour + ":" + min;
                    end_time.setText(text);
                    schedule.getEndTime().setHour(hourOfDay);
                    schedule.getEndTime().setMinute(minute);

                }
            };
        });
        calendar_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
                //Find the currently focused view, so we can grab the correct window token from it.
                schedule_calendar_view.setVisibility(View.VISIBLE);
                imm.hideSoftInputFromWindow(event_edit.getWindowToken(), 0);
            }
        });
        schedule_calendar_view.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                SetDate(dayOfMonth, month, year);
                day = year * 10000 + (month + 1) * 100 + dayOfMonth;
            }
        });
        add_schedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uniqueId = UUID.randomUUID().toString();
                scheduleViewModel.insert(new com.shubham.signuppage.Room.Schedule(uniqueId,
                        event_edit.getText().toString(),
                        day,
                        schedule.getStartTime().getHour(),
                        schedule.getStartTime().getMinute(),
                        schedule.getEndTime().getHour(),
                        schedule.getEndTime().getMinute(),
                        CurrentWorkplaceKey,
                        CurrentWorkplaceName));
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
            }
        });
        return root;
    }

    public void SetStartTime_EndTime() {
        String startTime = new MyCalendar().StartTime();
        String endTime = new MyCalendar().EndTime();
        start_time.setText(startTime);
        end_time.setText(endTime);
    }

    private List<String> sWeek(Calendar calendar) {
        List<String> sWeek = new ArrayList<>();
        int day_of_week = calendar.get(Calendar.DAY_OF_WEEK);
        {
            if (Calendar.MONDAY == day_of_week) {
                sWeek.add(0, "Mon");
                sWeek.add(1, "Tue");
                sWeek.add(2, "Wed");
                sWeek.add(3, "Thu");
                sWeek.add(4, "Fri");
                sWeek.add(5, "Sat");
                sWeek.add(6, "Sun");
            } else if (Calendar.TUESDAY == day_of_week) {
                sWeek.add(0, "Tue");
                sWeek.add(1, "Wed");
                sWeek.add(2, "Thu");
                sWeek.add(3, "Fri");
                sWeek.add(4, "Sat");
                sWeek.add(5, "Sun");
                sWeek.add(6, "Mon");
            } else if (Calendar.WEDNESDAY == day_of_week) {
                sWeek.add(0, "Wed");
                sWeek.add(1, "Thu");
                sWeek.add(1, "Fri");
                sWeek.add(3, "Sat");
                sWeek.add(4, "Sun");
                sWeek.add(5, "Mon");
                sWeek.add(6, "Tue");
            } else if (Calendar.THURSDAY == day_of_week) {
                sWeek.add(0, "Thu");
                sWeek.add(1, "Fri");
                sWeek.add(2, "Sat");
                sWeek.add(3, "Sun");
                sWeek.add(4, "Mon");
                sWeek.add(5, "Tue");
                sWeek.add(6, "Wed");
            } else if (Calendar.FRIDAY == day_of_week) {
                sWeek.add(0, "Fri");
                sWeek.add(1, "Sat");
                sWeek.add(2, "Sun");
                sWeek.add(3, "Mon");
                sWeek.add(4, "Tue");
                sWeek.add(5, "Wed");
                sWeek.add(6, "Thu");
            } else if (Calendar.SATURDAY == day_of_week) {
                sWeek.add(0, "Sat");
                sWeek.add(1, "Sun");
                sWeek.add(2, "Mon");
                sWeek.add(3, "Tue");
                sWeek.add(4, "Wed");
                sWeek.add(5, "Thu");
                sWeek.add(6, "Fri");
            } else if (Calendar.SUNDAY == day_of_week) {
                sWeek.add(0, "Sun");
                sWeek.add(1, "Mon");
                sWeek.add(2, "Tue");
                sWeek.add(3, "Wed");
                sWeek.add(4, "Thu");
                sWeek.add(5, "Fri");
                sWeek.add(6, "Sat");
            }
        }
        return sWeek;
    }

    private void SetMonthYear(Calendar calendar) {
        month = calendar.get(Calendar.MONTH);
        switch (month) {
            case 0:
                s_month = "January";
                break;
            case 1:
                s_month = "February";
                break;
            case 2:
                s_month = "March";
                break;
            case 3:
                s_month = "April";
                break;
            case 4:
                s_month = "May";
                break;
            case 5:
                s_month = "June";
                break;
            case 6:
                s_month = "July";
                break;
            case 7:
                s_month = "August";
                break;
            case 8:
                s_month = "September";
                break;
            case 9:
                s_month = "October";
                break;
            case 10:
                s_month = "November";
                break;
            case 11:
                s_month = "December";
                break;
        }
        int year = calendar.get(Calendar.YEAR);
        s_year = String.valueOf(year);
        String s_month_year = s_month + "  " + s_year;
        month_year.setText(s_month_year);
    }

    public void SetDate(int day_of_month, int mon, int year) {
        String day = String.valueOf(day_of_month);
        if (day_of_month < 10) {
            day = "0" + day;
        }
        String month = String.valueOf(mon + 1);
        if (mon + 1 < 10) {
            month = "0" + month;
        }
        String currentDate = " " + day + "/" + month + "/" + String.valueOf(year) + " ";
        calendar_date.setText(currentDate);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.schedule_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.search) {
            // horizontal_schedule.removeAllViews();

        } else {
            SetStartTime_EndTime();
            schedule = new com.shubham.signuppage.TableBuilder.Schedule();
            schedule.setStartTime(new Time(Calendar.getInstance().get(Calendar.HOUR_OF_DAY), Calendar.getInstance().get(Calendar.MINUTE)));
            if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) <23) {
                schedule.setEndTime(new Time(Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + 1, Calendar.getInstance().get(Calendar.MINUTE)));
            }else {
                schedule.setEndTime(new Time(Calendar.getInstance().get(Calendar.HOUR_OF_DAY),Calendar.getInstance().get(Calendar.MINUTE)));
            }
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        }
        return true;
    }

}
