package com.shubham.signuppage.ui.groups;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.FirebaseDatabase;
import com.shubham.signuppage.Chat.ChatFinalActivity;
import com.shubham.signuppage.Groups.GroupsChatActivity;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.Groups;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.ui.feeds.FeedsRecyclerViewAdapter;

import de.hdodenhof.circleimageview.CircleImageView;

public class GroupsAdapter extends ListAdapter<Groups,GroupsAdapter.GroupsHolder> {
    private  Context context;
    private SharedPreferences sharedPreferences ,preferences;
//    private RecyclerView.RecycledViewPool viewPool = new RecyclerView.RecycledViewPool();

    GroupsAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
    }
    private static  final DiffUtil.ItemCallback<Groups> DIFF_CALLBACK = new DiffUtil.ItemCallback<Groups>() {
        @Override
        public boolean areItemsTheSame(@NonNull Groups oldItem, @NonNull Groups newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Groups oldItem, @NonNull Groups newItem) {
            return false;
        }
    };

    @NonNull
    @Override
    public GroupsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.content_groups,parent,false);
        return new GroupsHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroupsHolder holder, int position) {
        Groups current_group = getItem(position);
        if (current_group.getLastmesage() !=null){
            if (current_group.getLastmesage().length() >27){
                String c =current_group.getLastmesage().substring(0,27)+"...";
                holder.message.setText(c);
            }else {
                holder.message.setText(current_group.getLastmesage());
            }
        }
        holder.name.setText(current_group.getName());
        String create =current_group.getCreateDate();
        create = create.substring(9,17);
        holder.time.setText(create);
        Glide.with(holder.image.getContext())
                .asBitmap()
                .error(R.drawable.mas)
                .load(R.drawable.dp)
                .into(holder.image);
        if (current_group.getMesssageCount()<1){
            holder.no.setVisibility(View.INVISIBLE);
        }else {
            holder.no.setVisibility(View.VISIBLE);
            holder.no.setText(" "+ String.valueOf(current_group.getMesssageCount()));
        }


        holder.relay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, GroupsChatActivity.class);
                intent.putExtra("name",current_group.getName());
                intent.putExtra("Friend_key",current_group.getKey());
                intent.putExtra("Create",current_group.getCreateDate());
                intent.putExtra("key",current_group.getMemberKey());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
        if (current_group.getLastmesage().length() >27){
            String c =current_group.getLastmesage().substring(0,27)+"...";
            holder.message.setText(c);
        }else {
            holder.message.setText(current_group.getLastmesage());
        }

    }

    class  GroupsHolder extends RecyclerView.ViewHolder {
        CircleImageView image;
        TextView name,message,no,time;
        RelativeLayout relay;
        public GroupsHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            message = itemView.findViewById(R.id.message);
            no = itemView.findViewById(R.id.no);
            time = itemView.findViewById(R.id.time);
            relay = itemView.findViewById(R.id.relay);


        }
    }

}
