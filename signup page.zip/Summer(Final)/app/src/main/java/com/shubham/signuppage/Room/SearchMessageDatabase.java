package com.shubham.signuppage.Room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {SearchMessage.class},version = 2,exportSchema = false)
public abstract  class SearchMessageDatabase  extends RoomDatabase {

    private static SearchMessageDatabase instance;

    public  abstract SearchMessageDao searchMessageDao();

    public  static  synchronized SearchMessageDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    SearchMessageDatabase.class,"search_message_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }
    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

        }
    };


}
