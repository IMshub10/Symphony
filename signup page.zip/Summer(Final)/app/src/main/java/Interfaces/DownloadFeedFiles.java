package Interfaces;

import com.shubham.signuppage.ui.feeds.Feed;

public interface DownloadFeedFiles {
    void onItemClick(Feed feed, int item_position, int file_position);

}
