package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.google.gson.annotations.SerializedName;
import com.shubham.signuppage.Models.Files;
import com.shubham.signuppage.ui.feeds.FilesUrlsConverter;

import java.util.ArrayList;
import java.util.List;

@Entity(tableName = "group_message_table")
public class GroupMessage {
    @PrimaryKey
    @NonNull
    private String key;

    private String sender;

    private String group_receiverId;

    private String group_receiver;

    private String workplaceKey;

    private String workplace;

    private String create_date;

    private String message_text;

    private int likes;

    private String timestamp;

    private String threadId;

    private String answer;


    @TypeConverters(ImageUrlsConverter.class)
    private List<String> urls = new ArrayList<>();

    @TypeConverters(FilesUrlsConverter.class)
    @ColumnInfo(name = "Files")
    @SerializedName("Files")
    private List<Files> filesUrl;

    private Boolean read;


    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getSender() {
        return sender;
    }

    public String getGroup_receiverId() {
        return group_receiverId;
    }

    public String getGroup_receiver() {
        return group_receiver;
    }

    public String getWorkplaceKey() {
        return workplaceKey;
    }

    public String getWorkplace() {
        return workplace;
    }

    public String getCreate_date() {
        return create_date;
    }

    public String getMessage_text() {
        return message_text;
    }

    public int getLikes() {
        return likes;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getThreadId() {
        return threadId;
    }

    public String getAnswer() {
        return answer;
    }

    public List<String> getUrls() {
        return urls;
    }

    public List<Files> getFilesUrl() {
        return filesUrl;
    }

    public Boolean getRead() {
        return read;
    }

    public GroupMessage(@NonNull String key, String sender, String group_receiverId, String group_receiver, String workplaceKey, String workplace, String create_date, String message_text, int likes, String timestamp, String threadId, String answer, List<String> urls, List<Files> filesUrl, Boolean read) {
        this.key = key;
        this.sender = sender;
        this.group_receiverId = group_receiverId;
        this.group_receiver = group_receiver;
        this.workplaceKey = workplaceKey;
        this.workplace = workplace;
        this.create_date = create_date;
        this.message_text = message_text;
        this.likes = likes;
        this.timestamp = timestamp;
        this.threadId = threadId;
        this.answer = answer;
        this.urls = urls;
        this.filesUrl = filesUrl;
        this.read = read;
    }
}
