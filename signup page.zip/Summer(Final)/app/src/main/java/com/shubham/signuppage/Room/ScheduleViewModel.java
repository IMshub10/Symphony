package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ScheduleViewModel extends AndroidViewModel {
    private  ScheduleRepository scheduleRepository;
    private LiveData<List<Schedule>> liveData;

    public ScheduleViewModel(@NonNull Application application) {
        super(application);
        scheduleRepository = new ScheduleRepository(application);
    }
    public  void  insert(Schedule schedule){
        scheduleRepository.insert(schedule);
    }
    public  void  update(Schedule schedule){
        scheduleRepository.update(schedule);
    }
    public  void  delete(Schedule schedule){
        scheduleRepository.delete(schedule);
    }
    public  void deleteall(){
        scheduleRepository.deleteAllThreads();
    }

    public  LiveData<List<Schedule>> getAllSchedule(String workKey){
        return  scheduleRepository.getAllSchedule(workKey);
    }
}
