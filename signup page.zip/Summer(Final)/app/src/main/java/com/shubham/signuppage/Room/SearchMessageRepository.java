package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.LiveData;

import java.util.List;

public class SearchMessageRepository {
    private SearchMessageDao searchMessageDao;
    private LiveData<List<SearchMessage>> allMessages;

    public SearchMessageRepository(Application application) {
        SearchMessageDatabase searchMessageDatabase = SearchMessageDatabase.getInstance(application);
        searchMessageDao = searchMessageDatabase.searchMessageDao();
    }
    public  void insert(SearchMessage searchMessage){
        new InsertFeedTask(searchMessageDao).execute(searchMessage);
    }
    public  void delete(SearchMessage searchMessage){
        new DeleteFeedTask(searchMessageDao).execute(searchMessage);
    }
    public  void update(SearchMessage searchMessage){
        new UpdateFeedTask(searchMessageDao).execute(searchMessage);
    }
    public  void deleteAllThreads(){
        new DeleteAllFeedTask(searchMessageDao).execute();
    }
    public  LiveData<List<SearchMessage>> getAllMessages(String work, String sender, String receiver){
        allMessages = searchMessageDao.getAllMessages(work,sender,receiver);
        return  allMessages;
    }

    public  LiveData<List<SearchMessage>> getMessages(String work,String receiverId){
        allMessages = searchMessageDao.getMessages(work,receiverId);
        return  allMessages;
    }





    private  static  class InsertFeedTask extends AsyncTask<SearchMessage,Void,Void> {

        private SearchMessageDao searchMessageDao;
        private  InsertFeedTask(SearchMessageDao searchMessageDao){
            this.searchMessageDao = searchMessageDao;
        }

        @Override
        protected Void doInBackground(SearchMessage... searchMessages) {
            searchMessageDao.insert(searchMessages[0]);
            Log.e("SearchMessageRepositoty","Inserted");
            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }
    }
    private  static  class UpdateFeedTask extends  AsyncTask<SearchMessage,Void,Void>{

        private SearchMessageDao searchMessageDao;
        private  UpdateFeedTask(SearchMessageDao searchMessageDao){
            this.searchMessageDao = searchMessageDao;
        }

        @Override
        protected Void doInBackground(SearchMessage... searchMessages) {
            searchMessageDao.update(searchMessages[0]);
            return null;
        }

    }
    private  static  class DeleteFeedTask extends  AsyncTask<SearchMessage,Void,Void>{

        private SearchMessageDao searchMessageDao;
        private  DeleteFeedTask(SearchMessageDao searchMessageDao){
            this.searchMessageDao = searchMessageDao;
        }

        @Override
        protected Void doInBackground(SearchMessage... searchMessages) {
            searchMessageDao.delete(searchMessages[0]);
            return null;
        }

    }

    private  static  class DeleteAllFeedTask extends  AsyncTask<Void,Void,Void>{

        private SearchMessageDao searchMessageDao;
        private  DeleteAllFeedTask(SearchMessageDao searchMessageDao){
            this.searchMessageDao = searchMessageDao;
        }

        @Override
        protected Void doInBackground(Void ... voids) {
            searchMessageDao.deleteAllMessages();
            return null;
        }

    }
}
