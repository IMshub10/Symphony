package com.shubham.signuppage

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.shubham.signuppage.Models.Message

class ChatListAdapter(private val context: Context, private val messages: List<Message>) : RecyclerView.Adapter<ChatListAdapter.ViewHolder>() {
    private val name: String? = null
    private val mAuth: FirebaseAuth? = null
    private val reference: DatabaseReference? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.chat_listitem, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.name.text = messages[position].Name
        holder.date.text = messages[position].SentDate
        holder.message.text = messages[position].Message
    }

    override fun getItemCount(): Int {
        return messages.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var name: TextView
        var date: TextView
        var message: TextView

        init {
            name = itemView.findViewById(R.id.name)
            date = itemView.findViewById(R.id.date)
            message = itemView.findViewById(R.id.message)
        }
    }

}