package com.shubham.signuppage.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface AllUsersDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(AllUsers member);

    @Update
    void update(AllUsers member);

    @Delete
    void delete(AllUsers member);

    @Query("Delete From all_users_table ")
    void deleteAllUsers();

    @Query("SELECT * FROM  all_users_table  ORDER BY f_name ASC ")
    LiveData<List<AllUsers>> getAllUsers();
    @Query("SELECT * FROM  all_users_table  ORDER BY f_name ASC ")
    List<AllUsers> getAllUsers2();


}
