package com.shubham.signuppage.ui.mails;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shubham.signuppage.Chat.ChatFinalActivity;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.Member;

import de.hdodenhof.circleimageview.CircleImageView;

public class MailsAdapter extends ListAdapter<Member,MailsAdapter.GroupsHolder> {

    private  Context context;

    protected MailsAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
    }
    private static  final DiffUtil.ItemCallback<Member> DIFF_CALLBACK = new DiffUtil.ItemCallback<Member>() {
        @Override
        public boolean areItemsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return false;
        }
    };


    @NonNull
    @Override
    public GroupsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.content_groups,parent,false);
        return new GroupsHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroupsHolder holder, int position) {

        Member current_member = getItem(position);

        holder.name.setText(current_member.getName());
        if (current_member.getLastMessage() !=null){
            if (current_member.getLastMessage().length() >27){
                String c =current_member.getLastMessage().substring(0,27)+"...";
                holder.message.setText(c);
            }else {
                holder.message.setText(current_member.getLastMessage());
            }
        }if (current_member.getCreateDate() !=null){
            String create =current_member.getCreateDate();
            create = create.substring(9,17);
            holder.time.setText(create.toLowerCase());
        }

        Glide.with(holder.image.getContext())
                .asBitmap()
                .error(R.drawable.mas)
                .load(R.drawable.dp)
                .into(holder.image);

        holder.relay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,ChatFinalActivity.class);
                intent.putExtra("MemberKey",current_member.getKey());
                intent.putExtra("CreateDate",current_member. getCreateDate());
                intent.putExtra("name",current_member.getName());
                intent.putExtra("Phone",current_member.getPhone());
                intent.putExtra("Friend_key",current_member.getMemberKey());
                intent.putExtra("Message",current_member.getLastMessage());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                context.startActivity(intent);
            }
        });
        if (current_member.getMesssageCount()<1){
            holder.no.setVisibility(View.INVISIBLE);
        }else {
            holder.no.setVisibility(View.VISIBLE);
            holder.no.setText(" "+ String.valueOf(current_member.getMesssageCount()));
        }

    }

    class  GroupsHolder extends RecyclerView.ViewHolder {
        CircleImageView image;
        TextView name,message,no,time;
        RelativeLayout relay;
        public GroupsHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            message = itemView.findViewById(R.id.message);
            no = itemView.findViewById(R.id.no);
            time = itemView.findViewById(R.id.time);
            relay = itemView.findViewById(R.id.relay);

        }
    }
}
