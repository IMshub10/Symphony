package com.shubham.signuppage.ui.feeds;


import android.content.SharedPreferences;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.shubham.signuppage.Room.Message;

import java.util.List;


@Dao
public interface FeedDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Feed feed );

    @Update
    void update(Feed feed);

    @Delete
    void delete(Feed feed);

    @Query("Delete From feeds_table ")
    void deleteAllFeeds();

    @Query("SELECT * FROM  feeds_table where workplaceKey=:workKey ORDER BY timestamp DESC ")
    LiveData<List<Feed>> getAllFeeds(String workKey);

    @Query("SELECT * FROM  feeds_table where workplaceKey =:workKey  ORDER BY timestamp DESC ")
    List<Feed> getFeeds(String workKey);

    @Query("Delete From feeds_table WHERE `key`=:asKey ")
    void deleteFeed(String asKey);

    @Query("UPDATE feeds_table SET likes=:likes WHERE `key`=:askey")
    void updateFeed(String askey,int likes);

    @Query("SELECT * FROM  feeds_table where workplaceKey=:work  AND (feed_text LIKE '%' || :contains ||'%' ) ORDER BY  timestamp DESC")
    List<Feed> getSearchFeeds(String work, String contains);

}
