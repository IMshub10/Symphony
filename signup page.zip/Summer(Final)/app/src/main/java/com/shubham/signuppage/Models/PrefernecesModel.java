package com.shubham.signuppage.Models;

public class PrefernecesModel {

    public String Phone;
    public String Fullname;
    public String FirstName;
    public String LastName;
    public String ImageUrl;
    public String Key;
    public String CurrentWorkplaceName;
    public String CurrentWorkplaceKey;
    public String CurrentWorkplaceCreator;
    public Boolean ThemeId;

}
