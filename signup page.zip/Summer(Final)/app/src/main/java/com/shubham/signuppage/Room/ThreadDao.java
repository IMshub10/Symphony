package com.shubham.signuppage.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ThreadDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Thread Thread);

    @Update
    void update(Thread Thread);

    @Delete
    void delete(Thread Thread);

    @Query("Delete From thread_table ")
    void deleteAllThread();

    @Query("Delete From thread_table WHERE `key`=:threadId ")
    void deleteThread(String threadId);

    @Query("UPDATE thread_table SET position=:position WHERE `key`=:threadTd")
    void updatePositionsOfThread(String threadTd,int position);

    @Query("SELECT position FROM thread_table WHERE `key`=:threadId ")
    int getThread(String threadId);

    @Query("SELECT * FROM  thread_table where(workplaceKey=:workKey AND workplace=:work AND((sender=:sender AND receiver=:receiver)OR (sender=:receiver AND receiver=:sender)))   ORDER BY timestamp ASC ")
    LiveData<List<Thread>> getAlThread(String workKey,String work, String sender, String receiver);

    @Query("SELECT * FROM  thread_table where(workplace=:work AND position>:position AND((sender=:sender AND receiver=:receiver)OR (sender=:receiver AND receiver=:sender)))   ORDER BY position ASC ")
    List<Thread> getThreads(String work, String sender, String receiver,int position);
}
