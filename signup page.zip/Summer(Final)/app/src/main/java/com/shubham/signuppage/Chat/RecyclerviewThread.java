package com.shubham.signuppage.Chat;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.google.firebase.database.FirebaseDatabase;

import com.shubham.signuppage.R;

import Interfaces.ChatFinalActivityListener;
import Interfaces.DownloadChatFiles;
import Interfaces.RecyclerViewItemClickListener;

import com.shubham.signuppage.Room.Message;
import com.shubham.signuppage.Room.MessageViewModel;
import com.shubham.signuppage.Room.Thread;
import com.shubham.signuppage.Room.ThreadsViewModel;
import com.shubham.signuppage.Services.LocalUserService;


import java.util.Objects;

import Helper.MyItemTouchHelper;
import Interfaces.RecyclerviewSwipeListener;
import Helper.Swipe;

public class RecyclerviewThread extends ListAdapter<Thread, RecyclerviewThread.ThreadHolder> {

    public Context context;
    private MessageViewModel messageViewModel;
    private ThreadsViewModel threadsViewModel;
    private String Friend_Key;

    EditText text_editor_edit;

    private ChatFinalActivityListener chatFinalActivityListener;
    public RecyclerView.RecycledViewPool viewPool;
    String FriendName;
    private DownloadChatFiles downloadChatFiles;


    public RecyclerviewThread(Context context, String FriendKey, String FriendName, EditText text_editor_edit) {
        super(DIFF_CALLBACK);
        this.context = context;
        this.Friend_Key = FriendKey;
        this.FriendName = FriendName;
        this.text_editor_edit= text_editor_edit;
        threadsViewModel = ViewModelProviders.of((ChatFinalActivity) context).get(ThreadsViewModel.class);
        viewPool = new RecyclerView.RecycledViewPool();
    }

    public void setOnItemClickListener(ChatFinalActivityListener chatFinalActivityListener) {
        this.chatFinalActivityListener = chatFinalActivityListener;
    }

    public  void  addFileDownloadListener(DownloadChatFiles downloadChatFiles){
        this.downloadChatFiles= downloadChatFiles;
    }

    @Override
    public int getItemCount() {
        return super.getItemCount();
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    public static final DiffUtil.ItemCallback<Thread> DIFF_CALLBACK = new DiffUtil.ItemCallback<Thread>() {
        @Override
        public boolean areItemsTheSame(@NonNull Thread oldItem, @NonNull Thread newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Thread oldItem, @NonNull Thread newItem) {

            return oldItem.getSender().equals(newItem.getSender()) &&
                    oldItem.getReceiver().equals(newItem.getReceiver()) &&
                    oldItem.getWorkplace().equals(newItem.getWorkplace()) &&
                    oldItem.getCreate_date().equals(newItem.getCreate_date()) &&
                    oldItem.getTimestamp().equals(newItem.getTimestamp()) &&
                    oldItem.getPosition() == newItem.getPosition();
        }
    };

    @NonNull
    @Override
    public ThreadHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.thread, parent, false);
        return new ThreadHolder(view);
    }

    @Override
    public void onViewRecycled(@NonNull ThreadHolder holder) {
        super.onViewRecycled(holder);
    }

    @Override
    public void onBindViewHolder(@NonNull ThreadHolder holder, int position) {
        Thread current_thread = getItem(position);
        // Create layout manager with initial prefetch item count
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                holder.recyclerViewMessage.getContext(),
                LinearLayoutManager.VERTICAL,
                false
        );
        holder.thread_name.setText(current_thread.getSender());
        holder.thread_name.setVisibility(View.INVISIBLE);
        holder.thread_key.setText(current_thread.getKey());
        holder.thread_key.setVisibility(View.INVISIBLE);
        holder.threadLayout.setBackgroundColor(0xf2f2f5);


        if (position != current_thread.getPosition()) {
            threadsViewModel.updatePositionsOfThread(current_thread.getKey(), position);
        }
        //layoutManager.setInitialPrefetchItemCount(current_thread.);
        // Create sub item view adapter
        RecyclerviewMessage recyclerviewMessage = new RecyclerviewMessage(context, Friend_Key);
        holder.recyclerViewMessage.setLayoutManager(layoutManager);
        holder.recyclerViewMessage.setAdapter(recyclerviewMessage);
        ((SimpleItemAnimator) Objects.requireNonNull(holder.recyclerViewMessage.getItemAnimator())).setSupportsChangeAnimations(false);
        holder.recyclerViewMessage.setRecycledViewPool(viewPool);
        holder.recyclerViewMessage.setNestedScrollingEnabled(false);
        Intent intent = ((ChatFinalActivity) context).getIntent();
        layoutManager.setItemPrefetchEnabled(true);
        messageViewModel = ViewModelProviders.of((ChatFinalActivity) context).get(MessageViewModel.class);
        messageViewModel.getAllMessages(LocalUserService.getLocalUserFromPreferences((ChatFinalActivity) context).CurrentWorkplaceKey,
                LocalUserService.getLocalUserFromPreferences((ChatFinalActivity) context).CurrentWorkplaceName,
                intent.getStringExtra("name"),
                LocalUserService.getLocalUserFromPreferences(context).FirstName + " " + LocalUserService.getLocalUserFromPreferences(context).LastName,
                current_thread.getKey())
                .observe((ChatFinalActivity) context, recyclerviewMessage::submitList);
        recyclerviewMessage.addFileDownloadListener(new DownloadChatFiles() {
            @Override
            public void onItemClick(Message message, int item_position, int file_position) {
                RecyclerviewThread.this.downloadChatFiles.onItemClick(message,position,0);
            }
        });
        recyclerviewMessage.setOnItemClickListener(new RecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
            }

            @Override
            public void onLongItemClick(View view, int message_position) {
                RecyclerviewThread.this.chatFinalActivityListener.onLongItemClick(recyclerviewMessage,view,position,message_position);

            }
        });
    }

    @Override
    protected Thread getItem(int position) {
        return super.getItem(position);
    }

    class ThreadHolder extends RecyclerView.ViewHolder {
        TextView thread_name, thread_key;
        RecyclerView recyclerViewMessage;
        LinearLayout threadLayout;

        public ThreadHolder(@NonNull View itemView) {
            super(itemView);
            thread_name = itemView.findViewById(R.id.thread_name);
            thread_key = itemView.findViewById(R.id.thread_key);
            recyclerViewMessage = itemView.findViewById(R.id.recyclerViewMessage);
            threadLayout = itemView.findViewById(R.id.threadLayout);

            MyItemTouchHelper myItemTouchHelper = new MyItemTouchHelper(context,0,ItemTouchHelper.RIGHT, new Swipe(){
                @Override
                public void showReplyUIRight(int position) {
                    RecyclerviewThread.this.chatFinalActivityListener.onSwipeRight(recyclerViewMessage,itemView, getLayoutPosition(),position);
                }
            });
            ItemTouchHelper itemTouchHelper = new ItemTouchHelper(myItemTouchHelper);
            itemTouchHelper.attachToRecyclerView(recyclerViewMessage);

            MyItemTouchHelper myItemTouchHelper1 = new MyItemTouchHelper(context,0,ItemTouchHelper.LEFT, new Swipe(){
                @Override
                public void showReplyUIRight(int position) {
                    RecyclerviewThread.this.chatFinalActivityListener.onSwipeLeft(recyclerViewMessage,itemView, getLayoutPosition(),position);
                }
            });
            ItemTouchHelper itemTouchHelper1 = new ItemTouchHelper(myItemTouchHelper1);
            itemTouchHelper1.attachToRecyclerView(recyclerViewMessage);

        }
    }

    @Override
    public void onViewAttachedToWindow(@NonNull ThreadHolder holder) {
        super.onViewAttachedToWindow(holder);
        Log.e("LayoutView Attached", String.valueOf(holder.getLayoutPosition()));
        Log.e("Layout ", "sddw");
    }


}
