package com.shubham.signuppage.ui.feeds;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

import com.google.gson.annotations.SerializedName;
import com.shubham.signuppage.Models.Files;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

@Entity(tableName = "feeds_table")
public class Feed {
    @PrimaryKey
    @NonNull
    private String key;

    private String creator;

    private String workplaceKey;

    private String workplaceName;

    private String create_date;

    private String feed_text;


    private String video_url;

    private int likes;

    private String timestamp;

    @TypeConverters(ImageUrlsConverter.class)
    private List<String> urls = new ArrayList<>();

    @TypeConverters(FilesUrlsConverter.class)
    @ColumnInfo(name = "Files")
    @SerializedName("Files")
    private List<Files> filesUrl;


    @NotNull
    public String getKey() {
        return key;
    }

    public void setKey(@NonNull String key) {
        this.key = key;
    }


    public String getTimestamp() {
        return timestamp;
    }

    public String getVideo_url() {
        return video_url;
    }

    public int getLikes() {
        return likes;
    }

    public String getCreator() {
        return creator;
    }

    public String getWorkplaceKey() {
        return workplaceKey;
    }

    public String getWorkplaceName() {
        return workplaceName;
    }

    public String getCreate_date() {
        return create_date;
    }

    public String getFeed_text() {
        return feed_text;
    }

    public List<String> getUrls() {
        return urls;
    }

    public List<Files> getFilesUrl() {
        return filesUrl;
    }

    public Feed(@NonNull String key, String creator, String workplaceKey, String workplaceName, String create_date, String feed_text, String video_url, int likes, String timestamp, List<String> urls, List<Files> filesUrl) {
        this.key = key;
        this.creator = creator;
        this.workplaceKey = workplaceKey;
        this.workplaceName = workplaceName;
        this.create_date = create_date;
        this.feed_text = feed_text;
        this.video_url = video_url;
        this.likes = likes;
        this.timestamp = timestamp;
        this.urls = urls;
        this.filesUrl = filesUrl;
    }
}
