package Interfaces;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.shubham.signuppage.Groups.RecyclerviewGroupMessage;

public interface GroupsChatActivityListener {
    void onItemClick(View view, int position);
    void  onLongItemClick( RecyclerviewGroupMessage recyclerviewGroupMessage,View view, int thread_position,int message_position);
    void  onSwipeRight(RecyclerView recyclerView, View view, int layoutPosition, int swipePosition);
    void  onSwipeLeft(RecyclerView recyclerView,View view, int layoutPosition,int swipePosition);
}
