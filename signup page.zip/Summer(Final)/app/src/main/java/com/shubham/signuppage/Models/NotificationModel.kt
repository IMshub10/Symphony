package com.shubham.signuppage.Models

/*
NotificationType:
 1) Friend Request



 */
class NotificationModel {
    var NotificationMessage: String? = null
    var NotificationType = 0
    var PhoneFrom: String? = null
    var FirstName: String? = null
    var LastName: String? = null
    var FriendRequestFireBaseKey: String? = null
}