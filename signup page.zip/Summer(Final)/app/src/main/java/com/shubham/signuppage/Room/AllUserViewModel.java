package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.shubham.signuppage.Room.AllUsers;
import com.shubham.signuppage.Room.AllUsersRepository;
import com.shubham.signuppage.Room.GroupMember;
import com.shubham.signuppage.Room.GroupMemberRepository;

import java.util.List;

public class AllUserViewModel extends AndroidViewModel {
    private AllUsersRepository allUsersRepository;
    private LiveData<List<AllUsers>> allMember;

    public AllUserViewModel(@NonNull Application application) {
        super(application);
        allUsersRepository = new AllUsersRepository(application);
    }

    public void insert (AllUsers allUsers) { allUsersRepository.insert(allUsers); }
    public void update (AllUsers allUsers) { allUsersRepository.update(allUsers); }
    public void delete (AllUsers allUsers) { allUsersRepository.delete(allUsers); }
    public  void deleteAll(){
        allUsersRepository.deleteAll();
    }
    public LiveData<List<AllUsers>> getAllUsers() {
        return allUsersRepository.getAllUsers();
    }

    public List<AllUsers> getAllUsers2() {
        return allUsersRepository.getAllUsers2();
    }

}
