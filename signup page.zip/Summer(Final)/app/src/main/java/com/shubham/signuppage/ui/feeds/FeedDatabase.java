package com.shubham.signuppage.ui.feeds;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Database(entities = {Feed.class},version = 8,exportSchema = false)
@TypeConverters(ImageUrlsConverter.class)
public abstract class FeedDatabase extends RoomDatabase {

    private  static FeedDatabase instance;

    public abstract FeedDao feedDao();

    public  static  synchronized FeedDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    FeedDatabase.class,"feed_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbTask(instance).execute();
        }
    };

    private  static class  PopulateDbTask extends AsyncTask<Void,Void,Void>{

        private  FeedDao feedDao;
        private PopulateDbTask(FeedDatabase database){
            feedDao = database.feedDao();
        }


        @Override
        protected Void doInBackground(Void... voids) {

            return null;
        }
    }
}
