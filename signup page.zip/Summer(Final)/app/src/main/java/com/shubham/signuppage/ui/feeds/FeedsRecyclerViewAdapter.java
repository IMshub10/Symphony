package com.shubham.signuppage.ui.feeds;

import android.app.DownloadManager;
import android.content.Context;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;

import android.net.Uri;

import android.os.Build;
import android.os.Environment;

import android.text.util.Linkify;

import android.util.Log;

import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;

import androidx.appcompat.app.AlertDialog;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.FirebaseDatabase;
import com.makeramen.roundedimageview.RoundedImageView;

import com.shubham.signuppage.R;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.VideoPlayer;
import com.shubham.signuppage.ViewImage;


import java.io.File;
import java.util.List;

import Interfaces.DownloadFeedFiles;
import Interfaces.DownloadGroupFiles;


public class FeedsRecyclerViewAdapter extends ListAdapter<Feed, FeedsRecyclerViewAdapter.FeedsHolder> implements Filterable {

    private Context context;
    private SharedPreferences sharedPreferences;
    private DownloadFeedFiles downloadFeedFiles;
//  private RecyclerView.RecycledViewPool viewPool = new RecyclerView.RecycledViewPool();

    FeedsRecyclerViewAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
    }

    private static final DiffUtil.ItemCallback<Feed> DIFF_CALLBACK = new DiffUtil.ItemCallback<Feed>() {
        @Override
        public boolean areItemsTheSame(@NonNull Feed oldItem, @NonNull Feed newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Feed oldItem, @NonNull Feed newItem) {
            return oldItem.getCreator().equals(newItem.getCreator()) &&
                    oldItem.getWorkplaceKey().equals(newItem.getWorkplaceKey()) &&
                    oldItem.getCreate_date().equals(newItem.getCreate_date()) &&
                    oldItem.getFeed_text().equals(newItem.getFeed_text()) &&
                    oldItem.getLikes()==newItem.getLikes();
        }

    };
    public void DownloadFilesFeed(DownloadFeedFiles downloadFeedFiles){
        this.downloadFeedFiles=downloadFeedFiles;
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(true);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }


    @NonNull
    @Override
    public FeedsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.content_feeds, parent, false);
        return new FeedsHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull FeedsHolder holder, int position) {
        Feed current_feed = getItem(position);

//        holder.feed_card.setCardBackgroundColor(0xff333537);
        //holder.setIsRecyclable(false);
        holder.feed_text_recyclerview.setText(current_feed.getFeed_text());
        Linkify.addLinks(holder.feed_text_recyclerview, Linkify.ALL);

        holder.workplace_name_recyclerview.setText(current_feed.getCreator());


        int likes = current_feed.getLikes();
        holder.count_like.setText(String.valueOf(likes-1));
        sharedPreferences = context.getSharedPreferences("FeedsLikes", 0);



        if (sharedPreferences.getInt(current_feed.getKey(), 0) == 1) {
            holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup);
        } else if (sharedPreferences.getInt(current_feed.getKey(), 0) == 0) {
            holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup_light);
        }



        if (current_feed.getUrls() != null) {
            if (current_feed.getUrls().size() >= 1) {
                if (current_feed.getUrls().get(0) != null) {
                    Glide.with(holder.gridLayout.getContext())
                            .asBitmap()
                            .load(current_feed.getUrls().get(0))
                            .into(holder.imageView1);
                    holder.imageView1.setVisibility(View.VISIBLE);
                    holder.frame1.setVisibility(View.VISIBLE);
                    holder.frame2.setVisibility(View.GONE);
                    holder.frame3.setVisibility(View.GONE);
                    holder.imageView2.setImageBitmap(null);
                    holder.imageView3.setImageBitmap(null);
                    holder.imageView2.setVisibility(View.GONE);
                    holder.imageView3.setVisibility(View.GONE);
                    holder.imageView1.setOnClickListener(v -> {
                        Intent intent = new Intent(context, ViewImage.class);
                        intent.putExtra("Url", current_feed.getUrls().get(0));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        context.startActivity(intent);
                    });
                }
            }
            if (current_feed.getUrls().size() >= 2) {
                if (current_feed.getUrls().get(1) != null) {

                    Glide.with(holder.gridLayout.getContext())
                            .asBitmap()
                            .load(current_feed.getUrls().get(1))
                            .into(holder.imageView2);
                    holder.imageView2.setVisibility(View.VISIBLE);
                    holder.frame2.setVisibility(View.VISIBLE);
                    holder.frame3.setVisibility(View.GONE);
                    holder.imageView3.setImageBitmap(null);
                    holder.imageView3.setVisibility(View.GONE);
                    holder.imageView2.setOnClickListener(v -> {
                        Intent intent = new Intent(context, ViewImage.class);
                        intent.putExtra("Url", current_feed.getUrls().get(1));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        context.startActivity(intent);
                    });
                }
            }
            if (current_feed.getUrls().size() >= 3) {
                if (current_feed.getUrls().get(2) != null) {
                    Glide.with(holder.gridLayout.getContext())
                            .asBitmap()
                            .load(current_feed.getUrls().get(2))
                            .into(holder.imageView3);
                    holder.imageView3.setVisibility(View.VISIBLE);
                    holder.frame3.setVisibility(View.VISIBLE);
                    holder.imageView3.setOnClickListener(v -> {
                        Intent intent = new Intent(context, ViewImage.class);
                        intent.putExtra("Url", current_feed.getUrls().get(2));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        context.startActivity(intent);
                    });
                }
            }
        } else {
            holder.imageView1.setImageBitmap(null);
            holder.imageView2.setImageBitmap(null);
            holder.imageView3.setImageBitmap(null);
            holder.imageView1.setVisibility(View.GONE);
            holder.imageView2.setVisibility(View.GONE);
            holder.imageView3.setVisibility(View.GONE);
            holder.frame1.setVisibility(View.GONE);
            holder.frame2.setVisibility(View.GONE);
            holder.frame3.setVisibility(View.GONE);
        }

        if (current_feed.getFilesUrl() != null){
            if (current_feed.getFilesUrl().size()>=1){
                holder.imagePdf.setVisibility(View.VISIBLE);
                holder.namePdf.setVisibility(View.VISIBLE);
                holder.pdf_layout.setVisibility(View.VISIBLE);
                holder.pdf_view.setVisibility(View.VISIBLE);
                holder.pdf_linear_layout.setVisibility(View.VISIBLE);
                holder.namePdf.setText(current_feed.getFilesUrl().get(0).getName());
                holder.pdf_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FeedsRecyclerViewAdapter.this.downloadFeedFiles.onItemClick(current_feed,position,0);
                    }
                });
                switch (current_feed.getFilesUrl().get(0).getType()) {
                    case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_docx_file_format);
                        holder.imagePdf.setImageDrawable(myDrawable);
                        break;
                    }
                    case "application/pdf": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_pdf_file_format_symbol);
                        holder.imagePdf.setImageDrawable(myDrawable);
                        break;
                    }
                    case "text/plain": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                        holder.imagePdf.setImageDrawable(myDrawable);
                        break;
                    }
                    case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_xls_file_format_symbol);
                        holder.imagePdf.setImageDrawable(myDrawable);
                        break;
                    }
                    default: {
                        Drawable myDrawable = context.getDrawable(R.drawable.file);
                        holder.imagePdf.setImageDrawable(myDrawable);
                        break;
                    }
                }

                holder.imagePdf1.setVisibility(View.GONE);
                holder.imagePdf1.setImageBitmap(null);
                holder.namePdf1.setVisibility(View.GONE);
                holder.pdf_layout1.setVisibility(View.GONE);
                holder.pdf_view1.setVisibility(View.GONE);
                holder.pdf_linear_layout1.setVisibility(View.GONE);

                holder.imagePdf2.setVisibility(View.GONE);
                holder.imagePdf2.setImageBitmap(null);
                holder.namePdf2.setVisibility(View.GONE);
                holder.pdf_layout2.setVisibility(View.GONE);
                holder.pdf_view2.setVisibility(View.GONE);
                holder.pdf_linear_layout2.setVisibility(View.GONE);

            }
            if (current_feed.getFilesUrl().size()>=2){
                holder.imagePdf1.setVisibility(View.VISIBLE);
                holder.namePdf1.setVisibility(View.VISIBLE);
                holder.pdf_layout1.setVisibility(View.VISIBLE);
                holder.pdf_view1.setVisibility(View.VISIBLE);
                holder.pdf_linear_layout1.setVisibility(View.VISIBLE);
                holder.namePdf1.setText(current_feed.getFilesUrl().get(1).getName());
                switch (current_feed.getFilesUrl().get(1).getType()) {
                    case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_docx_file_format);
                        holder.imagePdf1.setImageDrawable(myDrawable);
                        break;
                    }
                    case "application/pdf": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_pdf_file_format_symbol);
                        holder.imagePdf1.setImageDrawable(myDrawable);
                        break;
                    }
                    case "text/plain": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                        holder.imagePdf1.setImageDrawable(myDrawable);
                        break;
                    }
                    case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_xls_file_format_symbol);
                        holder.imagePdf1.setImageDrawable(myDrawable);
                        break;
                    }
                    default: {
                        Drawable myDrawable = context.getDrawable(R.drawable.file);
                        holder.imagePdf1.setImageDrawable(myDrawable);
                        break;
                    }
                }

                holder.pdf_layout1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FeedsRecyclerViewAdapter.this.downloadFeedFiles.onItemClick(current_feed,position,1);
                    }
                });
                holder.imagePdf2.setVisibility(View.GONE);
                holder.imagePdf2.setImageBitmap(null);
                holder.namePdf2.setVisibility(View.GONE);
                holder.pdf_layout2.setVisibility(View.GONE);
                holder.pdf_view2.setVisibility(View.GONE);
                holder.pdf_linear_layout2.setVisibility(View.GONE);

            }
            if (current_feed.getFilesUrl().size()>=3){
                holder.imagePdf2.setVisibility(View.VISIBLE);
                holder.namePdf2.setVisibility(View.VISIBLE);
                holder.pdf_layout2.setVisibility(View.VISIBLE);
                holder.namePdf2.setText(current_feed.getFilesUrl().get(2).getName());
                holder.pdf_view2.setVisibility(View.VISIBLE);
                holder.pdf_linear_layout2.setVisibility(View.VISIBLE);
                holder.pdf_layout2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FeedsRecyclerViewAdapter.this.downloadFeedFiles.onItemClick(current_feed,position,2);
                    }
                });
                switch (current_feed.getFilesUrl().get(2).getType()) {
                    case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_docx_file_format);
                        holder.imagePdf2.setImageDrawable(myDrawable);
                        break;
                    }
                    case "application/pdf": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_pdf_file_format_symbol);
                        holder.imagePdf2.setImageDrawable(myDrawable);
                        break;
                    }
                    case "text/plain": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                        holder.imagePdf2.setImageDrawable(myDrawable);
                        break;
                    }
                    case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                        Drawable myDrawable = context.getDrawable(R.drawable.ic_xls_file_format_symbol);
                        holder.imagePdf2.setImageDrawable(myDrawable);
                        break;
                    }
                    default: {
                        Drawable myDrawable = context.getDrawable(R.drawable.file);
                        holder.imagePdf2.setImageDrawable(myDrawable);
                        break;
                    }
                }
            }
        }else {
            holder.imagePdf.setVisibility(View.GONE);
            holder.imagePdf.setImageBitmap(null);
            holder.namePdf.setVisibility(View.GONE);
            holder.pdf_layout.setVisibility(View.GONE);
            holder.pdf_view.setVisibility(View.GONE);
            holder.pdf_linear_layout.setVisibility(View.GONE);

            holder.imagePdf1.setVisibility(View.GONE);
            holder.imagePdf1.setImageBitmap(null);
            holder.namePdf1.setVisibility(View.GONE);
            holder.pdf_layout1.setVisibility(View.GONE);
            holder.pdf_view1.setVisibility(View.GONE);
            holder.pdf_linear_layout1.setVisibility(View.GONE);

            holder.imagePdf2.setVisibility(View.GONE);
            holder.imagePdf2.setImageBitmap(null);
            holder.namePdf2.setVisibility(View.GONE);
            holder.pdf_layout2.setVisibility(View.GONE);
            holder.pdf_view2.setVisibility(View.GONE);
            holder.pdf_linear_layout2.setVisibility(View.GONE);
        }


        if (current_feed.getVideo_url() != null) {

            holder.button.setVisibility(View.VISIBLE);
            holder.videoView.setVisibility(View.VISIBLE);
            holder.videoView.setVideoPath(current_feed.getVideo_url());
            holder.videoView.setOnPreparedListener(mp -> mp.setVolume(0, 0));
            /*
            if(holder.videoView.isShown()){
                holder.videoView.start();
            }else {
                holder.videoView.pause();
            }
             */

            // holder.videoView.

            holder.button.setOnClickListener(v -> {
                Intent intent = new Intent(context, VideoPlayer.class);
                intent.putExtra("Url", current_feed.getVideo_url());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP |
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                context.startActivity(intent);

            });
        } else {
            holder.videoView.setVideoURI(null);
            holder.videoView.setVisibility(View.GONE);
            holder.button.setVisibility(View.GONE);
        }

        holder.button_like.setOnClickListener(v -> {
            if (sharedPreferences.getInt(current_feed.getKey(), 0) == 0) {
                holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup);
                FirebaseDatabase.getInstance().getReference().child("Feeds").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey).child(current_feed.getKey())
                        .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).setValue("1");
                int likes1 = current_feed.getLikes();
                holder.count_like.setText(String.valueOf(likes1));
                //holder.count_like.setText(String.valueOf());
                sharedPreferences.edit().putInt(current_feed.getKey(), 1).apply();


            } else if (sharedPreferences.getInt(current_feed.getKey(), 0) == 1) {

                holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup_light);
                FirebaseDatabase.getInstance().getReference().child("Feeds").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey).child(current_feed.getKey())
                        .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).removeValue();
                int likes1 = current_feed.getLikes();
                holder.count_like.setText(String.valueOf(likes1 -1));
                sharedPreferences.edit().putInt(current_feed.getKey(), 0).apply();
            }

        });
    }

    @Override
    public Filter getFilter() {
        return null;
    }

    class FeedsHolder extends RecyclerView.ViewHolder {
        TextView workplace_name_recyclerview, feed_text_recyclerview, count_like;
        Button button_like;
        LinearLayout layout_recylerview;
        View pdf_view,pdf_view1,pdf_view2;
        LinearLayout pdf_linear_layout,pdf_linear_layout1,pdf_linear_layout2;
        RoundedImageView imageView1,imageView2, imageView3;
        VideoView videoView;
        Button button;
        FrameLayout pdf_layout, pdf_layout1, pdf_layout2;
        ImageView imagePdf, imagePdf1, imagePdf2;
        TextView namePdf,namePdf1, namePdf2;
        FrameLayout  frame1,frame2,frame3;
        CardView feed_card;
        GridLayout gridLayout;

        public FeedsHolder(@NonNull View itemView) {
            super(itemView);
            workplace_name_recyclerview = itemView.findViewById(R.id.workplace_name_recyclerview);
            feed_text_recyclerview = itemView.findViewById(R.id.feed_text_recyclerview);
            count_like = itemView.findViewById(R.id.count_like);
            button_like = itemView.findViewById(R.id.button_like);

//            layout_recylerview = itemView.findViewById(R.id.layout_recylerview);
            gridLayout = itemView.findViewById(R.id.grid_layout);
            videoView = itemView.findViewById(R.id.videoView);
            button = itemView.findViewById(R.id.start);

            feed_card = itemView.findViewById(R.id.feed_card);

            imageView1 = itemView.findViewById(R.id.imageView1);
            imageView2 = itemView.findViewById(R.id.imageView2);
            imageView3 = itemView.findViewById(R.id.imageView3);
            imagePdf = itemView.findViewById(R.id.imagePdf);
            namePdf = itemView.findViewById(R.id.namePdf);

            imagePdf1 = itemView.findViewById(R.id.imagePdf1);
            namePdf1 = itemView.findViewById(R.id.namePdf1);
            imagePdf2 = itemView.findViewById(R.id.imagePdf2);
            namePdf2 = itemView.findViewById(R.id.namePdf2);
            pdf_layout = itemView.findViewById(R.id.pdf_layout);
            pdf_layout1 = itemView.findViewById(R.id.pdf_layout1);
            pdf_layout2 = itemView.findViewById(R.id.pdf_layout2);

            pdf_view = itemView.findViewById(R.id.pdf_view);
            pdf_view1 = itemView.findViewById(R.id.pdf_view1);
            pdf_view2 = itemView.findViewById(R.id.pdf_view2);

            pdf_linear_layout = itemView.findViewById(R.id.pdf_linear_layout);
            pdf_linear_layout1 = itemView.findViewById(R.id.pdf_linear_layout1);
            pdf_linear_layout2 = itemView.findViewById(R.id.pdf_linear_layout2);

            frame1 = itemView.findViewById(R.id.frame1);
            frame2 = itemView.findViewById(R.id.frame2);
            frame3 = itemView.findViewById(R.id.frame3);



            itemView.setOnLongClickListener(v -> false);


        }
    }

    @Override
    public void onViewAttachedToWindow(@NonNull FeedsHolder holder) {
        super.onViewAttachedToWindow(holder);
        holder.videoView.start();
        holder.videoView.seekTo(1000);
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull FeedsHolder holder) {
        super.onViewDetachedFromWindow(holder);
        holder.videoView.pause();
    }

    @Override
    public void onViewRecycled(@NonNull FeedsHolder holder) {
        super.onViewRecycled(holder);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedsHolder holder, int position, @NonNull List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
    }

}