package com.shubham.signuppage.Models

object StaticInfo {
    var EndPoint = "https://firsttry-87e5f.firebaseio.com"
    var MessagesEndPoint = "https://firsttry-87e5f.firebaseio.com/Messages"
    var FriendsURL = "https://firsttry-87e5f.firebaseio.com/Friends"
    var UsersURL = "https://firsttry-87e5f.firebaseio.com/Users"
    @JvmField
    var UserCurrentChatFriendEmail = ""
    var TypingStatus = "TypingStatus"
    var NotificationEndPoint = "https://firsttry-87e5f.firebaseio.com/Notifications"
    var FriendRequestsEndPoint = "https://firsttry-87e5f.firebaseio.com/Friendrequests"
    var ChatAciviityRequestCode = 101
}