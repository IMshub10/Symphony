package com.shubham.signuppage

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.shubham.signuppage.Services.LocalUserService

class MainActivity : AppCompatActivity() {
    var intent1: Intent? = null
    var mAuth: FirebaseAuth? = null
    var currentUser: FirebaseUser? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId == true) {
            setTheme(R.style.MainActivity_Dark);
        } else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_main)
        FirebaseApp.initializeApp(applicationContext)
        mAuth = FirebaseAuth.getInstance()
        currentUser = mAuth!!.currentUser
        val currentNightMode: Int = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        when (currentNightMode) {
            Configuration.UI_MODE_NIGHT_NO -> {
                Log.e("Mode","Light")
            } // Night mode is not active, we're using the light theme
            Configuration.UI_MODE_NIGHT_YES -> {
                Log.e("Mode","Dark")
            } // Night mode is active, we're using dark theme
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }

    fun SignUp(view: View?) {
        intent1 = Intent(this, Main2Activity::class.java)
        startActivity(intent1)
    }

    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        if (currentUser != null) {
            intent1 = Intent(this, Main3Activity::class.java)
            startActivity(intent1)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val a = Intent(Intent.ACTION_MAIN)
        a.addCategory(Intent.CATEGORY_HOME)
        a.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(a)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        return super.onKeyLongPress(keyCode, event)
    }
}