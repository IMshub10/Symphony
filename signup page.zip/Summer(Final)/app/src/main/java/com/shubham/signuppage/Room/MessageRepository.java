package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class MessageRepository {
    private MessageDao messageDao;
    private LiveData<List<Message>> allMessages;

    public MessageRepository(Application application) {
        MessageDatabase messageDatabase = MessageDatabase.getInstance(application);
        messageDao = messageDatabase.messageDao();
    }
    public  void insert(Message message){
        new InsertFeedTask(messageDao).execute(message);
    }
    public  void delete(Message message){
        new DeleteFeedTask(messageDao).execute(message);
    }
    public  void update(Message message){
        new UpdateFeedTask(messageDao).execute(message);
    }
    public  void deleteAllThreads(){
        new DeleteAllMessgeTask(messageDao).execute();
    }
    public  LiveData<List<Message>> getAllMessages(String workKey, String work,String sender,String receiver,String threadId){
        allMessages = messageDao.getAllMessages(workKey,work,sender,receiver,threadId);
        return  allMessages;
    }

    public void deleteMessage(String messageId){
        new DeleteMessageTask(messageDao).execute(messageId);
    }
    public List<Message> getThreadMessages(String threadId) {
        return messageDao.getThreadMessage(threadId);
    }
    public List<Message> getMessages(String work,String sender,String receiver,String contains) {
        return messageDao.getMessages( work, sender, receiver,contains);
    }
    public List<Message> getMessagess(String work,String sender,String receiver) {
        return messageDao.getMessagess( work, sender, receiver);
    }
    public  void updateMessageLikeCount(String asKey,int likes){
        new UpdateMessageLikeCount(messageDao,asKey,likes).execute();
    }
    void  updateRead(String work,String sender,String receiver,Boolean read){
        messageDao.updateRead(work,sender,receiver,read);
    }
    public int getThreadMessageCount(String threadId){
        return  messageDao.getThreadMessageCount(threadId);
    }

    private  static class UpdateMessageLikeCount extends  AsyncTask<Void,Void,Void>{
        private MessageDao messageDao;
        private String asKey;
        private int likes;
        public UpdateMessageLikeCount(MessageDao messageDao, String asKey, int likes) {
            this.messageDao = messageDao;
            this.asKey = asKey;
            this.likes = likes;
        }
        @Override
        protected Void doInBackground(Void... voids) {
            messageDao.updateMessageLikeCount(asKey,likes);
            return null;
        }
    }
    private  static class UpdateMessageRead extends  AsyncTask<Void,Void,Void>{
        private MessageDao messageDao;
        private String work;
        private String sender;
        private String receiver;
        private Boolean read;

        public UpdateMessageRead(MessageDao messageDao, String work, String sender, String receiver, Boolean read) {
            this.messageDao = messageDao;
            this.work = work;
            this.sender = sender;
            this.receiver = receiver;
            this.read = read;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            messageDao.updateRead(work,sender,receiver,read);
            return null;
        }
    }
    private  static  class InsertFeedTask extends AsyncTask<Message,Void,Void> {
        private MessageDao messageDao;
        private  InsertFeedTask(MessageDao messageDao){
            this.messageDao = messageDao;
        }
        @Override
        protected Void doInBackground(Message... messages) {
            messageDao.insert(messages[0]);
            return null;
        }
    }
    private  static  class UpdateFeedTask extends  AsyncTask<Message,Void,Void>{

        private MessageDao messageDao;
        private  UpdateFeedTask(MessageDao messageDao){
            this.messageDao = messageDao;
        }

        @Override
        protected Void doInBackground(Message... messages) {
            messageDao.update(messages[0]);
            return null;
        }

    }
    private  static  class DeleteFeedTask extends  AsyncTask<Message,Void,Void>{

        private MessageDao messageDao;
        private  DeleteFeedTask(MessageDao messageDao){
            this.messageDao = messageDao;
        }

        @Override
        protected Void doInBackground(Message... messages) {
            messageDao.delete(messages[0]);
            return null;
        }

    }
    private  static  class DeleteMessageTask extends  AsyncTask<String,Void,Void>{

        private MessageDao messageDao;
        private  DeleteMessageTask(MessageDao messageDao){
            this.messageDao = messageDao;
        }

        @Override
        protected Void doInBackground(String... strings) {
            messageDao.deleteMessage(strings[0]);
            return null;
        }

    }
    private  static  class DeleteAllMessgeTask extends  AsyncTask<Void,Void,Void>{
        private MessageDao messageDao;
        private  DeleteAllMessgeTask(MessageDao messageDao){
            this.messageDao = messageDao;
        }
        @Override
        protected Void doInBackground(Void ... voids) {
            messageDao.deleteAllMessages();
            return null;
        }
    }
}
