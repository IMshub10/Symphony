package com.shubham.signuppage.Chat;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.text.util.Linkify;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.FirebaseDatabase;
import com.makeramen.roundedimageview.RoundedImageView;
import com.shubham.signuppage.R;

import Interfaces.DownloadChatFiles;
import Interfaces.RecyclerViewItemClickListener;
import com.shubham.signuppage.Room.Message;
import com.shubham.signuppage.Room.MessageViewModel;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.ViewImage;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RecyclerviewMessage extends ListAdapter<Message, RecyclerviewMessage.ChatHolder> {

    private Context context;
    private RecyclerViewItemClickListener recyclerViewItemClickListener;
    private DownloadChatFiles downloadChatFiles;

    private SharedPreferences sharedPreferences;
    String Friend_Key;
    private TextToSpeech textToSpeech;
    private MessageViewModel messageViewModel;


    RecyclerviewMessage(Context context,String Friend_Key) {
        super(DIFF_CALLBACK);
        this.context=context;
        this.Friend_Key=Friend_Key;
        messageViewModel = ViewModelProviders.of((ChatFinalActivity)context).get(MessageViewModel.class);
    }
    private  static  final DiffUtil.ItemCallback<Message>DIFF_CALLBACK = new DiffUtil.ItemCallback<Message>() {
        @Override
        public boolean areItemsTheSame(@NonNull Message oldItem, @NonNull Message newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Message oldItem, @NonNull Message newItem) {

            return oldItem.getSender().equals(newItem.getSender()) &&
                    oldItem.getReceiver().equals(newItem.getReceiver()) &&
                    oldItem.getWorkplace().equals(newItem.getWorkplace()) &&
                    oldItem.getCreate_date().equals(newItem.getCreate_date()) &&
                    oldItem.getMessage_text().equals(newItem.getMessage_text()) &&
                    oldItem.getTimestamp().equals(newItem.getTimestamp()) &&
                    oldItem.getThreadId().equals(newItem.getThreadId()) &&
                    oldItem.getLikes()==newItem.getLikes();
        }
    };

    public  void  setOnItemClickListener(RecyclerViewItemClickListener recyclerViewItemClickListener){
        this.recyclerViewItemClickListener= recyclerViewItemClickListener;
    }
    public  void  addFileDownloadListener(DownloadChatFiles downloadChatFiles){
        this.downloadChatFiles= downloadChatFiles;
    }

    @NonNull
    @Override
    public ChatHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.chat_listitem,parent,false);
        return new ChatHolder(view);
    }

    @Override
    protected Message getItem(int position) {
        return super.getItem(position);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull ChatHolder holder, int position) {
        List<Message>messages = new ArrayList<>();
        Message current_message = getItem(position);
        StringBuilder message = new StringBuilder(new StringBuilder(current_message.getMessage_text()));
        messages.add(current_message);
        if (position < getItemCount()-1) {
            for (int i=position+1;i<getItemCount();i++){
                if (current_message.getSender().equals(getItem(i).getSender())){
                    if (current_message.getUrls()==null && getItem(i).getUrls()==null){
                        if (current_message.getFilesUrl()==null && getItem(i).getFilesUrl()==null){
                            long current_mess_time = Long.parseLong(current_message.getTimestamp());
                            long next_mess_time = Long.parseLong(getItem(i).getTimestamp());
                            long diff_timestamp = next_mess_time - current_mess_time;
                            if (diff_timestamp <1500){
                                messages.add(getItem(i));
                            }else {
                                break;
                            }
                        }else {
                            break;
                        }
                    }else {
                        break;
                    }
                }else {
                    break;
                }
            }
        }

//        if (current_message.getRead()){
////            holder.listitem3.setBackgroundResource(R.color.colorPrimaryLight);
//            holder.listitem3.setBackgroundColor(R.attr.msg_read);;
//        }else if(!current_message.getRead()){
////            holder.listitem3.setBackgroundResource(R.color.cream);
//            holder.listitem3.setBackgroundColor(R.attr.msg_unread);
//        }

        if(!current_message.getRead()){
            if(!LocalUserService.getLocalUserFromPreferences(context).ThemeId){
                holder.listitem3.setBackgroundResource(R.color.msg_unread_light);
            }else{
                holder.listitem3.setBackgroundResource(R.color.msg_unread_dark);
            }
        }

        sharedPreferences = context.getSharedPreferences("ChatLikes", 0);

        if (sharedPreferences.getInt(current_message.getKey(), 0) == 1) {
            holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup);
        } else if (sharedPreferences.getInt(current_message.getKey(), 0) == 0) {
            holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup_light);
        }
        /*
        if (!current_message.getAnswer().equals("")){
            //Log.e("recyclerMessage123",string2);
            if (current_message.getMessage_text().contains(current_message.getAnswer())){
                Spannable spanText = new SpannableString(current_message.getMessage_text());
                int offset = current_message.getMessage_text().indexOf(current_message.getAnswer(), 0);
                if (offset >= 0) {
                    spanText.setSpan(
                            new BackgroundColorSpan(R.color.colorPrimary),
                            offset,
                            offset + current_message.getAnswer().length(),
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                holder.text.setText(spanText);

                // Use TTS to speak out the answer.
                if (textToSpeech != null) {
                    textToSpeech.speak(current_message.getAnswer(), TextToSpeech.QUEUE_FLUSH, null, current_message.getAnswer());
                }
            }
        }else {
            holder.text.setText(current_message.getMessage_text());
        }

         */
        holder.count_like.setText(String.valueOf(current_message.getLikes()-1));
        holder.text.setText(current_message.getMessage_text());
        holder.name.setText(current_message.getSender());

        holder.text.setTextIsSelectable(true);

        Linkify.addLinks(holder.text, Linkify.ALL);

        if (current_message.getFilesUrl() ==null && current_message.getUrls()==null){
//            holder.layout_recylerview.setVisibility(View.GONE);
            holder.gridLayout.setVisibility(View.GONE);
        }else {
//            holder.layout_recylerview.setVisibility(View.VISIBLE);
            holder.gridLayout.setVisibility(View.VISIBLE);
        }
        String currentTimestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        long currentTimestamps = Long.parseLong(currentTimestamp);
        long timestamps = Long.parseLong(current_message.getTimestamp());
        timestamps = timestamps + 1000000;
        if (currentTimestamps > timestamps){
            holder.date.setText(current_message.getCreate_date().toLowerCase());
        }else {
            String create =current_message.getCreate_date();
            create = create.substring(9,17);
            holder.date.setText(create.toLowerCase());
        }

        if (current_message.getUrls() != null) {
            if (current_message.getUrls().size() >= 1) {
                if (current_message.getUrls().get(0) != null) {
                    Glide.with(holder.listitem3.getContext())
                            .asBitmap()
                            .load(current_message.getUrls().get(0))
                            .into(holder.imageView1);
                    holder.imageView1.setVisibility(View.VISIBLE);
                    holder.frame1.setVisibility(View.VISIBLE);
                    holder.imageView2.setImageBitmap(null);
                    holder.imageView3.setImageBitmap(null);
                    holder.imageView2.setVisibility(View.GONE);
                    holder.imageView3.setVisibility(View.GONE);
                    holder.frame2.setVisibility(View.GONE);
                    holder.frame3.setVisibility(View.GONE);
                    holder.imageView1.setOnClickListener(v -> {
                        Intent intent = new Intent(context, ViewImage.class);
                        intent.putExtra("Url", current_message.getUrls().get(0));
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        context.startActivity(intent);
                    });
                }
            }
            if (current_message.getUrls().size() >= 2) {
                if (current_message.getUrls().get(1) != null) {

                    Glide.with(holder.listitem3.getContext())
                            .asBitmap()
                            .load(current_message.getUrls().get(1))
                            .into(holder.imageView2);
                    holder.imageView2.setVisibility(View.VISIBLE);
                    holder.imageView3.setImageBitmap(null);
                    holder.frame2.setVisibility(View.VISIBLE);
                    holder.imageView3.setVisibility(View.GONE);
                    holder.frame3.setVisibility(View.GONE);
                    holder.imageView2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(context, ViewImage.class);
                            intent.putExtra("Url", current_message.getUrls().get(1));
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            context.startActivity(intent);
                        }
                    });
                }
            }
            if (current_message.getUrls().size() >= 3) {
                if (current_message.getUrls().get(2) != null) {
                    Glide.with(holder.listitem3.getContext())
                            .asBitmap()
                            .load(current_message.getUrls().get(2))
                            .into(holder.imageView3);
                    holder.imageView3.setVisibility(View.VISIBLE);
                    holder.frame3.setVisibility(View.VISIBLE);
                    holder.imageView3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(context, ViewImage.class);
                            intent.putExtra("Url", current_message.getUrls().get(2));
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                    Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            context.startActivity(intent);
                        }
                    });
                }
            }
        } else {
            holder.imageView1.setImageBitmap(null);
            holder.imageView2.setImageBitmap(null);
            holder.imageView3.setImageBitmap(null);
            holder.imageView1.setVisibility(View.GONE);
            holder.imageView2.setVisibility(View.GONE);
            holder.imageView3.setVisibility(View.GONE);
            holder.frame1.setVisibility(View.GONE);
            holder.frame2.setVisibility(View.GONE);
            holder.frame3.setVisibility(View.GONE);
        }

        if (current_message.getFilesUrl() != null){
            if (current_message.getFilesUrl().size()>=1){
                holder.imagePdf.setVisibility(View.VISIBLE);
                holder.namePdf.setVisibility(View.VISIBLE);
                holder.pdf_layout.setVisibility(View.VISIBLE);
                holder.namePdf.setText(current_message.getFilesUrl().get(0).getName());
                holder.pdf_layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        RecyclerviewMessage.this.downloadChatFiles.onItemClick(current_message,position,0);
                    }
                });
                if (current_message.getFilesUrl().get(0).getType().equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_docx_file_format);
                    holder.imagePdf.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(0).getType().equals("application/pdf")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_pdf_file_format_symbol);
                    holder.imagePdf.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(0).getType().equals("text/plain")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                    holder.imagePdf.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(0).getType().equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_xls_file_format_symbol);
                    holder.imagePdf.setImageDrawable(myDrawable);
                } else {
                    Drawable myDrawable = context.getDrawable(R.drawable.file);
                    holder.imagePdf.setImageDrawable(myDrawable);
                }
                holder.imagePdf1.setVisibility(View.GONE);
                holder.imagePdf1.setImageBitmap(null);
                holder.namePdf1.setVisibility(View.GONE);
                holder.pdf_layout1.setVisibility(View.GONE);

                holder.imagePdf2.setVisibility(View.GONE);
                holder.imagePdf2.setImageBitmap(null);
                holder.namePdf2.setVisibility(View.GONE);
                holder.pdf_layout2.setVisibility(View.GONE);
            }
            if (current_message.getFilesUrl().size()>=2){
                holder.imagePdf1.setVisibility(View.VISIBLE);
                holder.namePdf1.setVisibility(View.VISIBLE);
                holder.pdf_layout1.setVisibility(View.VISIBLE);
                holder.namePdf1.setText(current_message.getFilesUrl().get(1).getName());
                if (current_message.getFilesUrl().get(1).getType().equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_docx_file_format);
                    holder.imagePdf1.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(1).getType().equals("application/pdf")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_pdf_file_format_symbol);
                    holder.imagePdf1.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(1).getType().equals("text/plain")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                    holder.imagePdf1.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(1).getType().equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_xls_file_format_symbol);
                    holder.imagePdf1.setImageDrawable(myDrawable);
                } else {
                    Drawable myDrawable = context.getDrawable(R.drawable.file);
                    holder.imagePdf1.setImageDrawable(myDrawable);
                }
                holder.pdf_layout1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        RecyclerviewMessage.this.downloadChatFiles.onItemClick(current_message,position,1);
                    }
                });
                holder.imagePdf2.setVisibility(View.GONE);
                holder.imagePdf2.setImageBitmap(null);
                holder.namePdf2.setVisibility(View.GONE);
                holder.pdf_layout2.setVisibility(View.GONE);
            }
            if (current_message.getFilesUrl().size()>=3){
                holder.imagePdf2.setVisibility(View.VISIBLE);
                holder.namePdf2.setVisibility(View.VISIBLE);
                holder.pdf_layout2.setVisibility(View.VISIBLE);
                holder.namePdf2.setText(current_message.getFilesUrl().get(2).getName());
                holder.pdf_layout2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        RecyclerviewMessage.this.downloadChatFiles.onItemClick(current_message,position,2);
                    }
                });
                if (current_message.getFilesUrl().get(2).getType().equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_docx_file_format);
                    holder.imagePdf2.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(2).getType().equals("application/pdf")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_pdf_file_format_symbol);
                    holder.imagePdf2.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(2).getType().equals("text/plain")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                    holder.imagePdf2.setImageDrawable(myDrawable);
                } else if (current_message.getFilesUrl().get(2).getType().equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                    Drawable myDrawable = context.getDrawable(R.drawable.ic_xls_file_format_symbol);
                    holder.imagePdf2.setImageDrawable(myDrawable);
                } else {
                    Drawable myDrawable = context.getDrawable(R.drawable.file);
                    holder.imagePdf2.setImageDrawable(myDrawable);
                }
            }
        }else {
            holder.imagePdf.setVisibility(View.GONE);
            holder.imagePdf.setImageBitmap(null);
            holder.namePdf.setVisibility(View.GONE);
            holder.pdf_layout.setVisibility(View.GONE);

            holder.imagePdf1.setVisibility(View.GONE);
            holder.imagePdf1.setImageBitmap(null);
            holder.namePdf1.setVisibility(View.GONE);
            holder.pdf_layout1.setVisibility(View.GONE);

            holder.imagePdf2.setVisibility(View.GONE);
            holder.imagePdf2.setImageBitmap(null);
            holder.namePdf2.setVisibility(View.GONE);
            holder.pdf_layout2.setVisibility(View.GONE);

        }
        holder.button_like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sharedPreferences.getInt(current_message.getKey(), 0) == 0) {
                    holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup);
                    if (current_message.getSender().equals(LocalUserService.getLocalUserFromPreferences(context).Fullname)){
                        FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                .child("Mails").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("Messages").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).setValue("1");
                        FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child("Mails").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("OwnMessages").child(Friend_Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).setValue("1");
                    }else {
                        FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child("Mails")
                                .child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("Messages")
                                .child(Friend_Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).setValue("1");
                        FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                .child("Mails")
                                .child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("OwnMessages")
                                .child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).setValue("1");
                    }
                    //holder.count_like.setText(String.valueOf());
                    sharedPreferences.edit().putInt(current_message.getKey(), 1).apply();
                }
                else if (sharedPreferences.getInt(current_message.getKey(), 0) == 1) {
                    holder.button_like.setBackgroundResource(R.drawable.ic_thumbsup_light);
                    if (current_message.getSender().equals(LocalUserService.getLocalUserFromPreferences(context).Fullname)){
                        FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                .child("Mails").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("Messages").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).removeValue();
                        FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child("Mails").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("OwnMessages").child(Friend_Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).removeValue();
                    }else {
                        FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child("Mails")
                                .child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("Messages")
                                .child(Friend_Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).removeValue();
                        FirebaseDatabase.getInstance().getReference().child("Users").child(Friend_Key)
                                .child("Mails")
                                .child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                                .child("OwnMessages")
                                .child(LocalUserService.getLocalUserFromPreferences(context).Key)
                                .child(current_message.getKey())
                                .child("Likes").child(LocalUserService.getLocalUserFromPreferences(context).Key).removeValue();
                    }
                    sharedPreferences.edit().putInt(current_message.getKey(), 0).apply();
                }
            }
        });
        if (messages.size()>2){
            for (int i=1;i<messages.size();i++){
                message.append("\n").append(messages.get(i).getMessage_text());
            }
            messageViewModel.update(new Message(current_message.getKey(),
                    current_message.getSender(),
                    current_message.getReceiver(),
                    current_message.getWorkplaceKey(),
                    current_message.getWorkplace(),
                    current_message.getCreate_date(),
                    message.toString(),
                    current_message.getLikes(),
                    current_message.getTimestamp(),
                    current_message.getThreadId(),
                    "",
                    null,
                    null,
                    messages.get(messages.size()-1).getRead()));
            for (int i=1;i<messages.size();i++){
                messageViewModel.deleteMessage(messages.get(i).getKey());
                if (current_message.getSender().equals(LocalUserService.getLocalUserFromPreferences(context).Fullname)){
                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                            .child("OwnMessages").child(Friend_Key)
                            .child(messages.get(i).getKey()).removeValue();
                }else {
                    FirebaseDatabase.getInstance().getReference().child("Users").child(LocalUserService.getLocalUserFromPreferences(context).Key)
                            .child("Mails").child(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceKey)
                            .child("Messages").child(Friend_Key)
                            .child(messages.get(i).getKey()).removeValue();
                }

            }

        }
        /*
        if (previous_message != null){
            if (current_message.getSender().equals(previous_message.getSender())) {
                long current_mess_time = Long.parseLong(current_message.getTimestamp());
                long previous_mess_time = Long.parseLong(previous_message.getTimestamp());
                long diff_timestamp = current_mess_time - previous_mess_time;
                if (diff_timestamp < 1500) {
                    holder.name.setVisibility(View.GONE);
                    holder.date.setVisibility(View.GONE);
                } else {
                    holder.name.setVisibility(View.VISIBLE);
                    holder.date.setVisibility(View.VISIBLE);
                }
            }
        }

         */
    }
    @Override
    public int getItemCount() {
        return super.getItemCount();
    }
    @Override
    public void onBindViewHolder(@NonNull ChatHolder holder, int position, @NonNull List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
    }
    public Context getContext() {
        return context;
    }
    class ChatHolder extends RecyclerView.ViewHolder{
        TextView name,text,date;
        RelativeLayout listitem3;
        HorizontalScrollView horizontal_scrollview;
        ImageView imagePdf, imagePdf1, imagePdf2;
        TextView namePdf,namePdf1, namePdf2;
        FrameLayout pdf_layout, pdf_layout1, pdf_layout2;
        LinearLayout layout_recylerview;
        RoundedImageView  imageView2, imageView3,imageView1;
        TextView count_like;
        Button button_like;
        FrameLayout frame1,frame2,frame3;
        View separator;
        GridLayout gridLayout;

        ChatHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            text = itemView.findViewById(R.id.message);
            date = itemView.findViewById(R.id.date);
            listitem3 = itemView.findViewById(R.id.listitem3);
            count_like= itemView.findViewById(R.id.count_like);
            imageView1 = itemView.findViewById(R.id.imageView1);
            imageView2 = itemView.findViewById(R.id.imageView2);
            imageView3 = itemView.findViewById(R.id.imageView3);
            imagePdf = itemView.findViewById(R.id.imagePdf);
            namePdf = itemView.findViewById(R.id.namePdf);
            imagePdf1 = itemView.findViewById(R.id.imagePdf1);
            namePdf1 = itemView.findViewById(R.id.namePdf1);
            imagePdf2 = itemView.findViewById(R.id.imagePdf2);
            namePdf2 = itemView.findViewById(R.id.namePdf2);
            pdf_layout = itemView.findViewById(R.id.pdf_layout);
            pdf_layout1 = itemView.findViewById(R.id.pdf_layout1);
            pdf_layout2 = itemView.findViewById(R.id.pdf_layout2);
//            horizontal_scrollview = itemView.findViewById(R.id.horizontal_scrollview);
            gridLayout = itemView.findViewById(R.id.grid_attach);
//            layout_recylerview = itemView.findViewById(R.id.layout_recylerview);
            button_like = itemView.findViewById(R.id.button_like);
            frame1= itemView.findViewById(R.id.frame1);
            frame2= itemView.findViewById(R.id.frame2);
            frame3= itemView.findViewById(R.id.frame3);
            separator = itemView.findViewById(R.id.separator);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecyclerviewMessage.this.recyclerViewItemClickListener.onItemClick(itemView,getLayoutPosition());

                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    RecyclerviewMessage.this.recyclerViewItemClickListener.onLongItemClick(itemView,getLayoutPosition());
                    return false;
                }
            });
        }
    }

}
