package com.shubham.signuppage.Models

class User {
    var Password: String? = null
    var ID: Long = 0
    @JvmField
    var Phone: String? = null
    @JvmField
    var FirstName: String? = null
    @JvmField
    var LastName: String? = null
//    @JvmField
//    var ImageUrl: String? = null
    var EntryDate: String? = null
    @JvmField
    var Key: String? = null
}