package com.shubham.signuppage.Chat;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.shubham.signuppage.R;
import Interfaces.RecyclerViewItemClickListener;
import com.shubham.signuppage.Room.Member;
import com.shubham.signuppage.Room.MembersViewModel;
import com.shubham.signuppage.Services.LocalUserService;

import java.util.List;
import java.util.Objects;

public class AllContacts extends AppCompatActivity {
    private MembersViewModel membersViewModel;
    Toolbar toolbar;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            setTheme(R.style.MainActivity3_Dark);
        else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_all_contacts);
        toolbar = findViewById(R.id.toolbar_members2);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_dark);
        else {
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        }
        setSupportActionBar(toolbar);
        recyclerView = findViewById(R.id.members_recycler_view2);
        final MembersRecyclerViewAdapter membersRecyclerViewAdapter = new MembersRecyclerViewAdapter(getApplicationContext());
        recyclerView.setAdapter(membersRecyclerViewAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setHasFixedSize(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        membersViewModel = ViewModelProviders.of(this).get(MembersViewModel.class);
        membersViewModel.getAllMembers(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName).observe(this, new Observer<List<Member>>() {
            @Override
            public void onChanged(List<Member> members) {
                membersRecyclerViewAdapter.submitList(members);
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        GetMembersTask membersTask = new GetMembersTask();
        membersTask.execute();

        membersRecyclerViewAdapter.setOnItemClickListener(new RecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                //view.findViewById(.)

            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.all_members_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_refresh:
        }
        return super.onOptionsItemSelected(item);
    }

    public class GetMembersTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName != null) {
                FirebaseDatabase.getInstance().getReference().child("Workplaces").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey).child("Members")
                        .addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                                if (!dataSnapshot.getKey().equals(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)) {
                                    String phone = Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString();
                                    membersViewModel.insert(new Member(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Name").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString(),
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            "",
                                            null,0,null));
                                }
                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                                membersViewModel.deleteMMember(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString());
                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
            }
            return null;
        }
    }
}
