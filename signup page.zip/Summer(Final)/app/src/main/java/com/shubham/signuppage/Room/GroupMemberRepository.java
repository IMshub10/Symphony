package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class GroupMemberRepository {
    private GroupMemberDao groupMemberDao;
    private LiveData<List<GroupMember>> allMembersOfAGroup;

    public GroupMemberRepository(Application application){
        GroupMemberDatabase groupMemberDatabase = GroupMemberDatabase.getInstance(application);
        groupMemberDao = groupMemberDatabase.groupMemberDao();
    }

    public  void insert(GroupMember groupMember){
        new InsertMemberTask(groupMemberDao).execute(groupMember);
    }
    public  void delete(GroupMember groupMember){
        new DeleteTask(groupMemberDao).execute(groupMember);
    }
    public  void update(GroupMember groupMember){
        new UpdateTask(groupMemberDao).execute(groupMember);
    }

    public void deleteAll(){
        new DeleteAllMembers(groupMemberDao).execute();
    }

    public  LiveData<List<GroupMember>> getAllMembersOfAGroup(String groupId){
        allMembersOfAGroup = groupMemberDao.getMembersOfAGroup(groupId);
        return  allMembersOfAGroup;
    }

    public LiveData<List<GroupMember>> getAllMembers(){
        return groupMemberDao.getAllMembers();
    }

    private  static  class InsertMemberTask extends AsyncTask<GroupMember,Void,Void> {
        private GroupMemberDao groupMemberDao;
        private  InsertMemberTask(GroupMemberDao groupMemberDao){
            this.groupMemberDao = groupMemberDao;
        }
        @Override
        protected Void doInBackground(GroupMember... groupMembers) {
            groupMemberDao.insert(groupMembers[0]);
            return null;
        }

    }
    private  static  class UpdateTask extends AsyncTask<GroupMember,Void,Void> {

        private GroupMemberDao groupMemberDao;
        private  UpdateTask(GroupMemberDao groupMemberDao){
            this.groupMemberDao = groupMemberDao;
        }

        @Override
        protected Void doInBackground(GroupMember... GroupMembers) {
            groupMemberDao.update(GroupMembers[0]);
            return null;
        }

    }
    private  static  class DeleteTask extends  AsyncTask<GroupMember,Void,Void>{
        private GroupMemberDao groupMemberDao;
        private  DeleteTask(GroupMemberDao groupMemberDao){
            this.groupMemberDao = groupMemberDao;
        }

        @Override
        protected Void doInBackground(GroupMember... GroupMembers) {
            groupMemberDao.delete(GroupMembers[0]);
            return null;
        }
    }
    private  static  class DeleteAllMembers extends  AsyncTask<Void,Void,Void>{
        private GroupMemberDao groupMemberDao;
        private  DeleteAllMembers(GroupMemberDao groupMemberDao){
            this.groupMemberDao = groupMemberDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            groupMemberDao.deleteAllMembers();
            return null;
        }
    }
}