package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class GroupMemberViewModel extends AndroidViewModel {

    private GroupMemberRepository groupMemberRepository;
    private LiveData<List<GroupMember>> allMember;

    public GroupMemberViewModel(@NonNull Application application) {
        super(application);
        groupMemberRepository = new GroupMemberRepository(application);
    }

    public void insert (GroupMember groupMember) { groupMemberRepository.insert(groupMember); }
    public void update (GroupMember groupMember) { groupMemberRepository.update(groupMember); }
    public void delete (GroupMember groupMember) { groupMemberRepository.delete(groupMember); }
    public void deleteAll () { groupMemberRepository.deleteAll(); }

    public LiveData<List<GroupMember>> getAllMemberOfAGroup(String groupKey) { return groupMemberRepository.getAllMembersOfAGroup(groupKey); }

    public LiveData<List<GroupMember>> getAllMember() {
        allMember = groupMemberRepository.getAllMembers();
        return allMember;
    }
}
