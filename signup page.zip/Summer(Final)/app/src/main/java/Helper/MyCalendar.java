package Helper;

public class MyCalendar {

    public String StartTime(){
        String hour;
        String min;

        if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) < 10) {
            hour = "0" + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY));
        } else {
            hour = String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY));
        }
        if (java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE) < 10) {
            min = "0" + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE));
        } else {
            min = String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE));
        }
        return hour + ":" + min;
    }
    public String EndTime(){
        String hour1;
        String min;

        if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY )+1 < 10) {
            hour1 = "0" + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY )+1);
        } else {
            if (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY )+1 <23) {
                hour1 = String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY )+1);
            }else {
                hour1 = String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY ));
            }
        }
        if (java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE) < 10) {
            min = "0" + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE));
        } else {
            min = String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE));
        }
        return hour1 + ":" + min;
    }

}
