package com.shubham.signuppage.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface GroupMemberDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(GroupMember groupMember);

    @Update
    void update(GroupMember groupMember);

    @Delete
    void delete(GroupMember groupMember);

    @Query("Delete From group_member_table ")
    void deleteAllMembers();

    @Query("SELECT * FROM group_member_table WHERE groupKey = :grpKey ")
    LiveData<List<GroupMember>> getMembersOfAGroup(String grpKey);

    @Query("SELECT * FROM group_member_table")
    LiveData<List<GroupMember>> getAllMembers();

}
