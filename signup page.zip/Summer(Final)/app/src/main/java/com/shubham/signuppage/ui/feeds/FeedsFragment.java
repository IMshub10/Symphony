package com.shubham.signuppage.ui.feeds;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import android.widget.RelativeLayout;

import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.shubham.signuppage.Chat.ChatFinalActivity;
import com.shubham.signuppage.Chat.RecyclerViewSearch;
import com.shubham.signuppage.Chat.SearchActivity;
import com.shubham.signuppage.Main3Activity;
import com.shubham.signuppage.Models.Files;
import com.shubham.signuppage.Models.FilesUri;
import com.shubham.signuppage.MyLinearLayoutManager;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.GroupMessage;
import com.shubham.signuppage.Room.Message;
import com.shubham.signuppage.Room.ScheduleViewModel;
import com.shubham.signuppage.Room.SearchMessage;
import com.shubham.signuppage.Room.SearchMessageViewModel;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.Services.Tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import Helper.DownloadFiles;
import Interfaces.DownloadFeedFiles;
import Interfaces.RecyclerViewItemClickListener;

public class FeedsFragment extends Fragment {
    private FeedsViewModel feedsViewModel;
    private SwipeRefreshLayout swipeRefreshLayout;

    private BottomNavigationView nav_view;
    private CoordinatorLayout colorLayout;
    private LinearLayout bottom_sheet_feeds;
    private BottomSheetBehavior bottomSheetBehavior;
    private ImageView sendFeed;
    private ImageView attach;
    private CardView cardView;
    private EditText feed_edit_text;
    private List<Uri> imageFiles, videoFiles;
    private List<FilesUri> files;
    private ImageView addVideo, addImage;
    private LinearLayout layout1;
    //    ProgressBar progress;
    private HorizontalScrollView scrollView_createFeeds;
    private VideoView videoView;
    private NotificationManagerCompat notificationManagerCompat;
    private String selectedVideoPath;

    private CardView pdfCardView;
    private ImageView imagePdf;
    private TextView namePdf;
    private CardView pdfCardView1;
    private ImageView imagePdf1;
    private TextView namePdf1;
    private CardView pdfCardView2;
    private ImageView imagePdf2;
    private TextView namePdf2;

    Toolbar toolbar_main_3;

    //Recyclerview Search
    RecyclerView recyclerview_feed_search;
    RecyclerViewSearch recyclerViewSearch;
    private SearchMessageViewModel searchMessageViewModel;

    private String editText = " ";
    private static final String CHANNEL_1_ID = "channel1";
    //private String uniqueid;
    private FeedsRecyclerViewAdapter adapter;
    private ImageView camera;
    private RelativeLayout pdf_layout, pdf_layout1, pdf_layout2;

    private ImageView imageCancel, imageCancel1, imageCancel2, videoCancel;
    private ImageView galleryImage, galleryImage1, galleryImage2;
    private ImageView pdfCancel, pdfCancel1, pdfCancel2;
    private static final int REQUEST_CAPTURE_IMAGE = 100;

    TextView nullWorkplace;
    private static final int PICK_FILE_REQUEST = 4;
    private Parcelable recyclerViewState;
    SearchView searchView;
    RecyclerView recyclerView;

    String CurrentWorkplaceName, CurrentWorkplaceKey;
    private Context context;

    public void init() {
        context = getContext();
        CurrentWorkplaceKey = LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceKey;
        CurrentWorkplaceName = LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_feeds, container, false);
        setHasOptionsMenu(true);
        init();
        swipeRefreshLayout = root.findViewById(R.id.swipeRefereshLayout);
        recyclerView = root.findViewById(R.id.feeds_recyclerview);
        adapter = new FeedsRecyclerViewAdapter(getContext());
        recyclerView.setAdapter(adapter);
        final MyLinearLayoutManager layoutManager = new MyLinearLayoutManager(getContext(), true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemViewCacheSize(20);
        recyclerView.setNestedScrollingEnabled(false);
        ((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
        nav_view = getActivity().findViewById(R.id.nav_view);
        toolbar_main_3 = getActivity().findViewById(R.id.toolbar);
        colorLayout = root.findViewById(R.id.colorLayout);
        //Bottom Sheet Code
        bottom_sheet_feeds = root.findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottom_sheet_feeds);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        //int height = (int) getResources().getDisplayMetrics().density*(56+8) ;
        // bottomSheetBehavior.setPeekHeight(height);


        //Search Functions
        recyclerview_feed_search = root.findViewById(R.id.recyclerview_feed_search);
        recyclerViewSearch = new RecyclerViewSearch(getContext());
        recyclerview_feed_search.setAdapter(recyclerViewSearch);
        final MyLinearLayoutManager layoutManager1 = new MyLinearLayoutManager(getContext(), true);
        recyclerview_feed_search.setLayoutManager(layoutManager1);
        recyclerview_feed_search.setHasFixedSize(true);
        recyclerview_feed_search.setItemViewCacheSize(20);
        recyclerview_feed_search.setNestedScrollingEnabled(false);

        nullWorkplace = root.findViewById(R.id.nullWorkplace);
        camera = root.findViewById(R.id.camera);

        ImageView gallery = root.findViewById(R.id.gallery);
        sendFeed = root.findViewById(R.id.send_feed);
        TextView name_bottom = root.findViewById(R.id.name_bottom);
        pdfCardView = root.findViewById(R.id.pdf_card);
        imagePdf = root.findViewById(R.id.imagePdf);
        namePdf = root.findViewById(R.id.namePdf);
        pdfCardView1 = root.findViewById(R.id.pdf_card1);
        imagePdf1 = root.findViewById(R.id.imagePdf1);
        namePdf1 = root.findViewById(R.id.namePdf1);
        pdfCardView2 = root.findViewById(R.id.pdf_card2);
        imagePdf2 = root.findViewById(R.id.imagePdf2);
        namePdf2 = root.findViewById(R.id.namePdf2);
        pdf_layout = root.findViewById(R.id.pdf_layout);
        pdf_layout1 = root.findViewById(R.id.pdf_layout1);
        pdf_layout2 = root.findViewById(R.id.pdf_layout2);
        pdfCancel = root.findViewById(R.id.pdfCancel);
        pdfCancel1 = root.findViewById(R.id.pdfCancel1);
        pdfCancel2 = root.findViewById(R.id.pdfCancel2);
        imageCancel = root.findViewById(R.id.imageCancel);
        imageCancel1 = root.findViewById(R.id.imageCancel1);
        imageCancel2 = root.findViewById(R.id.imageCancel2);
        videoCancel = root.findViewById(R.id.videoCanwcel);
        cardView = root.findViewById(R.id.card);
        imageFiles = new ArrayList<Uri>();
        files = new ArrayList<FilesUri>();
        videoFiles = new ArrayList<Uri>();
        feed_edit_text = root.findViewById(R.id.bs_text);
        addImage = root.findViewById(R.id.addImage);
        addVideo = root.findViewById(R.id.addVideo);
        layout1 = root.findViewById(R.id.layout);
        galleryImage = root.findViewById(R.id.galleryImage);
        galleryImage1 = root.findViewById(R.id.galleryImage1);
        galleryImage2 = root.findViewById(R.id.galleryImage2);

//       progress = root.findViewById(R.id.progress);
        scrollView_createFeeds = root.findViewById(R.id.scroll);
        videoView = root.findViewById(R.id.video);
        attach = root.findViewById(R.id.attach);
        notificationManagerCompat = NotificationManagerCompat.from(this.getActivity());
        name_bottom.setText("Create New Feed");

        if (LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName == null) {
            nullWorkplace.setVisibility(View.VISIBLE);
        } else {
            nullWorkplace.setVisibility(View.GONE);
        }

        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageFiles.size() >= 3) {
                    addImage.setVisibility(View.GONE);
                } else {
                    addImage.setVisibility(View.VISIBLE);
                }
                if (videoFiles.size() >= 1) {
                    addVideo.setVisibility(View.GONE);
                } else {
                    addVideo.setVisibility(View.VISIBLE);
                }
                if (imageFiles.size() <= 2 || videoFiles.size() < 1) {
                    if (cardView.getVisibility() == View.INVISIBLE) {
                        cardView.setVisibility(View.VISIBLE);
                    } else if (cardView.getVisibility() == View.VISIBLE) {
                        cardView.setVisibility(View.INVISIBLE);
                    }
                } else {
                    Toast.makeText(getContext(), "A maximum of 3 images, 1 video and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
                }
//                if (cardView.getVisibility() == View.INVISIBLE && imageFiles.size() < 3 && videoFiles.size() < 1) {
//                    cardView.setVisibility(View.VISIBLE);
//
//                } else {
//                    cardView.setVisibility(View.INVISIBLE);
//                }
//                if (videoFiles.size() == 1) {
//                    Snackbar snackbar = Snackbar.make(bottom_sheet_feeds, "You can select only 1 Video", Snackbar.LENGTH_SHORT);
//                    snackbar.show();
//
//                } else if (imageFiles.size() == 3) {
//                    Snackbar snackbar = Snackbar.make(bottom_sheet_feeds, "You can select only 3 images", Snackbar.LENGTH_SHORT);
//                    snackbar.show();
//                }
            }
        });

        attach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (files.size() < 3) {
                    if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 4);
                    } else {
                        getFile();
                    }
                } else {
                    Toast.makeText(getContext(), "A maximum of 3 images, 1 video and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();

                }

                    /*
                }else if(videoFiles.size()==1){
                    Snackbar snackbar=Snackbar.make(frameLayout,"You can select only 1 Video",Snackbar.LENGTH_SHORT);
                    snackbar.show();

                }else {
                    Snackbar snackbar=Snackbar.make(frameLayout,"You can select only 3 images",Snackbar.LENGTH_SHORT);
                    snackbar.show();


                     */

            }
        });

        /*
        MyItemTouchHelper myItemTouchHelper = new MyItemTouchHelper(getContext(),0,ItemTouchHelper.LEFT, new Swipe(){
            @Override
            public void showReplyUI(int position) {
                feed_edit_text.requestFocus();
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(feed_edit_text, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(myItemTouchHelper);
        itemTouchHelper.attachToRecyclerView(recyclerView);

         */
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (files.size() < 3) {
                    //openCameraIntent();
                } else {
                    Toast.makeText(getContext(), "A maximum of 3 images, 1 video and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        sendFeed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{(Manifest.permission.WRITE_EXTERNAL_STORAGE)}, 10);
                } else {
                    cardView.setVisibility(View.INVISIBLE);
                    if (Tools.isNetworkAvailable(getContext())) {
                        editText = feed_edit_text.getText().toString().trim();
                        if (editText.length() > 2) {
                            FeedTask feedTask = new FeedTask(imageFiles, videoFiles, files);
                            feedTask.execute();
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                            feed_edit_text.setText(null);
                            imageFiles = new ArrayList<>();
                            files = new ArrayList<>();
                            videoFiles = new ArrayList<>();
                            scrollView_createFeeds.setVisibility(View.INVISIBLE);
                            layout1.setVisibility(View.INVISIBLE);
                            galleryImage.setImageBitmap(null);
                            galleryImage.setVisibility(View.GONE);
                            imageCancel.setVisibility(View.GONE);
                            galleryImage1.setImageBitmap(null);
                            galleryImage1.setVisibility(View.GONE);
                            imageCancel1.setVisibility(View.GONE);
                            galleryImage2.setImageBitmap(null);
                            galleryImage2.setVisibility(View.GONE);
                            imageCancel2.setVisibility(View.GONE);
                            pdfCardView.setVisibility(View.GONE);
                            imagePdf.setVisibility(View.GONE);
                            imagePdf.setImageBitmap(null);
                            namePdf.setVisibility(View.GONE);
                            pdfCancel.setVisibility(View.GONE);
                            pdf_layout.setVisibility(View.GONE);
                            pdfCardView1.setVisibility(View.GONE);
                            imagePdf1.setVisibility(View.GONE);
                            imagePdf1.setImageBitmap(null);
                            namePdf1.setVisibility(View.GONE);
                            pdfCancel1.setVisibility(View.GONE);
                            pdf_layout1.setVisibility(View.GONE);
                            pdfCardView2.setVisibility(View.GONE);
                            imagePdf2.setVisibility(View.GONE);
                            imagePdf2.setImageBitmap(null);
                            namePdf2.setVisibility(View.GONE);
                            pdfCancel2.setVisibility(View.GONE);
                            pdf_layout2.setVisibility(View.GONE);
                            videoView.setVideoURI(null);
                            videoView.stopPlayback();
                            videoView.setVisibility(View.GONE);
                            videoCancel.setVisibility(View.GONE);

                            //Intent intent = new Intent(getActivity().getApplicationContext(), Main3Activity.class);
                            //startActivity(intent);
                        } else {
                            Snackbar snackbar = Snackbar.make(bottom_sheet_feeds, "Text Cannot be Empty", Snackbar.LENGTH_SHORT);
                            snackbar.show();
                        }
                    } else {
                        Snackbar snackbar1 = Snackbar.make(bottom_sheet_feeds, "Internet is  Not Available", Snackbar.LENGTH_SHORT);
                        snackbar1.show();
                    }

                }
            }
        });

        feed_edit_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cardView.setVisibility(View.INVISIBLE);
            }
        });

        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageFiles.size() < 3 || videoFiles.size() < 1) {
                    if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 1);
                    } else {
                        getPhoto();
                    }

                } else {
                    Toast.makeText(getContext(), "A maximum of 3 images, 1 video and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        addVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (videoFiles.size() < 1) {
                    if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{(Manifest.permission.READ_EXTERNAL_STORAGE)}, 2);
                    } else {
                        getVideo();
                    }
                } else {
                    Toast.makeText(getContext(), "A maximum of 3 images, 1 video and 3 files can be uploaded.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bottomSheetBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                    colorLayout.setBackgroundColor(0x66000000);
                    //nav_view.setVisibility(View.INVISIBLE);
                    nav_view.animate().translationY(nav_view.getHeight()).setDuration(500).start();
                } else if (newState == BottomSheetBehavior.STATE_COLLAPSED || newState == BottomSheetBehavior.STATE_HIDDEN) {
                    colorLayout.setBackgroundColor(0x00000000);
                    nav_view.animate()
                            .translationY(0).setDuration(500).start();
                    nav_view.setVisibility(View.VISIBLE);
                    feed_edit_text.clearFocus();
                    InputMethodManager imm = (InputMethodManager)
                            getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(feed_edit_text.getWindowToken(), 0);
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                        }
                    }, 600);
                } else if (newState == BottomSheetBehavior.STATE_DRAGGING || newState == BottomSheetBehavior.STATE_SETTLING) {
                    colorLayout.setBackgroundColor(0x66000000);
                    cardView.setVisibility(View.INVISIBLE);
                } else if (newState == BottomSheetBehavior.STATE_HALF_EXPANDED) {
                    colorLayout.setBackgroundColor(0x66000000);
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                if (slideOffset == 0.75) {
                    colorLayout.setBackgroundColor(0x66000000);
                }
            }
        });

        feedsViewModel = ViewModelProvider.AndroidViewModelFactory.getInstance(getActivity().getApplication()).create(FeedsViewModel.class);
        searchMessageViewModel = ViewModelProvider.AndroidViewModelFactory.getInstance(getActivity().getApplication()).create(SearchMessageViewModel.class);

        //feedsViewModel = new ViewModelProvider(this).get(FeedsViewModel.class);
        feedsViewModel.getAllFeeds(CurrentWorkplaceKey).observe(getViewLifecycleOwner(), new Observer<List<Feed>>() {
            @Override
            public void onChanged(List<Feed> feeds) {
                //update Recyclerview
                adapter.submitList(feeds);
                //new ShowFeeds(feedsViewModel, workPlace).execute();
            }
        });
        searchMessageViewModel.getMessages(CurrentWorkplaceKey, "").observe(getViewLifecycleOwner(), new Observer<List<SearchMessage>>() {
            @Override
            public void onChanged(List<SearchMessage> searchMessages) {
                recyclerViewSearch.submitList(searchMessages);
            }
        });

        recyclerViewSearch.setOnItemClickListener(new RecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        });

        swipeRefreshLayout.setOnRefreshListener(() -> {

            GetFeedTask getFeedTask = new GetFeedTask();
            getFeedTask.execute();
            swipeRefreshLayout.setRefreshing(false);
        });
        GetFeedTask getFeedTask = new GetFeedTask();
        getFeedTask.execute();
        Download();
        return root;
    }


    public void Download() {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{(Manifest.permission.WRITE_EXTERNAL_STORAGE)}, 100);
        } else {
            adapter.DownloadFilesFeed(new DownloadFeedFiles() {
                @Override
                public void onItemClick(Feed feed, int item_position, int file_position) {
                    new DownloadFiles(getContext())
                            .DownloadFeedFile(feed.getFilesUrl().get(file_position).getUrl(),
                                    feed.getFilesUrl().get(file_position).getName(),
                                    feed.getFilesUrl().get(file_position).getType());
                }
            });
        }

    }

    public void getPhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, 4);
        startActivityForResult(intent, 1);
    }

    public void getFile() {
        String[] mimetypes = {"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/pdf", "text/plain", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"};
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimetypes);
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    public void getVideo() {
        //Get Video from Gallery | Storage
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 2);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getPhoto();
            }
        } else if (requestCode == 2) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getVideo();
            }
        } else if (requestCode == 4) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getFile();
            }
        } else if (requestCode == 10) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            }
        } else if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Uri imageFile;
        if (requestCode == 1 && resultCode == Activity.RESULT_OK && data != null) {
            try {
                imageFile = data.getData();
                scrollView_createFeeds.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.VISIBLE);
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getActivity().getContentResolver(), imageFile);
                //rofImageView.setImageBitmap(bitmap);
                cardView.setVisibility(View.INVISIBLE);
                if (imageFiles.size() >= 2) {
                    addImage.setVisibility(View.GONE);
                }
                if (galleryImage.getVisibility() == View.GONE) {
                    Uri uri = data.getData();
                    imageFiles.add(data.getData());
                    galleryImage.setVisibility(View.VISIBLE);
                    imageCancel.setVisibility(View.VISIBLE);
                    galleryImage.setImageBitmap(getResizedBitmap(bitmap, 250));
                    imageCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            galleryImage.setImageBitmap(null);
                            galleryImage.setVisibility(View.GONE);
                            imageCancel.setVisibility(View.GONE);
                            imageFiles.remove(uri);
                        }
                    });
                } else if (galleryImage1.getVisibility() == View.GONE) {
                    imageFiles.add(data.getData());
                    Uri uri = data.getData();
                    galleryImage1.setVisibility(View.VISIBLE);
                    imageCancel1.setVisibility(View.VISIBLE);
                    galleryImage1.setImageBitmap(getResizedBitmap(bitmap, 250));
                    imageCancel1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            galleryImage1.setImageBitmap(null);
                            galleryImage1.setVisibility(View.GONE);
                            imageCancel1.setVisibility(View.GONE);
                            imageFiles.remove(uri);
                        }
                    });
                } else if (galleryImage2.getVisibility() == View.GONE) {
                    Uri uri = data.getData();
                    imageFiles.add(data.getData());
                    galleryImage2.setVisibility(View.VISIBLE);
                    imageCancel2.setVisibility(View.VISIBLE);
                    galleryImage2.setImageBitmap(getResizedBitmap(bitmap, 250));
                    imageCancel2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            galleryImage2.setImageBitmap(null);
                            galleryImage2.setVisibility(View.GONE);
                            imageCancel2.setVisibility(View.GONE);
                            imageFiles.remove(uri);
                        }
                    });
                }
                /*
                if (imageFiles.size() == 1) {
                    imageCancel.setVisibility(View.VISIBLE);
                    galleryImage.setVisibility(View.VISIBLE);
                    galleryImage.setImageBitmap(getResizedBitmap(bitmap, 250));
                } else if (imageFiles.size() == 2) {
                    imageCancel1.setVisibility(View.VISIBLE);
                    galleryImage1.setVisibility(View.VISIBLE);
                    galleryImage1.setImageBitmap(getResizedBitmap(bitmap, 250));
                } else if (imageFiles.size() == 3) {
                    imageCancel2.setVisibility(View.VISIBLE);
                    galleryImage2.setVisibility(View.VISIBLE);
                    galleryImage2.setImageBitmap(getResizedBitmap(bitmap, 250));
                }

                 */

                //ImageView imageView = new ImageView(this.getContext());
                //imageView.setId(View.generateViewId());

                //imageView.setImageBitmap(getResizedBitmap(bitmap, 250));
                //this.addViewX(imageView, 400, 400);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (requestCode == 2 && resultCode == Activity.RESULT_OK) {
            selectedVideoPath = getPath(data.getData());
            /*:
            try {
                if(selectedVideoPath == null) {
                    finish();
                } else {
                    videoView.setVisibility(View.VISIBLE);
                    videoView.setVideoPath(selectedVideoPath);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(600, 600);
                    layoutParams.setMargins(20, 20, 20, 20);
                    layoutParams.gravity=Gravity.CENTER;
                    videoView.setLayoutParams(layoutParams);

                }
            } catch (Exception e) {

                e.printStackTrace();
            }

             */
            if (data != null) {
                Uri contentURI = data.getData();
                videoFiles.add(contentURI);
                scrollView_createFeeds.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.VISIBLE);
                String selectedVideoPath = getPath(contentURI);
                saveVideoToInternalStorage(selectedVideoPath);
                cardView.setVisibility(View.INVISIBLE);
                videoView.setVisibility(View.VISIBLE);
                videoCancel.setVisibility(View.VISIBLE);
                videoView.setVideoURI(contentURI);
                //videoView.requestFocus();
                videoView.start();
                if (videoFiles.size() >= 1) {
                    addVideo.setVisibility(View.GONE);
                }
                videoCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        videoFiles.clear();
                        videoView.setVideoURI(null);
                        videoView.setVisibility(View.GONE);
                        videoCancel.setVisibility(View.GONE);
                    }
                });


            }

        } else if (requestCode == 3 && resultCode == Activity.RESULT_OK) {
            try {
                imageFile = data.getData();
                imageFiles.add(data.getData());
                scrollView_createFeeds.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.VISIBLE);
                Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
                //rofImageView.setImageBitmap(bitmap);
                cardView.setVisibility(View.INVISIBLE);

                ImageView imageView = new ImageView(this.getContext());
                imageView.setImageBitmap(getResizedBitmap(imageBitmap, 250));
                this.addViewX(imageView, 400, 400);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (requestCode == PICK_FILE_REQUEST && resultCode == Activity.RESULT_OK && data.getData() != null) {
            layout1.setVisibility(View.VISIBLE);
            scrollView_createFeeds.setVisibility(View.VISIBLE);
            if (files.size() <= 3) {
                if (imagePdf.getVisibility() == View.GONE) {

                    pdfCardView.setVisibility(View.VISIBLE);
                    pdf_layout.setVisibility(View.VISIBLE);
                    namePdf.setVisibility(View.VISIBLE);
                    imagePdf.setVisibility(View.VISIBLE);
                    pdfCancel.setVisibility(View.VISIBLE);
                    try {
                        String path = new File(data.getData().getPath()).getAbsolutePath();
                        Uri uri = data.getData();
                        String filename;
                        Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
                        String mime = getContext().getContentResolver().getType(uri);
                        switch (mime) {
                            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
                                Drawable myDrawable = getContext().getDrawable(R.drawable.ic_docx_file_format);
                                imagePdf.setImageDrawable(myDrawable);
                                break;
                            }
                            case "application/pdf": {
                                Drawable myDrawable = getContext().getDrawable(R.drawable.ic_pdf_file_format_symbol);
                                imagePdf.setImageDrawable(myDrawable);
                                break;
                            }
                            case "text/plain": {
                                Drawable myDrawable = getContext().getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                                imagePdf.setImageDrawable(myDrawable);
                                break;
                            }
                            case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
                                Drawable myDrawable = getContext().getDrawable(R.drawable.ic_xls_file_format_symbol);
                                imagePdf.setImageDrawable(myDrawable);
                                break;
                            }
                            default: {
                                Drawable myDrawable = getContext().getDrawable(R.drawable.file);
                                imagePdf.setImageDrawable(myDrawable);
                                break;
                            }
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();
                            namePdf.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            files.add(filesUri);

//                            imagePdf.setOnClickListener(new View.OnClickListener() {
//                                @Override
//                                public void onClick(View v) {
//
//                                    Toast.makeText(getContext(), String.valueOf(files.size()), Toast.LENGTH_SHORT).show();
//                                }
//                            });
                            pdfCancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // layout1.removeView(v);
                                    pdfCardView.setVisibility(View.GONE);
                                    pdf_layout.setVisibility(View.GONE);
                                    namePdf.setVisibility(View.GONE);
                                    imagePdf.setVisibility(View.GONE);
                                    imagePdf.setImageBitmap(null);
                                    files.remove(filesUri);
                                }
                            });

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (imagePdf1.getVisibility() == View.GONE) {
                    pdfCardView1.setVisibility(View.VISIBLE);
                    pdf_layout1.setVisibility(View.VISIBLE);
                    namePdf1.setVisibility(View.VISIBLE);
                    imagePdf1.setVisibility(View.VISIBLE);
                    pdfCancel1.setVisibility(View.VISIBLE);
                    try {
                        String path = new File(data.getData().getPath()).getAbsolutePath();
                        Uri uri = data.getData();
                        String filename;
                        Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
                        String mime = getContext().getContentResolver().getType(uri);
                        if (mime.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_docx_file_format);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else if (mime.equals("application/pdf")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_pdf_file_format_symbol);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else if (mime.equals("text/plain")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else if (mime.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_xls_file_format_symbol);
                            imagePdf1.setImageDrawable(myDrawable);
                        } else {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.file);
                            imagePdf1.setImageDrawable(myDrawable);
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();
                            namePdf1.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            files.add(filesUri);
                            pdfCancel1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // layout1.removeView(v);
                                    pdfCardView1.setVisibility(View.GONE);
                                    pdf_layout1.setVisibility(View.GONE);
                                    namePdf1.setVisibility(View.GONE);
                                    imagePdf1.setVisibility(View.GONE);
                                    imagePdf1.setImageBitmap(null);
                                    files.remove(filesUri);
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (imagePdf2.getVisibility() == View.GONE) {
                    pdfCardView2.setVisibility(View.VISIBLE);
                    pdf_layout2.setVisibility(View.VISIBLE);
                    namePdf2.setVisibility(View.VISIBLE);
                    imagePdf2.setVisibility(View.VISIBLE);
                    pdfCancel2.setVisibility(View.VISIBLE);
                    try {

                        String path = new File(data.getData().getPath()).getAbsolutePath();

                        Uri uri = data.getData();

                        String filename;
                        Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
                        String mime = getContext().getContentResolver().getType(uri);
                        if (mime.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_docx_file_format);
                            imagePdf2.setImageDrawable(myDrawable);
                        } else if (mime.equals("application/pdf")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_pdf_file_format_symbol);
                            imagePdf2.setImageDrawable(myDrawable);
                        } else if (mime.equals("text/plain")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_txt_text_file_extension_symbol);
                            imagePdf2.setImageDrawable(myDrawable);
                        } else if (mime.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.ic_xls_file_format_symbol);
                            imagePdf2.setImageDrawable(myDrawable);
                        } else {
                            Drawable myDrawable = getContext().getDrawable(R.drawable.file);
                            imagePdf2.setImageDrawable(myDrawable);
                        }
                        if (cursor == null) {
                            filename = uri.getPath();
                        } else {
                            cursor.moveToFirst();
                            int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);
                            filename = cursor.getString(idx);
                            cursor.close();

                            namePdf2.setText(filename);
                            FilesUri filesUri = new FilesUri(filename, mime, data.getData());
                            files.add(filesUri);
                            pdfCancel2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // layout1.removeView(v);
                                    pdfCardView2.setVisibility(View.GONE);
                                    pdf_layout2.setVisibility(View.GONE);
                                    namePdf2.setVisibility(View.GONE);
                                    imagePdf2.setVisibility(View.GONE);
                                    imagePdf2.setImageBitmap(null);
                                    files.remove(filesUri);
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }

        }
    }


    public void addViewX(ImageView imageView, int width, int height) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(width, height);
        layoutParams.setMargins(20, 20, 20, 20);
        layoutParams.gravity = Gravity.CENTER;
        imageView.setLayoutParams(layoutParams);
        layout1.addView(imageView);
    }

    public String getPath(Uri uri) {
        String[] projection = {MediaStore.Images.Media.DATA};
        //Cursor cursor = getActivity().getContentResolver().query(uri, projection, null, null, null);
        Cursor cursor = getActivity().managedQuery(uri, projection, null, null, null);
        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } else return null;
    }

    private void saveVideoToInternalStorage(String filePath) {
        File newfile;
        try {
            File currentFile = new File(filePath);
            File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + "/demonuts");
            newfile = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".mp4");

            if (!wallpaperDirectory.exists()) {
                wallpaperDirectory.mkdirs();
            }

            if (currentFile.exists()) {

                InputStream in = new FileInputStream(currentFile);
                OutputStream out = new FileOutputStream(newfile);

                // Copy the bits from instream to outstream
                byte[] buf = new byte[1024];
                int len;

                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
                Log.v("vii", "Video file saved successfully.");
            } else {
                Log.v("vii", "Video saving failed. Source file missing.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.feeds_menu, menu);
        MenuItem myActionMenuItem = menu.findItem(R.id.search_feed);
        searchView = (SearchView) myActionMenuItem.getActionView();
        searchView.setQueryHint("Search here");

        searchView.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    nav_view.animate().translationY(nav_view.getHeight()).setDuration(500).start();
                    recyclerView.setVisibility(View.GONE);
                    recyclerview_feed_search.setVisibility(View.VISIBLE);
                }else {
                    nav_view.animate()
                            .translationY(0).setDuration(500).start();
                    nav_view.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.VISIBLE);
                    recyclerview_feed_search.setVisibility(View.GONE);
                    searchMessageViewModel.deleteall();
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                queryFunction(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });
    }

    public void queryFunction(String query) {

        new GetFeedForSearchTask(query.trim()).execute();
    }

    //get feeds from view model for search
    public class GetFeedForSearchTask extends AsyncTask<Void, Void, List<Feed>> {
        private String query;
        public GetFeedForSearchTask(String query) {
            this.query = query;
        }
        @Override
        protected List<Feed> doInBackground(Void... voids) {
            List<Feed> feeds = new ArrayList<>();
             feeds = feedsViewModel.SearchFeeds(CurrentWorkplaceKey,query);
            //Toast.makeText(SearchActivity.this,String.valueOf(messages.size()),Toast.LENGTH_SHORT).show();
            Log.e("Size", String.valueOf(feeds.size()));
            return feeds;
        }
        @Override
        protected void onPostExecute(List<Feed> feeds) {
            super.onPostExecute(feeds);
            for (int i = 0; i < feeds.size(); i++) {
                Feed feed = feeds.get(i);
                String uniquid = UUID.randomUUID().toString();
                searchMessageViewModel.insert(new SearchMessage(uniquid,
                        feed.getCreator(),
                        "",
                        CurrentWorkplaceKey,
                        CurrentWorkplaceName,
                        feed.getCreate_date(),
                        feed.getFeed_text(),
                        String.valueOf(feed.getLikes()),
                        feed.getTimestamp(),
                        "",
                        query));
                Log.e("Insert", "Inserted");
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // int id = item.getItemId();
        switch (item.getItemId()) {
            case R.id.create_feed:
                if (LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName != null) {
//                    Intent intent = new Intent(getContext(), Create_Feed.class);
//                    startActivity(intent)
                    cardView.setVisibility(View.INVISIBLE);
                    feed_edit_text.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(feed_edit_text, InputMethodManager.RESULT_SHOWN);
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                    }, 600);
                    return true;
                } else {
                    //Snackbar snackbar=Snackbar.make(constraintLayout,"Please select a Workplace",Snackbar.LENGTH_SHORT);
                    //snackbar.show();
                    Toast.makeText(getContext(), "Please select a workplace", Toast.LENGTH_SHORT).show();
                    return true;
                }
        }
        return super.onOptionsItemSelected(item);
    }

    private void openCameraIntent() {
        Intent pictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (pictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(pictureIntent, 3);
        }
    }

    @Nullable
    @Override
    public Context getContext() {
        return super.getContext();
    }

    @Override
    public void onResume() {
        super.onResume();
    }


    @Override
    public void onStart() {
        super.onStart();
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{(Manifest.permission.WRITE_EXTERNAL_STORAGE)}, 100);
        }
    }

    public class FeedTask extends AsyncTask<Void, Void, String> {

        private List<Uri> imageFiles1;
        private List<Uri> videoFiles1;
        private List<FilesUri> files1;
        int i = 0, j = 0;
        int x = 0, y = 0;
        String uniqueid = UUID.randomUUID().toString() + LocalUserService.getLocalUserFromPreferences(getContext()).Phone;

        private FeedTask(List<Uri> imageFiles1, List<Uri> videoFiles1, List<FilesUri> files1) {
            this.imageFiles1 = imageFiles1;
            this.videoFiles1 = videoFiles1;
            this.files1 = files1;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            SharedPreferences sharedPreferences2 = getActivity().getApplicationContext().getSharedPreferences("Recent", 0);
            String string2 = new SimpleDateFormat("dd MM yy hh:mm a").format(new Date());
            sharedPreferences2.edit().putString("recent", string2).apply();
            Map<String, String> hashMap = new HashMap();
            hashMap.put("Feed Text", editText);
            String full_Name = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).FirstName + " " +
                    LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).LastName;
            hashMap.put("Creator", full_Name);
            hashMap.put("Workplace", LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceName);
            hashMap.put("Creator Phone", LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Phone);
            hashMap.put("Create Date", sharedPreferences2.getString("recent", null));
            hashMap.put("Unique Id", uniqueid);
            String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
            hashMap.put("Timestamp", timestamp);
            if (imageFiles1.size() != 0) {
                hashMap.put("ImagesNumber", String.valueOf(imageFiles1.size()));
            } else {
                hashMap.put("ImagesNumber", String.valueOf(0));
            }
            if (files1.size() != 0) {
                hashMap.put("FilesNumber", String.valueOf(files1.size()));
            } else {
                hashMap.put("FilesNumber", String.valueOf(0));
            }
            if (imageFiles1.size() == 0 && videoFiles1.size() == 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(1));
            } else if (imageFiles1.size() == 0 && videoFiles1.size() == 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(2));
            } else if (imageFiles1.size() == 0 && videoFiles1.size() != 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(3));
            } else if (imageFiles1.size() == 0 && videoFiles1.size() != 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(4));
            } else if (imageFiles1.size() != 0 && videoFiles1.size() == 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(5));
            } else if (imageFiles1.size() != 0 && videoFiles1.size() == 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(6));
            } else if (imageFiles1.size() != 0 && videoFiles1.size() != 0 && files1.size() == 0) {
                hashMap.put("Ready", String.valueOf(7));
            } else if (imageFiles1.size() != 0 && videoFiles1.size() != 0 && files1.size() != 0) {
                hashMap.put("Ready", String.valueOf(8));
            }

            FirebaseDatabase.getInstance().getReference().child("Feeds")
                    .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                    .child(uniqueid).setValue(hashMap);
            FirebaseDatabase.getInstance().getReference().child("Feeds")
                    .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                    .child(uniqueid).child("Likes").child("x").setValue("1");
        }

        @Override
        protected String doInBackground(Void... voids) {
            SharedPreferences sharedPreferences2 = getActivity().getApplicationContext().getSharedPreferences("Recent", 0);
            try {
                if (files1.size() != 0) {
                    y = files1.size();
                    if (y >= 1) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Feeds")
                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Phone))
                                .child(sharedPreferences2.getString("recent", null)).child("Files").child(String.valueOf(0));
                        storageReference.putFile(files1.get(0).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 1).child("FileUrl").setValue(uri.toString());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 1).child("FileName").setValue(files1.get(0).getName());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 1).child("FileType").setValue(files1.get(0).getType());
                                        Uri uri1 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                        Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                                .setSmallIcon(R.drawable.smiley)
                                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                .setContentTitle(" Success")
                                                .setSound(uri1)
                                                .setContentText(" Images Created ")
                                                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                .build();
                                        notificationManagerCompat.notify(1, notification);
                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.smiley)
                                        .setContentTitle(" Failed")
                                        .setContentText(" Feed Creaion Failed ")
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .build();
                                notificationManagerCompat.notify(1, notification);

                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                long max = taskSnapshot.getTotalByteCount();
                                long current = taskSnapshot.getBytesTransferred();
                                int asd = (int) max;
                                int asdCurrent = (int) current;
                                Notification notification = new NotificationCompat.Builder(getContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                        .setContentTitle("Uploading Files")
                                        .setContentText("Upload in Progress")
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .setOngoing(true)
                                        .setOnlyAlertOnce(true)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setProgress(asd, asdCurrent, false).build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        });
                        ;
                    }
                    if (y >= 2) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Feeds")
                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Phone))
                                .child(sharedPreferences2.getString("recent", null)).child("Files").child(String.valueOf(1));
                        storageReference.putFile(files1.get(1).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 2).child("FileUrl").setValue(uri.toString());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 2).child("FileName").setValue(files1.get(1).getName());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 2).child("FileType").setValue(files1.get(1).getType());
                                        Uri uri1 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                        Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                                .setSmallIcon(R.drawable.smiley)
                                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                .setContentTitle(" Success")
                                                .setSound(uri1)
                                                .setContentText(" Images Created ")
                                                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                .build();
                                        notificationManagerCompat.notify(1, notification);
                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.smiley)
                                        .setContentTitle(" Failed")
                                        .setContentText(" Feed Creaion Failed ")
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .build();
                                notificationManagerCompat.notify(1, notification);

                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                long max = taskSnapshot.getTotalByteCount();
                                long current = taskSnapshot.getBytesTransferred();
                                int asd = (int) max;
                                int asdCurrent = (int) current;
                                Notification notification = new NotificationCompat.Builder(getContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                        .setContentTitle("Uploading Files")
                                        .setContentText("Upload in Progress")
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .setOngoing(true)
                                        .setOnlyAlertOnce(true)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setProgress(asd, asdCurrent, false).build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        });
                        ;
                    }
                    if (y == 3) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Feeds")
                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Phone))
                                .child(sharedPreferences2.getString("recent", null)).child("Files").child(String.valueOf(2));
                        storageReference.putFile(files1.get(2).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 3).child("FileUrl").setValue(uri.toString());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 3).child("FileName").setValue(files1.get(2).getName());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + 3).child("FileType").setValue(files1.get(2).getType());
                                        Uri uri1 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                        Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                                .setSmallIcon(R.drawable.smiley)
                                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                .setContentTitle(" Success")
                                                .setSound(uri1)
                                                .setContentText(" Images Created ")
                                                .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                .build();
                                        notificationManagerCompat.notify(1, notification);
                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.smiley)
                                        .setContentTitle(" Failed")
                                        .setContentText(" Feed Creaion Failed ")
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .build();
                                notificationManagerCompat.notify(1, notification);

                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                long max = taskSnapshot.getTotalByteCount();
                                long current = taskSnapshot.getBytesTransferred();
                                int asd = (int) max;
                                int asdCurrent = (int) current;
                                Notification notification = new NotificationCompat.Builder(getContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                        .setContentTitle("Uploading Files")
                                        .setContentText("Upload in Progress")
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .setOngoing(true)
                                        .setOnlyAlertOnce(true)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setProgress(asd, asdCurrent, false).build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        });
                        ;
                    }
                    /*
                    while (j < files1.size()) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Feeds")
                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Phone))
                                .child(sharedPreferences2.getString("recent", null)).child("Files").child(String.valueOf(j));
                        storageReference.putFile(files1.get(j).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        y++;
                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + y).child("FileUrl").setValue(uri.toString());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + y).child("FileName").setValue(files1.get(y - 1).getName());

                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Files").child("FilesNo" + y).child("FileType").setValue(files1.get(y - 1).getType());
                                        if (y == (files1.size())) {
                                            Uri uri1 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                                        .setSmallIcon(R.drawable.smiley)
                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                        .setContentTitle(" Success")
                                                        .setSound(uri1)
                                                        .setContentText(" Images Created ")
                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                        .build();
                                                notificationManagerCompat.notify(1, notification);

                                        }
                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.smiley)
                                        .setContentTitle(" Failed")
                                        .setContentText(" Feed Creaion Failed ")
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .build();
                                notificationManagerCompat.notify(1, notification);

                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                long max = taskSnapshot.getTotalByteCount();
                                long current = taskSnapshot.getBytesTransferred();
                                int asd = (int) max;
                                int asdCurrent = (int) current;
                                Notification notification = new NotificationCompat.Builder(getContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                        .setContentTitle("Uploading Files")
                                        .setContentText("Upload in Progress")
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .setOngoing(true)
                                        .setOnlyAlertOnce(true)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setProgress(asd, asdCurrent, false).build();
                                notificationManagerCompat.notify(1, notification);
                            }
                        });
                        j++;
                    }

                     */
                }
                if (imageFiles1.size() != 0) {
                    while (i < imageFiles1.size()) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Feeds")
                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Phone))
                                .child(sharedPreferences2.getString("recent", null)).child("Images").child(String.valueOf(i));

                        storageReference.putFile(imageFiles1.get(i)).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        x++;
                                        FirebaseDatabase.getInstance().getReference().child("Feeds")
                                                .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                                .child(uniqueid).child("Images").child("Image Url " + x).setValue(uri.toString());
                                        if (x == (imageFiles1.size())) {

                                            Uri uri1 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                            if (x == (imageFiles1.size())) {
                                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                                        .setSmallIcon(R.drawable.smiley)
                                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                                        .setContentTitle(" Success")
                                                        .setSound(uri1)
                                                        .setContentText(" Feed Created ")
                                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                                        .build();
                                                notificationManagerCompat.notify(1, notification);
                                            }
                                        }
                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.smiley)
                                        .setContentTitle(" Failed")
                                        .setContentText(" Feed Creaion Failed ")
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .build();
                                notificationManagerCompat.notify(1, notification);

                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                long max = taskSnapshot.getTotalByteCount();
                                long current = taskSnapshot.getBytesTransferred();
                                int asd = (int) max;
                                int asdCurrent = (int) current;
                                Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                        .setContentTitle("Uploading Images")
                                        .setContentText("Upload in Progress")
                                        .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                        .setOngoing(true)
                                        .setOnlyAlertOnce(true)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setProgress(asd, asdCurrent, false).build();
                                notificationManagerCompat.notify(1, notification);

                            }
                        });
                        i++;
                    }
                }
                if (videoFiles1.size() != 0) {
                    StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Feeds")
                            .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                            .child((String) Objects.requireNonNull((Object) LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Phone))
                            .child(sharedPreferences2.getString("recent", null)).child("video");
                    storageReference.putFile(videoFiles1.get(0)).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    FirebaseDatabase.getInstance().getReference().child("Feeds")
                                            .child(LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey)
                                            .child(uniqueid).child("Video Url").setValue(uri.toString());
                                    Uri uri1 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                    Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                            .setSmallIcon(R.drawable.smiley)
                                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                                            .setContentTitle(" Success")
                                            .setSound(uri1)
                                            .setContentText(" Feed Created ")
                                            .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                            .build();
                                    notificationManagerCompat.notify(1, notification);

                                }
                            });
                        }
                    }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                            long max = taskSnapshot.getTotalByteCount();
                            long current = taskSnapshot.getBytesTransferred();
                            int asd = (int) max;
                            int asdCurrent = (int) current;
                            NotificationCompat.Builder notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                    .setContentTitle("Uploading Video")
                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                    .setContentText("Upload in Progress")
                                    .setSmallIcon(R.drawable.ic_notifications_black_24dp)
                                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                    .setOngoing(true)
                                    .setOnlyAlertOnce(true)
                                    .setProgress(asd, asdCurrent, false);
                            notificationManagerCompat.notify(1, notification.build());
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Notification notification = new NotificationCompat.Builder(getActivity().getApplicationContext(), CHANNEL_1_ID)
                                    .setSmallIcon(R.drawable.smiley)
                                    .setContentTitle(" Failed")
                                    .setVibrate((new long[]{1000, 1000, 1000, 1000, 1000}))
                                    .setContentText(" Feed Creation Failed ")
                                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                    .build();
                            notificationManagerCompat.notify(1, notification);
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return String.valueOf(1);

        }

        @Override
        protected void onPostExecute(String string) {
            super.onPostExecute(string);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }

    public class GetFeedTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceName != null) {
                FirebaseDatabase.getInstance().getReference().child("Feeds")
                        .child(LocalUserService.getLocalUserFromPreferences(getContext()).CurrentWorkplaceKey)
                        .addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                                try {
                                    if (dataSnapshot.exists() && dataSnapshot.child("Likes").getChildrenCount() != 0) {

                                        if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(1))) {
                                            try {
                                                Log.e("Content", "No images  No Video  No files");
                                                feedsViewModel.insert(new Feed(Objects.requireNonNull(dataSnapshot.getKey()),
                                                        Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                        CurrentWorkplaceKey,
                                                        CurrentWorkplaceName,
                                                        Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                        Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                        null,
                                                        Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                        Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString(), null, null));
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }

                                        } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(2))) {
                                            try {
                                                if (dataSnapshot.child("Files").exists()) {
                                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());
                                                    int filesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Files").getChildrenCount()));
                                                    if (filesCount == filesChildCount) {

                                                        List<Files> fileUrls = new ArrayList<>();
                                                        for (int i = 1; i <= filesChildCount; i++) {
                                                            Files files = new Files(Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileName").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileType").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileUrl").getValue()).toString());
                                                            fileUrls.add(files);
                                                        }
                                                        feedsViewModel.insert(new Feed(Objects.requireNonNull(dataSnapshot.getKey()),
                                                                Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                                CurrentWorkplaceKey,
                                                                CurrentWorkplaceName,
                                                                Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                                null,
                                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                                Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString(), null, fileUrls));


                                                        Log.e("Content", "No images No Video Yes Files");
                                                    }

                                                }
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(3))) {
                                            try {
                                                if (dataSnapshot.child("Video Url").exists()) {
                                                    feedsViewModel.insert(new Feed(dataSnapshot.getKey(),
                                                            Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                            CurrentWorkplaceKey,
                                                            CurrentWorkplaceName,
                                                            Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                            Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                            dataSnapshot.child("Video Url").getValue().toString(),
                                                            Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                            dataSnapshot.child("Timestamp").getValue().toString(), null, null));
                                                    Log.e("Content", "No images Yes Video  No files ");
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(4))) {
                                            try {
                                                if (dataSnapshot.child("Files").exists() && dataSnapshot.child("Video Url").exists()) {
                                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());
                                                    int filesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Files").getChildrenCount()));
                                                    if (filesCount == filesChildCount) {
                                                        List<Files> fileUrls = new ArrayList<>();
                                                        for (int i = 1; i <= filesChildCount; i++) {
                                                            Files files = new Files(Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileName").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileType").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileUrl").getValue()).toString());
                                                            fileUrls.add(files);
                                                        }
                                                        feedsViewModel.insert(new Feed(Objects.requireNonNull(dataSnapshot.getKey()),
                                                                Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                                CurrentWorkplaceKey,
                                                                CurrentWorkplaceName,
                                                                Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Video Url").getValue()).toString(),
                                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                                Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString(), null, fileUrls));
                                                        Log.e("Content", "No images Yes Video  Yes files ");
                                                    }

                                                }


                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(5))) {
                                            try {
                                                if (dataSnapshot.child("Images").exists()) {
                                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                                    int imagesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Images").getChildrenCount()));
                                                    if (imagesChildCount == imagesCount) {
                                                        List<String> imageUrls = new ArrayList<>();
                                                        for (int i = 1; i <= imagesChildCount; i++) {
                                                            imageUrls.add(Objects.requireNonNull(dataSnapshot.child("Images").child("Image Url " + String.valueOf(i)).getValue()).toString());
                                                        }

                                                        feedsViewModel.insert(new Feed(Objects.requireNonNull(dataSnapshot.getKey()),
                                                                Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                                CurrentWorkplaceKey,
                                                                CurrentWorkplaceName,
                                                                Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                                null,
                                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                                Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString(), imageUrls, null));
                                                        Log.e("Content", "Yes images No Video  No files ");
                                                    }
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(6))) {
                                            try {
                                                if (dataSnapshot.child("Images").exists() && dataSnapshot.child("Files").exists()) {
                                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                                    int imagesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Images").getChildrenCount()));
                                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());
                                                    int filesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Files").getChildrenCount()));
                                                    if (imagesChildCount == imagesCount && filesChildCount == filesCount) {
                                                        List<String> imageUrls = new ArrayList<>();
                                                        List<Files> fileUrls = new ArrayList<>();
                                                        for (int i = 1; i <= imagesChildCount; i++) {
                                                            imageUrls.add(Objects.requireNonNull(dataSnapshot.child("Images").child("Image Url " + String.valueOf(i)).getValue()).toString());
                                                        }
                                                        for (int i = 1; i <= filesChildCount; i++) {
                                                            Files files = new Files(Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileName").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileType").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileUrl").getValue()).toString());
                                                            fileUrls.add(files);
                                                        }
                                                        feedsViewModel.insert(new Feed(Objects.requireNonNull(dataSnapshot.getKey()),
                                                                Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                                CurrentWorkplaceKey,
                                                                CurrentWorkplaceName,
                                                                Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                                null,
                                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                                Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString(), imageUrls, fileUrls));
                                                        Log.e("Content", "Yes images No Video  Yes files ");
                                                    }
                                                }


                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(7))) {
                                            try {
                                                if (dataSnapshot.child("Images").exists() && dataSnapshot.child("Video Url").exists()) {
                                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                                    int imagesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Images").getChildrenCount()));
                                                    if (imagesChildCount == imagesCount) {
                                                        List<String> imageUrls = new ArrayList<>();
                                                        for (int i = 1; i <= imagesChildCount; i++) {
                                                            imageUrls.add(Objects.requireNonNull(dataSnapshot.child("Images").child("Image Url " + String.valueOf(i)).getValue()).toString());
                                                        }

                                                        feedsViewModel.insert(new Feed(Objects.requireNonNull(dataSnapshot.getKey()),
                                                                Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                                CurrentWorkplaceKey,
                                                                CurrentWorkplaceName,
                                                                Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Video Url").getValue()).toString(),
                                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                                Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString(), imageUrls, null));
                                                        Log.e("Content", "Yes images Yes Video  No files ");
                                                    }
                                                }
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        } else if (Objects.requireNonNull(dataSnapshot.child("Ready").getValue()).toString().equals(String.valueOf(8))) {
                                            try {
                                                if (dataSnapshot.child("Images").exists() && dataSnapshot.child("Files").exists() && dataSnapshot.child("Video Url").exists()) {
                                                    int imagesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("ImagesNumber").getValue()).toString());
                                                    int imagesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Images").getChildrenCount()));
                                                    int filesCount = Integer.parseInt(Objects.requireNonNull(dataSnapshot.child("FilesNumber").getValue()).toString());
                                                    int filesChildCount = Integer.parseInt(String.valueOf(dataSnapshot.child("Files").getChildrenCount()));
                                                    if (imagesChildCount == imagesCount && filesChildCount == filesCount) {
                                                        List<String> imageUrls = new ArrayList<>();
                                                        List<Files> fileUrls = new ArrayList<>();
                                                        for (int i = 1; i <= imagesChildCount; i++) {
                                                            imageUrls.add(Objects.requireNonNull(dataSnapshot.child("Images").child("Image Url " + String.valueOf(i)).getValue()).toString());
                                                        }
                                                        for (int i = 1; i <= filesChildCount; i++) {
                                                            Files files = new Files(Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileName").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileType").getValue()).toString(),
                                                                    Objects.requireNonNull(dataSnapshot.child("Files").child("FilesNo" + String.valueOf(i)).child("FileUrl").getValue()).toString());
                                                            fileUrls.add(files);
                                                        }
                                                        feedsViewModel.insert(new Feed(Objects.requireNonNull(dataSnapshot.getKey()),
                                                                Objects.requireNonNull(dataSnapshot.child("Creator").getValue()).toString(),
                                                                CurrentWorkplaceKey,
                                                                CurrentWorkplaceName,
                                                                Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Feed Text").getValue()).toString(),
                                                                Objects.requireNonNull(dataSnapshot.child("Video Url").getValue()).toString(),
                                                                Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())),
                                                                Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString(), imageUrls, fileUrls));
                                                        Log.e("Content", "yes images Yes Video  Yes files ");
                                                    }
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                                if (dataSnapshot.exists()) {
                                    feedsViewModel.updateFeed(dataSnapshot.getKey(), Integer.parseInt(String.valueOf(dataSnapshot.child("Likes").getChildrenCount())));
                                }

                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                                if (dataSnapshot.exists()) {
                                    feedsViewModel.deleteFeed(dataSnapshot.getKey());
                                }
                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

}
