package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class SearchMessageViewModel extends AndroidViewModel {
    private  SearchMessageRepository searchMessageRepository;
    private LiveData<List<SearchMessage>> allMessages;

    public SearchMessageViewModel(@NonNull Application application) {
        super(application);
        searchMessageRepository = new SearchMessageRepository(application);
    }

    public  void  insert(SearchMessage searchMessage){
        searchMessageRepository.insert(searchMessage);
    }
    public  void  update(SearchMessage searchMessage){
        searchMessageRepository.update(searchMessage);
    }
    public  void  delete(SearchMessage searchMessage){
        searchMessageRepository.delete(searchMessage);
    }
    public  void deleteall(){
        searchMessageRepository.deleteAllThreads();
    }
    public  LiveData<List<SearchMessage>> getAllMessages(String work, String sender, String receiver){
        allMessages = searchMessageRepository.getAllMessages(work,sender,receiver);
        return  allMessages;
    }
    public  LiveData<List<SearchMessage>> getMessages(String work,String receiverId){
        allMessages = searchMessageRepository.getMessages(work,receiverId);
        return  allMessages;
    }
}
