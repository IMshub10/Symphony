package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class AllUsersRepository {
    private AllUsersDao allUsersDao;
    private LiveData<List<AllUsers>> allUsers;

    public AllUsersRepository(Application application) {
        AllUsersDatabase allUsersDatabase = AllUsersDatabase.getInstance(application);
        allUsersDao = allUsersDatabase.allUsersDao();
    }

    public void insert(AllUsers allUsers) {
        new InsertUserTask(allUsersDao).execute(allUsers);
    }

    public void delete(AllUsers allUsers) {
        new InsertUserTask(allUsersDao).execute(allUsers);
    }

    public void update(AllUsers allUsers) {
        new InsertUserTask(allUsersDao).execute(allUsers);
    }

    public void deleteAll(){
        new DeleteAllUsersTask(allUsersDao).execute();
    }

    public LiveData<List<AllUsers>> getAllUsers() {
        return allUsersDao.getAllUsers();
    }
    public List<AllUsers> getAllUsers2() {
        return allUsersDao.getAllUsers2();
    }


    private static class DeleteAllUsersTask extends AsyncTask<Void,Void,Void>{
        private AllUsersDao allUsersDao;
        private  DeleteAllUsersTask(AllUsersDao allUsersDao){
            this.allUsersDao = allUsersDao;
        }

        @Override
        protected Void doInBackground(Void ... voids) {
            allUsersDao.deleteAllUsers();
            return null;
        }
    }

    private static class InsertUserTask extends AsyncTask<AllUsers, Void, Void> {
        private AllUsersDao allUsersDao;

        private InsertUserTask(AllUsersDao allUsersDao) {
            this.allUsersDao = allUsersDao;
        }

        @Override
        protected Void doInBackground(AllUsers... allUsers) {
            allUsersDao.insert(allUsers[0]);
            return null;
        }

    }

    private static class UpdateUserTask extends AsyncTask<AllUsers, Void, Void> {

        private AllUsersDao allUsersDao;

        private UpdateUserTask(AllUsersDao allUsersDao) {
            this.allUsersDao = allUsersDao;
        }

        @Override
        protected Void doInBackground(AllUsers... allUsers) {
            allUsersDao.update(allUsers[0]);
            return null;
        }

    }

    private static class DeleteUserTask extends AsyncTask<AllUsers, Void, Void> {
        private AllUsersDao allUsersDao;

        private DeleteUserTask(AllUsersDao allUsersDao) {
            this.allUsersDao = allUsersDao;
        }

        @Override
        protected Void doInBackground(AllUsers... allUsers) {
            allUsersDao.delete(allUsers[0]);
            return null;
        }
    }
}

