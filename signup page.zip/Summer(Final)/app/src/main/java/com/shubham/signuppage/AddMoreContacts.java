package com.shubham.signuppage;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.shubham.signuppage.Models.User;
import com.shubham.signuppage.Room.Member;
import com.shubham.signuppage.Room.MembersViewModel;
import com.shubham.signuppage.Services.LocalUserService;
import com.shubham.signuppage.Services.Tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import Interfaces.RecyclerViewItemClickListener;

public class AddMoreContacts extends AppCompatActivity {

    List<String> memberKeys = new ArrayList<>();
    List<User> memberUsers = new ArrayList<>();
    List<User> memberFinalUsers = new ArrayList<>();
    RecyclerView recyclerView_workplace1, recyclerView_workplace2;

    TextView workplace_name2, description2;
    HashMap<Integer, Integer> hashMap = new HashMap<>();
    HashMap<Integer, User> hashMapz = new HashMap<>();
    List<String> members_list = new ArrayList<>();
    int count = 0;
    Toolbar toolbar;
    String current;
    String workplace;
    ProgressBar progg;

    TextView mem, mem2;
    //    String datasnapshot_name;
    private RelativeLayout root_layout;
    MembersViewModel membersViewModel;
    MembersRecyclerViewAdapter membersRecyclerViewAdapter;
    RecyclerViewAddMoreContacts recyclerviewWorkplace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            setTheme(R.style.MainActivity3_Dark);
        else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_add_more_contacts);
        root_layout = findViewById(R.id.root_activity_add_contact);
        description2 = findViewById(R.id.description2);
        workplace_name2 = findViewById(R.id.workplace_name2);
        recyclerView_workplace1 = findViewById(R.id.recyclerView_workplace1);
        recyclerView_workplace2 = findViewById(R.id.recyclerView_workplace2);

        mem = findViewById(R.id.mem);
        mem2 = findViewById(R.id.mem2);
        toolbar = findViewById(R.id.toolBar_workplace1);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        progg = findViewById(R.id.prog);
        progg.setVisibility(View.INVISIBLE);
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId)
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_dark);
        else {
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        }

        membersRecyclerViewAdapter = new MembersRecyclerViewAdapter(this);
        recyclerView_workplace2.setAdapter(membersRecyclerViewAdapter);
        recyclerView_workplace2.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        membersViewModel = ViewModelProviders.of(this).get(MembersViewModel.class);

        recyclerviewWorkplace = new RecyclerViewAddMoreContacts(getApplicationContext(), memberUsers, workplace);
        recyclerView_workplace1.setAdapter(recyclerviewWorkplace);
        recyclerView_workplace1.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView_workplace2.setVisibility(View.VISIBLE);
        workplace = LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName;
        membersViewModel.getAllMembers(workplace).observe(this, new Observer<List<Member>>() {
            @Override
            public void onChanged(List<Member> members) {
                membersRecyclerViewAdapter.submitList(members);
            }
        });
        if (workplace != null) {
            FirebaseDatabase.getInstance().getReference().child("Workplaces").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                    .child("Members").addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    memberKeys.add(dataSnapshot.child("Member Key").getValue(String.class));
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            FirebaseDatabase.getInstance().getReference().child("Workplaces").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                    .child("Workplace Name").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    workplace_name2.setText(dataSnapshot.getValue(String.class));
                    current = dataSnapshot.getValue(String.class);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            FirebaseDatabase.getInstance().getReference().child("Workplaces").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                    .child("Description").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        description2.setText(dataSnapshot.getValue(String.class));
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            String full_name = LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                    + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName;
            if (full_name.equals(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceCreator)) {

                recyclerView_workplace1.setVisibility(View.VISIBLE);
                Log.e("fullname", full_name);
                Log.e("fullname2", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceCreator);
            }
            Log.e("fullname1", full_name);
            Log.e("fullname2", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceCreator);


        }


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{(Manifest.permission.READ_CONTACTS)}, 4);
        }else {
            new GetMembersTask().execute();
        }

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 4) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                new GetMembersTask().execute();
            }
        }
    }

    public class UploadTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            int temp = 0;
            String tem;

            Map<String, String> map2 = new HashMap<>();


            for (int j = 0; j < memberFinalUsers.size(); j++) {
                tem = String.valueOf(j);
                map2.clear();
                map2.put("Member Name", memberFinalUsers.get(j).FirstName + " " + memberFinalUsers.get(j).LastName);
                map2.put("Member Key", memberFinalUsers.get(j).Key);
//                map2.put("Member Image Url",memberFinalUsers.get(j).ImageUrl);
                map2.put("Member Phone Number", memberFinalUsers.get(j).Phone);
                FirebaseDatabase.getInstance().getReference().child("Workplaces")
                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .child("Members").child(memberFinalUsers.get(j).Key).setValue(map2);

            }

            for (int j = 0; j < memberFinalUsers.size(); j++) {
                Map<String, String> map3 = new HashMap<>();
                map3.clear();
                map3.put("Workplace Id", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey);
                map3.put("Workplace Name", current);
                FirebaseDatabase.getInstance().getReference().child("Users").child(memberFinalUsers.get(j).Key).child("Workplaces")
                        .child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey)
                        .setValue(map3);
            }


            return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        String full_name = LocalUserService.getLocalUserFromPreferences(getApplicationContext()).FirstName + " "
                + LocalUserService.getLocalUserFromPreferences(getApplicationContext()).LastName.trim();
        if (full_name.equals(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceCreator.trim())) {
            this.getMenuInflater().inflate(R.menu.add_more_contacts, menu);
        }
        Log.e("fullname", full_name);
        Log.e("fullname2", LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceCreator);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.tick) {
            int asd = 0;
            int sad = 0;
            while (asd < hashMapz.size()) {
                if (hashMapz.get(sad) != null) {
                    memberFinalUsers.add(hashMapz.get(sad));
                    asd++;
                }
                sad++;
            }
            UploadTask uploadTask = new UploadTask();
            uploadTask.execute();
            Intent intent = new Intent(this, Main3Activity.class);
            startActivity(intent);
        }
        if (id == R.id.add) {
            workplace_name2.setVisibility(View.GONE);
            description2.setVisibility(View.GONE);
            recyclerView_workplace1.setVisibility(View.VISIBLE);
            recyclerView_workplace2.setVisibility(View.GONE);
            mem.setVisibility(View.GONE);
            mem2.setVisibility(View.VISIBLE);
            progg.setVisibility(View.VISIBLE);
            new GetContactTask().execute();
        }
        return true;
    }

    private List<String> getContactList() {

        List<String> PhoneList = new ArrayList<>();

        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if ((cur != null ? cur.getCount() : 0) > 0) {
            while (cur != null && cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                if (cur.getInt(cur.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));
                        if (phoneNo.length() > 13) {
                            phoneNo = phoneNo.substring(0, 3) + phoneNo.substring(4, 9) + phoneNo.substring(10, 15);
                        }
                        PhoneList.add(phoneNo);
                        Log.i("TAG", "Name: " + name);
                        Log.i("TAG", "Phone Number: " + phoneNo);
                    }
                    pCur.close();
                }
            }
        }
        if (cur != null) {
            cur.close();
        }
        return PhoneList;
    }

    public class GetContactTask extends AsyncTask<Void, Void, List<String>> {

        @Override
        protected List<String> doInBackground(Void... voids) {
            return getContactList();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(List<String> strings) {
            super.onPostExecute(strings);
            new GetUsersTask(strings).execute();

        }
    }

    private class GetUsersTask extends AsyncTask<Void, Void, Void> {

        List<String> PhoneList = new ArrayList<>();

        public GetUsersTask(List<String> phoneList) {
            PhoneList = phoneList;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progg.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            if (Tools.isNetworkAvailable(getApplicationContext())) {
                if (workplace != null) {
                    FirebaseDatabase.getInstance().getReference().child("Users").addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            int i = 0;
                            int x = 0;
                            while (i < memberKeys.size()) {
                                if (!memberKeys.get(i).equals(dataSnapshot.getKey())) {
                                    i++;
                                    x = 1;
                                } else {
                                    x = 0;
                                    i = memberKeys.size();
                                }
                                if (i == memberKeys.size() && x == 1) {
                                    if (PhoneList.contains(Objects.requireNonNull(dataSnapshot.child("Phone number").getValue()).toString())) {
                                        memberKeys.add(dataSnapshot.getKey());
                                        User friend = new User();
                                        friend.Phone = Objects.requireNonNull(dataSnapshot.child("Phone number").getValue()).toString();
                                        friend.Key = Objects.requireNonNull(dataSnapshot.getKey());
                                        friend.FirstName = Objects.requireNonNull(dataSnapshot.child("F_Name").getValue()).toString();
                                        String key = dataSnapshot.getKey();
                                        friend.LastName = Objects.requireNonNull(dataSnapshot.child("L_Name").getValue()).toString();
//                                        friend.ImageUrl = Objects.requireNonNull(dataSnapshot.child("Profile Image").getValue()).toString();
                                        memberUsers.add(friend);

                                        recyclerviewWorkplace.notifyDataSetChanged();
                                        for (int i1 = 0; i1 < memberUsers.size(); i1++) {
                                            hashMap.put(i1, 0);
                                        }
                                        recyclerviewWorkplace.setOnItemClickListener(new RecyclerViewItemClickListener() {
                                            @SuppressLint("ResourceAsColor")
                                            @Override
                                            public void onItemClick(View view, int position) {
                                                if (memberUsers.size() != 0) {
                                                    if (hashMap.get(position) == 0) {
                                                        view.setBackgroundColor(R.color.colorPrimaryDark);
                                                        hashMap.put(position, 1);
                                                        count++;
                                                        User userz = new User();
                                                        userz = memberUsers.get(position);
                                                        hashMapz.put(position, userz);
                                                    } else {
                                                        view.setBackgroundColor(0xFFFFFFFF);
                                                        hashMap.put(position, 0);
                                                        count--;
                                                        hashMapz.remove(position);
                                                    }
                                                }
                                            }

                                            @Override
                                            public void onLongItemClick(View view, int position) {

                                            }
                                        });
                                    }
                                }
                            }
                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            } else {
                Snackbar.make(root_layout,"Network Error: No Internet Connection", Snackbar.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(), "Network Error Snack", Toast.LENGTH_SHORT).show();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progg.setVisibility(View.INVISIBLE);

        }
    }

    public class GetMembersTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {

            if (LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName != null) {
                FirebaseDatabase.getInstance().getReference().child("Workplaces").child(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey).child("Members")
                        .addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                                if (!dataSnapshot.getKey().equals(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).Key)) {
                                    String phone = Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString();
                                    membersViewModel.insert(new Member(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Name").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString(),
                                            LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            null,
                                            null, 0, null));
                                }
                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                                membersViewModel.update(new Member(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("Member Name").getValue()).toString(),
                                        Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString(),
                                        LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceName,
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                        null,
                                        null, 0, null));
                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                                membersViewModel.deleteMMember(LocalUserService.getLocalUserFromPreferences(getApplicationContext()).CurrentWorkplaceKey +
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString());
                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
            }
            return null;
        }
    }

}
