package com.shubham.signuppage.Room;


import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Message.class},version = 13,exportSchema = false)
public abstract  class MessageDatabase  extends RoomDatabase {

    private static MessageDatabase instance;

    public  abstract MessageDao messageDao();

    public  static  synchronized MessageDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    MessageDatabase.class,"message_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }
    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbTask(instance).execute();
        }
    };

    private  static class  PopulateDbTask extends AsyncTask<Void,Void,Void> {

        private  MessageDao messageDao;
        private PopulateDbTask(MessageDatabase database){
            messageDao = database.messageDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            return null;
        }
    }


}
