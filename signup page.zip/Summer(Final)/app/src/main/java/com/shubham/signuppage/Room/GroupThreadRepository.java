package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class GroupThreadRepository {
    private GroupThreadDao groupThreadDao;
    private LiveData<List<GroupThread>> allThreads;

    public GroupThreadRepository(Application application) {
        GroupThreadDatabase groupThreadDatabase = GroupThreadDatabase.getInstance(application);
        groupThreadDao = groupThreadDatabase.groupThreadDao();
    }
    public  void insert(GroupThread groupThread){
        new InsertThreadTask(groupThreadDao).execute(groupThread);
    }
    public  void delete(GroupThread groupThread){
        new DeleteThreadTask(groupThreadDao).execute(groupThread);
    }
    public  void update(GroupThread groupThread){
        new UpdateThreadTask(groupThreadDao).execute(groupThread);
    }
    public  void deleteAllThreads(){
        new DeleteAllThreadTask(groupThreadDao).execute();
    }
    public  LiveData<List<GroupThread>> getAllThread(String workKey, String work, String receiverid){
        allThreads = groupThreadDao.getAlThread(workKey,work,receiverid);
        return  allThreads;
    }
    public void deleteThread(String threadId){
        new DeleteThreadxTask(groupThreadDao).execute(threadId);
    }
    public  void  updatePositionsOfThread(String threadId,int position){
        new UpdatePositionsOfThreadTask(groupThreadDao,threadId,position).execute();
    }
    private  static  class DeleteThreadxTask extends AsyncTask<String,Void,Void> {

        private GroupThreadDao groupThreadDao;
        private  DeleteThreadxTask(GroupThreadDao groupThreadDao){
            this.groupThreadDao = groupThreadDao;
        }

        @Override
        protected Void doInBackground(String... strings) {
            groupThreadDao.deleteThread(strings[0]);
            return null;
        }

    }
    public static class UpdatePositionsOfThreadTask extends AsyncTask<Void,Void,Void>{
        private GroupThreadDao groupThreadDao;
        private String threadId;
        private int position;

        public UpdatePositionsOfThreadTask(GroupThreadDao groupThreadDao, String threadId, int position) {
            this.groupThreadDao = groupThreadDao;
            this.threadId = threadId;
            this.position = position;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            groupThreadDao.updatePositionsOfThread(threadId,position);
            return null;
        }
    }
    private  static  class InsertThreadTask extends AsyncTask<GroupThread,Void,Void> {

        private GroupThreadDao groupThreadDao;
        private  InsertThreadTask(GroupThreadDao groupThreadDao){
            this.groupThreadDao = groupThreadDao;
        }

        @Override
        protected Void doInBackground(GroupThread... groupThreads) {
            groupThreadDao.insert(groupThreads[0]);
            return null;

        }

    }
    private  static  class UpdateThreadTask extends  AsyncTask<GroupThread,Void,Void>{

        private GroupThreadDao groupThreadDao;
        private  UpdateThreadTask(GroupThreadDao groupThreadDao){
            this.groupThreadDao = groupThreadDao;
        }

        @Override
        protected Void doInBackground(GroupThread... groupThreads) {
            groupThreadDao.update(groupThreads[0]);
            return null;
        }

    }
    private  static  class DeleteThreadTask extends  AsyncTask<GroupThread,Void,Void>{

        private GroupThreadDao groupThreadDao;
        private  DeleteThreadTask(GroupThreadDao groupThreadDao){
            this.groupThreadDao = groupThreadDao;
        }

        @Override
        protected Void doInBackground(GroupThread... groupThreads) {
            groupThreadDao.delete(groupThreads[0]);
            return null;
        }

    }
    private  static  class DeleteAllThreadTask extends  AsyncTask<Void,Void,Void>{

        private GroupThreadDao groupThreadDao;
        private  DeleteAllThreadTask(GroupThreadDao groupThreadDao){
            this.groupThreadDao = groupThreadDao;
        }

        @Override
        protected Void doInBackground(Void ... voids) {
            groupThreadDao.deleteAllThread();
            return null;
        }

    }
}

