package com.shubham.signuppage;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.shubham.signuppage.Services.LocalUserService;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class ExpandableListAdapter extends BaseExpandableListAdapter {
    private Context context;
    private List<String> listGroup;
    private HashMap<String, List<String>> listItem;
    private SharedPreferences sharedPreferences;

    public ExpandableListAdapter(Context context, List<String> listGroup, HashMap<String, List<String>> listChild) {
        this.context = context;
        this.listGroup = listGroup;
        this.listItem = listChild;
    }


    @Override
    public int getGroupCount() {
        return this.listGroup.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if (listItem.get(listGroup.get(groupPosition)) == null) {
            return 0;
        } else {
            return this.listItem.get(listGroup.get(groupPosition)).size();
        }

    }


    @Override
    public Object getGroup(int groupPosition) {
        return this.listGroup.get(groupPosition);
    }

    public Object getChild(int groupPosition, int childPosition) {
        return this.listItem.get(listGroup.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }


    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }


    @Override
    public boolean hasStableIds() {
        return true;
    }


    @SuppressWarnings("deprecation")
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.expandable_group_header, null);
        }
        if (groupPosition == 0) {
            ImageView imageView = convertView.findViewById(R.id.group_header_imageview);
            imageView.setVisibility(View.VISIBLE);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(50, 50);
            layoutParams.gravity = Gravity.CENTER;
            layoutParams.setMargins(0, 6, 0, 0);
            imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
            if (isExpanded && getChildrenCount(0) != 0) {
                imageView.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_keyboard_arrow_up_black_24dp));
            } else if (!isExpanded && getChildrenCount(0) != 0) {
                imageView.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_keyboard_arrow_down_black_24dp));
            } else if (getChildrenCount(0) == 0) {
                imageView.setVisibility(View.VISIBLE);
                imageView.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_keyboard_arrow_down_black_24dp));

            }
        } else if (groupPosition == 1) {
            ImageView imageView = (ImageView) convertView.findViewById(R.id.group_header_imageview);
            imageView.setVisibility(View.VISIBLE);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(50, 50);
            layoutParams.gravity = Gravity.CENTER;
            layoutParams.setMargins(0, 0, 0, 0);
            imageView.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
            imageView.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_add_black_24dp));
        } else {
            ImageView imageView = convertView.findViewById(R.id.group_header_imageview);
            imageView.setVisibility(View.GONE);
        }
        TextView textView = convertView.findViewById(R.id.group_header_text);
        String header = (String) getGroup(groupPosition);
        textView.setText(header);
        Switch switch_theme = convertView.findViewById(R.id.switch_theme);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, 50);

        layoutParams.gravity = Gravity.CENTER;
        layoutParams.setMargins(0, 0, 0, 0);

        if (LocalUserService.getLocalUserFromPreferences(context).ThemeId == true) {
            switch_theme.setChecked(true);
        } else {
            switch_theme.setChecked(false);
        }

        switch_theme.setLayoutParams((ViewGroup.LayoutParams) layoutParams);
        if (groupPosition == 2) {
            switch_theme.setVisibility(View.VISIBLE);
        } else {
            switch_theme.setVisibility(View.GONE);
        }

        sharedPreferences = this.context.getSharedPreferences("LocalUser", 0);
        switch_theme.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Intent intent = new Intent(context, Main3Activity.class);
                if (isChecked) {
                    sharedPreferences.edit().putBoolean("ThemeId", true).apply();
                } else {
                    sharedPreferences.edit().putBoolean("ThemeId", false).apply();
                }
                context.startActivity(intent);
            }
        });
        return convertView;

    }


    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        String string = getChild(groupPosition, childPosition).toString();
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.expandable_child_header, null);

        }
        TextView textView = convertView.findViewById(R.id.child_head_text);
        textView.setText(string);
        ImageView imageView = convertView.findViewById(R.id.child_head_image);

        if (string.equals(LocalUserService.getLocalUserFromPreferences(context).CurrentWorkplaceName)) {
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.INVISIBLE);
        }


        //getGroupView(0,true,convertView,)
        return convertView;
    }


    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
