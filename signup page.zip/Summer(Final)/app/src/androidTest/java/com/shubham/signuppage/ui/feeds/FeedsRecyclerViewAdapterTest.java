package com.shubham.signuppage.ui.feeds;

import org.junit.Test;


public class FeedsRecyclerViewAdapterTest {

    @Test
    public void getItemViewType() {
    }

    @Test
    public void setHasStableIds() {
    }

    @Test
    public void getItemId() {
    }

    @Test
    public void onCreateViewHolder() {
    }

    @Test
    public void onBindViewHolder() {
    }

    @Test
    public void onViewAttachedToWindow() {
    }

    @Test
    public void onViewDetachedFromWindow() {
    }

    @Test
    public void onViewRecycled() {
    }

    @Test
    public void testOnBindViewHolder() {
    }

    @Test
    public void downloadBooks() {
    }
}