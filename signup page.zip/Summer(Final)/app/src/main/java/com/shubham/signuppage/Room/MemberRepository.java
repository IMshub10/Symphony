package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class MemberRepository {
    private MemberDao memberDao;
    private LiveData<List<Member>> allMembers;
    int count;

    public MemberRepository(Application application) {
        MemberDatabase memberDatabase = MemberDatabase.getInstance(application);
        memberDao = memberDatabase.memberDao();
    }

    public  void insert(Member member){
        new InsertMemberTask(memberDao).execute(member);
    }
    public  void delete(Member member){
        new DeleteMemberTask(memberDao).execute(member);
    }
    public  void update(Member member){
        new UpdateMemberTask(memberDao).execute(member);
    }
    public void updateMember(String key,String message,int messageCount,String createDate,String timestamp){

        new UpdateMemberIdTask(memberDao,key,message,messageCount,createDate,timestamp).execute();
    }
    public void updateMemberMessage(String key,String message,String createDate,String timestamp){

        new UpdateMemberCountTask(memberDao,key,message,createDate,timestamp).execute();
    }
    public void updateMemberMess(String key,int messageCount){

        new UpdateMemberMessageTask(memberDao,key,messageCount).execute();
    }
    public  void deleteAllMembers(){
        new DeleteAllMemberTask(memberDao).execute();
    }
    public List<Member>getAllMembersWork(String work){
        return memberDao.getAllMembersWork(work);
    }
    public  LiveData<List<Member>> getAllMembers(String work){
        allMembers = memberDao.getAllMembers(work);
        return  allMembers;
    }
    public void deleteMessage(String memberId){
        new DeleteMemberidTask(memberDao).execute(memberId);
    }
    public  LiveData<List<Member>> getAllMembersFrag(String work,String lastMessage){
        allMembers = memberDao.getAllMembersFrag(work,lastMessage);
        return  allMembers;
    }

    private  static  class UpdateMemberIdTask extends  AsyncTask<String,Void,Void>{
        private MemberDao memberDao;
        private String message;
        private String key;
        private String createDate;
        private int messageCount;
        private String timestamp;
        public UpdateMemberIdTask(MemberDao memberDao,String key,String message,int messageCount,String createDate,String timestamp){
            this.memberDao = memberDao;
            this.message = message;
            this.key = key;
            this.messageCount = messageCount;
            this.createDate=createDate;
            this.timestamp = timestamp;
        }

        @Override
        protected Void doInBackground(String... strings) {
            memberDao.updateMember(key,message,messageCount,createDate,timestamp);
            return null;
        }
    }
    private  static  class UpdateMemberMessageTask extends  AsyncTask<String,Void,Void>{
        private MemberDao memberDao;
        private String message;
        private String key;
        private int messageCount;
        public UpdateMemberMessageTask(MemberDao memberDao,String key,int messageCount){
            this.memberDao = memberDao;
            this.message = message;
            this.key = key;
        }

        @Override
        protected Void doInBackground(String... strings) {
            memberDao.updateMemberMessage(key,messageCount);
            return null;
        }
    }
    private  static  class UpdateMemberCountTask extends  AsyncTask<String,Void,Void>{
        private MemberDao memberDao;
        private String message;
        private String key;
        private String createDate;
        private String timestamp;
        public UpdateMemberCountTask(MemberDao memberDao,String key,String message,String createDate,String timestamp){
            this.memberDao = memberDao;
            this.message = message;
            this.key = key;
            this.createDate = createDate;
            this.timestamp = timestamp;
        }

        @Override
        protected Void doInBackground(String... strings) {
            memberDao.updateMemberMessageCOunt(key,message,createDate,timestamp);
            return null;
        }
    }
    private  static  class DeleteMemberidTask extends  AsyncTask<String,Void,Void>{

        private MemberDao memberDao;
        private  DeleteMemberidTask(MemberDao memberDao){
            this.memberDao = memberDao;
        }

        @Override
        protected Void doInBackground(String... strings) {
            memberDao.deleteMessage(strings[0]);
            return null;
        }

    }

    private class InsertMemberTask extends AsyncTask<Member,Void,Void>{

        private MemberDao memberDao;
        public InsertMemberTask(MemberDao memberDao) {
            this.memberDao = memberDao;
        }

        @Override
        protected Void doInBackground(Member... members) {
            memberDao.insert(members[0]);
            return null;
        }
    }

    private class DeleteMemberTask extends AsyncTask<Member,Void,Void>{

        private MemberDao memberDao;
        public DeleteMemberTask(MemberDao memberDao) {
            this.memberDao = memberDao;
        }

        @Override
        protected Void doInBackground(Member... members) {
            memberDao.delete(members[0]);
            return null;
        }
    }

    private class UpdateMemberTask extends AsyncTask<Member,Void,Void>{

        private MemberDao memberDao;
        public UpdateMemberTask(MemberDao memberDao) {
            this.memberDao = memberDao;
        }

        @Override
        protected Void doInBackground(Member... members) {
            memberDao.update(members[0]);
            return null;
        }
    }

    private class DeleteAllMemberTask extends AsyncTask<Void,Void,Void>{

        private MemberDao memberDao;
        public DeleteAllMemberTask(MemberDao memberDao) {
            this.memberDao = memberDao;
        }
        @Override
        protected Void doInBackground(Void... voids) {
            memberDao.deleteAllMembers();
            return null;
        }
    }
}
