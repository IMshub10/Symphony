package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;
import android.util.Log;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ScheduleRepository {
    private ScheduleDao scheduleDao;
    private LiveData<List<Schedule>> liveData;

    public ScheduleRepository(Application application) {
        ScheduleDatabase scheduleDatabase = ScheduleDatabase.getInstance(application);
        scheduleDao = scheduleDatabase.scheduleDao();
    }
    public  void insert(Schedule schedule){
        new InsertFeedTask(scheduleDao).execute(schedule);
    }
    public  void delete(Schedule schedule){
        new DeleteFeedTask(scheduleDao).execute(schedule);
    }
    public  void update(Schedule schedule){
        new UpdateFeedTask(scheduleDao).execute(schedule);
    }
    public  void deleteAllThreads(){
        new DeleteAllFeedTask(scheduleDao).execute();
    }

    public  LiveData<List<Schedule>> getAllSchedule(String workKey){
        return  scheduleDao.getAllSchedule(workKey);
    }
    private  static  class InsertFeedTask extends AsyncTask<Schedule,Void,Void> {

        private ScheduleDao scheduleDao;
        private  InsertFeedTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Schedule... schedules) {
            scheduleDao.insert(schedules[0]);
            Log.e("SearchMessageRepositoty","Inserted");
            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }
    }
    private  static  class UpdateFeedTask extends  AsyncTask<Schedule,Void,Void>{

        private ScheduleDao scheduleDao;
        private  UpdateFeedTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Schedule... schedules) {
            scheduleDao.update(schedules[0]);
            return null;
        }

    }
    private  static  class DeleteFeedTask extends  AsyncTask<Schedule,Void,Void>{

        private ScheduleDao scheduleDao;
        private  DeleteFeedTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Schedule... schedules) {
            scheduleDao.delete(schedules[0]);
            return null;
        }

    }

    private  static  class DeleteAllFeedTask extends  AsyncTask<Void,Void,Void>{

        private ScheduleDao scheduleDao;
        private  DeleteAllFeedTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Void ... voids) {
            scheduleDao.deleteAllMessages();
            return null;
        }

    }
}
