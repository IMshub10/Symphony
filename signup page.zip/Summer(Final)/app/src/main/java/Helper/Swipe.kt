package Helper

interface Swipe {
    public fun showReplyUIRight(position: Int)
}