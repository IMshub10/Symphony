package com.shubham.signuppage.ui.feeds;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class FeedRepository {

    private  FeedDao feedDao;
    private LiveData<List<Feed>> allFeeds;

    public  FeedRepository(Application application){
        FeedDatabase feedDatabase = FeedDatabase.getInstance(application);
        feedDao = feedDatabase.feedDao();
    }
    public  void insert(Feed feed){
        new InsertFeedTask(feedDao).execute(feed);
    }
    public  void delete(Feed feed){
        new DeleteFeedTask(feedDao).execute(feed);
    }
    public  void update(Feed feed){
        new UpdateFeedTask(feedDao).execute(feed);
    }
    public  void deleteAllFeeds(){
        new DeleteAllFeedTask(feedDao).execute();
    }
    public  LiveData<List<Feed>> getAllFeeds(String work){
        allFeeds = feedDao.getAllFeeds(work);
        return  allFeeds;
    }
    public List<Feed> getFeeds(String work){
        return  feedDao.getFeeds(work);
    }

    public  void deleteFeed(String asKey){
        new DeleteFeed(feedDao,asKey).execute();
    }
    public  void updateFeed(String asKey,int likes){
        new UpdateFeed(feedDao,asKey,likes).execute();
    }

    public List<Feed> SearchFeeds(String work,String contains){
        return feedDao.getSearchFeeds(work, contains);
    }

    private  static class DeleteFeed extends  AsyncTask<Void,Void,Void>{

        private FeedDao feedDao;
        private String asKey;

        public DeleteFeed(FeedDao feedDao, String asKey) {
            this.feedDao = feedDao;
            this.asKey = asKey;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            feedDao.deleteFeed(asKey);
            return null;
        }

    }
    private  static class UpdateFeed extends  AsyncTask<Void,Void,Void>{

        private FeedDao feedDao;
        private String asKey;
        private int likes;

        public UpdateFeed(FeedDao feedDao, String asKey, int likes) {
            this.feedDao = feedDao;
            this.asKey = asKey;
            this.likes = likes;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            feedDao.updateFeed(asKey,likes);
            return null;
        }

    }
    private  static  class InsertFeedTask extends  AsyncTask<Feed,Void,Void>{

        private FeedDao feedDao;
        private  InsertFeedTask(FeedDao feedDao){
            this.feedDao = feedDao;
        }

        @Override
        protected Void doInBackground(Feed... feeds) {
            feedDao.insert(feeds[0]);
            return null;

        }

    }
    private  static  class UpdateFeedTask extends  AsyncTask<Feed,Void,Void>{

        private FeedDao feedDao;
        private  UpdateFeedTask(FeedDao feedDao){
            this.feedDao = feedDao;
        }

        @Override
        protected Void doInBackground(Feed... feeds) {
            feedDao.update(feeds[0]);
            return null;
        }

    }
    private  static  class DeleteFeedTask extends  AsyncTask<Feed,Void,Void>{

        private FeedDao feedDao;
        private  DeleteFeedTask(FeedDao feedDao){
            this.feedDao = feedDao;
        }

        @Override
        protected Void doInBackground(Feed... feeds) {
            feedDao.delete(feeds[0]);
            return null;
        }

    }
    private  static  class DeleteAllFeedTask extends  AsyncTask<Void,Void,Void>{

        private FeedDao feedDao;
        private  DeleteAllFeedTask(FeedDao feedDao){
            this.feedDao = feedDao;
        }

        @Override
        protected Void doInBackground(Void ... voids) {
            feedDao.deleteAllFeeds();
            return null;
        }

    }

}
