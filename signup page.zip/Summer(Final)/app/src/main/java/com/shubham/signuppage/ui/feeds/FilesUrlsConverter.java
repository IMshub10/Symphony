package com.shubham.signuppage.ui.feeds;

import androidx.room.TypeConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.shubham.signuppage.Models.Files;

import java.lang.reflect.Type;
import java.util.List;

public class FilesUrlsConverter {
    @TypeConverter
    public static List<Files> fromString(String value) {
        Type listType = new TypeToken<List<Files>>() {}.getType();
        return new Gson().fromJson(value, listType);
    }
    @TypeConverter
    public static String fromArrayList(List<Files> list) {
        Gson gson = new Gson();
        return gson.toJson(list);
    }
}
