package Interfaces;


import com.shubham.signuppage.Room.Message;

public interface DownloadChatFiles {
    void onItemClick(Message message, int item_position, int file_position);
}
