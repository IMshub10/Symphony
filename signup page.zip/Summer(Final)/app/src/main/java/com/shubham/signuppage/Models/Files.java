package com.shubham.signuppage.Models;

import com.google.gson.annotations.SerializedName;

public class Files {

    @SerializedName("name")
    private String name;

    @SerializedName("type")
    private String type;

    @SerializedName("url")
    private String url;

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getUrl() {
        return url;
    }

    public Files(String name, String type, String url) {
        this.name = name;
        this.type = type;
        this.url = url;
    }
}
