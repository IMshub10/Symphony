package Interfaces;

import com.shubham.signuppage.Room.GroupMessage;

public interface DownloadGroupFiles {
    void onItemClick(GroupMessage groupMessage, int item_position, int file_position);
}
