package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "groups_table")
public class Groups {
    @PrimaryKey(autoGenerate = false)
    @NonNull
    private  String key;

    private String name;

    private String workplace;

    private String memberKey;

    private String createDate;

    private  String lastmesage;

    private int messsageCount;

    private String timestamp;

    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getWorkplace() {
        return workplace;
    }

    public String getMemberKey() {
        return memberKey;
    }

    public String getLastmesage() {
        return lastmesage;
    }

    public int getMesssageCount() {
        return messsageCount;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public Groups(@NonNull String key, String name, String workplace, String memberKey, String createDate, String lastmesage, int messsageCount, String timestamp) {
        this.key = key;
        this.name = name;
        this.workplace = workplace;
        this.memberKey = memberKey;
        this.createDate = createDate;
        this.lastmesage = lastmesage;
        this.messsageCount = messsageCount;
        this.timestamp = timestamp;
    }


}
