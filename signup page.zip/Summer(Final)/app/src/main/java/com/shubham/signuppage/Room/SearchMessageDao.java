package com.shubham.signuppage.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface SearchMessageDao {

    @Insert()
    void insert(SearchMessage message);

    @Update
    void update(SearchMessage message);

    @Delete
    void delete(SearchMessage message);

    @Query("Delete From search_message_table ")
    void deleteAllMessages();

    @Query("SELECT * FROM  search_message_table where (workplaceKey =:workKey  AND ((sender=:sender AND receiver=:receiver)OR (sender=:receiver AND receiver=:sender))) ORDER BY timestamp DESC ")
    LiveData<List<SearchMessage>> getAllMessages(String workKey, String sender, String receiver);

    @Query("SELECT * FROM  search_message_table where (workplaceKey =:workKey  AND receiver=:receiverId) ORDER BY timestamp DESC ")
    LiveData<List<SearchMessage>> getMessages(String workKey,String receiverId);
}
