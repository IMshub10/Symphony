package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "all_users_table")
public class AllUsers {

    @PrimaryKey(autoGenerate = false)
    @NonNull
    private  String key;

    private String f_name;

    private String l_name;

    private String  phone;

    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getF_name() {
        return f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public String getPhone() {
        return phone;
    }

    public AllUsers(@NonNull String key, String f_name, String l_name, String phone) {
        this.key = key;
        this.f_name = f_name;
        this.l_name = l_name;
        this.phone = phone;
    }


}
