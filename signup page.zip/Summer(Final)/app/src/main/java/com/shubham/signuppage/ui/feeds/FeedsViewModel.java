package com.shubham.signuppage.ui.feeds;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;

public class FeedsViewModel extends AndroidViewModel {

    private  FeedRepository feedRepository;
    private LiveData<List<Feed>> allFeeds;

    public FeedsViewModel(@NonNull Application application) {
        super(application);

        feedRepository = new FeedRepository(application);

    }

    public  void  insert(Feed feed){
        feedRepository.insert(feed);
    }
    public  void  update(Feed feed){
        feedRepository.update(feed);
    }
    public  void  delete(Feed feed){
        feedRepository.delete(feed);
    }
    public  void deleteall(){
        feedRepository.deleteAllFeeds();
    }
    public  LiveData<List<Feed>> getAllFeeds(String work){
        allFeeds = feedRepository.getAllFeeds(work);

        return  allFeeds;
    }
    public List<Feed> getFeeds(String work){
        return  feedRepository.getFeeds(work);
    }
    public List<Feed> SearchFeeds(String work,String contains){
        return feedRepository.SearchFeeds(work, contains);
    }

    public  void deleteFeed(String asKey){
        feedRepository.deleteFeed(asKey);
    }
    public  void updateFeed(String asKey,int likes){
        feedRepository.updateFeed(asKey,likes);
    }


}
