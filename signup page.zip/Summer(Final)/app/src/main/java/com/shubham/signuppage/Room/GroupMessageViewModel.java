package com.shubham.signuppage.Room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;


public class GroupMessageViewModel extends AndroidViewModel {

    private  GroupMessageRepository groupMessageRepository;
    private LiveData<List<GroupMessage>> allMessages;

    public GroupMessageViewModel(@NonNull Application application) {
        super(application);
        groupMessageRepository = new GroupMessageRepository(application);
    }
    public List<GroupMessage> getThreadMessages(String threadId){
        return groupMessageRepository.getThreadMessages(threadId);
    }
    public List<GroupMessage> getMessages(String work,String receiverId,String cotains) {
        return groupMessageRepository.getMessages(work,receiverId,cotains);
    }

    public  void  deleteMessage(String messageId){
        groupMessageRepository.deleteMessage(messageId);
    }
    public List<GroupMessage> getMess(String work,String receiverId) {
        return groupMessageRepository.getMess(work,receiverId);
    }
    public int getThreadMessageCount(String threadId){
        return  groupMessageRepository.getThreadMessageCount(threadId);
    }
    public  void  insert(GroupMessage groupMessage){
        groupMessageRepository.insert(groupMessage);
    }
    public  void  update(GroupMessage groupMessage){
        groupMessageRepository.update(groupMessage);
    }
    public  void  delete(GroupMessage groupMessage){
        groupMessageRepository.delete(groupMessage);
    }
    public  void deleteall(){
        groupMessageRepository.deleteAllThreads();
    }
    public  LiveData<List<GroupMessage>> getAllMessages(String workKey,String work, String receiverid,String threadId){
        allMessages = groupMessageRepository.getAllMessages(workKey,work,receiverid,threadId);
        return  allMessages;
    }
    public  void updateMessageLikeCount(String asKey,int likes){
        groupMessageRepository.updateMessageLikeCount(asKey,likes);
    }

    public  void  updateRead(String work,String receiverid,Boolean read){
        groupMessageRepository.updateRead(work,receiverid,read);
    }
}
