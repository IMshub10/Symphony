package com.shubham.signuppage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.shubham.signuppage.Models.User;

import java.util.HashMap;
import java.util.List;

import Interfaces.RecyclerViewItemClickListener;
import de.hdodenhof.circleimageview.CircleImageView;

public class RecyclerViewAddMoreContacts extends RecyclerView.Adapter<RecyclerViewAddMoreContacts.ViewHolder> {

    private List<User> contactList;
    private Context context;
    int count;
    HashMap<Integer, Integer> hash_map;
    int i;
    private String key;
    HashMap<Integer, String> members;
    private int selected_item;
    private String workplaceName;
    private RecyclerViewItemClickListener recyclerViewItemClickListener;


    RecyclerViewAddMoreContacts(Context context, List<User> contactList, String workplaceName){
        this.context = context;
        this.contactList = contactList;
        this.workplaceName = workplaceName;

    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.workplace_recyclerview,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }
    public  void  setOnItemClickListener(RecyclerViewItemClickListener recyclerViewItemClickListener){
        this.recyclerViewItemClickListener= recyclerViewItemClickListener;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String firstName=contactList.get(position).FirstName;
        String lastName = contactList.get(position).LastName;
        String fullName = firstName +lastName;
        holder.workplace_user_name.setText(fullName);
        holder.workplace_user_phone.setText(contactList.get(position).Phone);
    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder {
        TextView  workplace_user_name, workplace_user_phone;
        CircleImageView workplace_user_image;
        public ViewHolder(@NonNull View view) {
            super(view);
            workplace_user_name=view.findViewById(R.id.workplace_user_name);
            workplace_user_phone=view.findViewById(R.id.workplace_user_phone);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecyclerViewAddMoreContacts.this.recyclerViewItemClickListener.onItemClick(view,getLayoutPosition());

                }
            });
            view.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    RecyclerViewAddMoreContacts.this.recyclerViewItemClickListener.onLongItemClick(view,getLayoutPosition());
                    return false;
                }
            });
        }
    }
    @Override
    public void onViewAttachedToWindow(@NonNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
    }
}