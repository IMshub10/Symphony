package com.shubham.signuppage.ui.groups;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.Member;

import de.hdodenhof.circleimageview.CircleImageView;

public class MembersRecyclerViewAdapter extends ListAdapter<Member,MembersRecyclerViewAdapter.MembersHolder> {

    Context context;

    public MembersRecyclerViewAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
    }
    private  static  final DiffUtil.ItemCallback<Member>DIFF_CALLBACK = new DiffUtil.ItemCallback<Member>() {
        @Override
        public boolean areItemsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return false;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return false;
        }
    };

    @NonNull
    @Override
    public MembersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.groups_contacts_listitem,parent,false);
        return new MembersHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MembersHolder holder, int position) {
        Member current_member = getItem(position);
        holder.user_name.setText(current_member.getName());
        holder.user_phone.setText(current_member.getPhone());
        Glide.with(holder.user_image.getContext())
                .asBitmap()
                .error(R.drawable.mas)
                .load(R.drawable.dp)
                .into(holder.user_image);
    }
    class MembersHolder extends RecyclerView.ViewHolder{
        CircleImageView user_image;
        TextView user_name, user_phone;

        public MembersHolder(@NonNull View itemView) {
            super(itemView);
            user_image = itemView.findViewById(R.id.user_image);
            user_name = itemView.findViewById(R.id.user_name);
            user_phone = itemView.findViewById(R.id.user_phone);
        }
    }
}
