package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Entity;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.PrimaryKey;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;


@Dao
public interface GroupThreadDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(GroupThread groupThread);

    @Update
    void update(GroupThread groupThread);

    @Delete
    void delete(GroupThread groupThread);

    @Query("Delete From group_thread_table ")
    void deleteAllThread();

    @Query("Delete From group_thread_table WHERE `key`=:threadId ")
    void deleteThread(String threadId);


    @Query("SELECT * FROM  group_thread_table where(workplaceKey=:workKey AND workplace= :work AND group_receiver_id = :receiver_id)   ORDER BY timestamp ASC ")
    LiveData<List<GroupThread>> getAlThread(String workKey,String work,  String receiver_id);


    @Query("UPDATE group_thread_table SET position=:position WHERE `key`=:threadTd")
    void updatePositionsOfThread(String threadTd,int position);
}
