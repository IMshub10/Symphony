package com.shubham.signuppage.Chat;

import android.content.Context;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.BackgroundColorSpan;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.shubham.signuppage.R;
import Interfaces.RecyclerViewItemClickListener;

import com.shubham.signuppage.Room.SearchMessage;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RecyclerViewSearch extends ListAdapter<SearchMessage, RecyclerViewSearch.ThreadHolder> {

    public Context context;

    private RecyclerViewItemClickListener recyclerViewItemClickListener;

    public RecyclerViewSearch(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;

        // this.Friend_Key=FriendKey;

    }

    public void setOnItemClickListener(RecyclerViewItemClickListener recyclerViewItemClickListener) {
        this.recyclerViewItemClickListener = recyclerViewItemClickListener;
    }


    public static final DiffUtil.ItemCallback<SearchMessage> DIFF_CALLBACK = new DiffUtil.ItemCallback<SearchMessage>() {
        @Override
        public boolean areItemsTheSame(@NonNull SearchMessage oldItem, @NonNull SearchMessage newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull SearchMessage oldItem, @NonNull SearchMessage newItem) {

            return
                    oldItem.getSender().equals(newItem.getSender()) &&
                            oldItem.getCreate_date().equals(newItem.getCreate_date()) &&
                            oldItem.getTimestamp().equals(newItem.getTimestamp());

        }
    };

    @NonNull
    @Override
    public RecyclerViewSearch.ThreadHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.search_list_item, parent, false);
        return new ThreadHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerViewSearch.ThreadHolder holder, int position) {
        SearchMessage current_message = getItem(position);

        String text = current_message.getMessage_text();
        Spannable spanText = new SpannableString(text);

        int offset = text.toLowerCase().indexOf(current_message.getFilter().toLowerCase());
        while (offset >= 0) {
            spanText.setSpan(
                    new BackgroundColorSpan(0xffff8500),
                    offset,
                    offset + current_message.getFilter().toLowerCase().length(),
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            StringBuilder s = new StringBuilder(" ");
            for (int i = 1; i <= offset + current_message.getFilter().toLowerCase().length(); i++) {
                s.append(" ");
            }
            try {
                text = s + text.substring(offset + current_message.getFilter().toLowerCase().length() + 1);
                offset = text.toLowerCase().indexOf(current_message.getFilter().toLowerCase());
            } catch (Exception e) {
                break;
            }
        }
        holder.text.setText(spanText);

        holder.messageKey.setText(current_message.getKey());

        holder.name.setText(current_message.getSender());
        Linkify.addLinks(holder.text, Linkify.ALL);

        String currentTimestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        long currentTimestamps = Long.parseLong(currentTimestamp);
        long timestamps = Long.parseLong(current_message.getTimestamp());
        timestamps = timestamps + 1000000;
        if (currentTimestamps > timestamps) {
            holder.date.setText(current_message.getCreate_date());
        } else {
            String create = current_message.getCreate_date();
            create = create.substring(9, 17);
            holder.date.setText(create);
        }


        holder.text.setTextIsSelectable(false);

    }

    @Override
    public void onViewAttachedToWindow(@NonNull ThreadHolder holder) {
        super.onViewAttachedToWindow(holder);
    }

    @Override
    protected SearchMessage getItem(int position) {
        return super.getItem(position);
    }

    class ThreadHolder extends RecyclerView.ViewHolder {
        TextView name, text, date, messageKey;
        View message2;
        View view;

        public ThreadHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            text = itemView.findViewById(R.id.message);
            date = itemView.findViewById(R.id.date);
            messageKey = itemView.findViewById(R.id.messageKey);
            message2 = itemView.findViewById(R.id.message2);


            message2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecyclerViewSearch.this.recyclerViewItemClickListener.onItemClick(itemView, getLayoutPosition());
                }
            });
            message2.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    RecyclerViewSearch.this.recyclerViewItemClickListener.onLongItemClick(itemView, getLayoutPosition());
                    return false;
                }
            });
        }
    }

}
