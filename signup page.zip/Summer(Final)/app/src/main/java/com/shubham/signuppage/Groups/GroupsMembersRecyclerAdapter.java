package com.shubham.signuppage.Groups;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.Member;

import Interfaces.RecyclerViewItemClickListener;
import de.hdodenhof.circleimageview.CircleImageView;

public class GroupsMembersRecyclerAdapter extends ListAdapter<Member, GroupsMembersRecyclerAdapter.GroupMembersHolder> {


    private Context context;
    private RecyclerViewItemClickListener recyclerViewItemClickListener;

    GroupsMembersRecyclerAdapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
    }
    private  static  final DiffUtil.ItemCallback<Member>DIFF_CALLBACK = new DiffUtil.ItemCallback<Member>() {
        @Override
        public boolean areItemsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Member oldItem, @NonNull Member newItem) {
            return oldItem.getName().equals(newItem.getName())
                    && oldItem.getWorkplace().equals(newItem.getWorkplace());
        }
    };

    @NonNull
    @Override
    public GroupMembersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.groups_contacts_listitem,parent,false);
        return new GroupMembersHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroupMembersHolder holder, int position) {
        Member current_member = getItem(position);
        holder.user_name.setText(current_member.getName());
        holder.user_phone.setText(current_member.getPhone());
        Glide.with(holder.user_image.getContext())
                .asBitmap()
                .error(R.drawable.mas)
                .load(R.drawable.dp)
                .into(holder.user_image);

    }

    public  void  setOnItemClickListener(RecyclerViewItemClickListener recyclerViewItemClickListener){
        this.recyclerViewItemClickListener= recyclerViewItemClickListener;
    }

    class GroupMembersHolder extends RecyclerView.ViewHolder{

        CircleImageView user_image;
        TextView user_name, user_phone;
        RelativeLayout relativeLayout;

        public GroupMembersHolder(@NonNull View itemView) {
            super(itemView);
            user_image = itemView.findViewById(R.id.user_image);
            user_name = itemView.findViewById(R.id.user_name);
            user_phone = itemView.findViewById(R.id.user_phone);
            relativeLayout= itemView.findViewById(R.id.members_relativeLayout);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    GroupsMembersRecyclerAdapter.this.recyclerViewItemClickListener.onItemClick(itemView,getLayoutPosition());

                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    GroupsMembersRecyclerAdapter.this.recyclerViewItemClickListener.onLongItemClick(itemView,getLayoutPosition());
                    return false;
                }
            });
        }
    }
}
