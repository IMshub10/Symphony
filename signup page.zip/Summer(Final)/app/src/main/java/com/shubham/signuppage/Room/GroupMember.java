package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "group_member_table")
public class GroupMember {
    @PrimaryKey(autoGenerate = false)
    @NonNull
    private String key;
    private String name;
    private String phone;
    private String groupKey;
    private String workplace;

    public GroupMember(String key, String name, String phone, String groupKey, String workplace) {
        this.key = key;
        this.name = name;
        this.phone = phone;
        this.groupKey = groupKey;
        this.workplace = workplace;
    }

    public String getKey() { return key; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getGroupKey() {return groupKey; }
    public String getWorkplace() { return workplace; }

}
