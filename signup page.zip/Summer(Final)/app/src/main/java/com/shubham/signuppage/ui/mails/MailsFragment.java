package com.shubham.signuppage.ui.mails;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.shubham.signuppage.Chat.AllContacts;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.Member;
import com.shubham.signuppage.Room.MembersViewModel;
import com.shubham.signuppage.Services.LocalUserService;

import java.util.List;
import java.util.Objects;


public class MailsFragment extends Fragment {
    private MembersViewModel membersViewModel;
    private ReceiveLatestMessages receiveLatestMessages;
    private GetMembersTask getMembersTask;

    private String authKey;
    private String WorkplaceKey;
    private String Workplace;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_mails, container, false);
        setHasOptionsMenu(true);
        RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        TextView nullWorkplace = root.findViewById(R.id.nullWorkplace);

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        recyclerView.setHasFixedSize(true);
        final MailsAdapter adapter = new MailsAdapter(getActivity());
        recyclerView.setAdapter(adapter);
        // recyclerView.addItemDecoration(new DividerItemDecoration(Objects.requireNonNull(getActivity()), DividerItemDecoration.VERTICAL));
        final LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        membersViewModel = ViewModelProviders.of(this).get(MembersViewModel.class);
        String workPlace = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceName;
        membersViewModel.getAllMembersFrag(workPlace, "").observe(getViewLifecycleOwner(), new Observer<List<Member>>() {
            @Override
            public void onChanged(List<Member> members) {
                adapter.submitList(members);
            }
        });

        WorkplaceKey = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceKey;
        Workplace = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).CurrentWorkplaceName;
        authKey = LocalUserService.getLocalUserFromPreferences(getActivity().getApplicationContext()).Key;
        if (WorkplaceKey == null) {
            nullWorkplace.setVisibility(View.VISIBLE);
        } else {
            nullWorkplace.setVisibility(View.GONE);
        }
        receiveLatestMessages = new ReceiveLatestMessages();
        receiveLatestMessages.execute();
        return root;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.mails_menu, menu);
    }

    @Nullable
    @Override
    public Context getContext() {
        return super.getContext();
    }

    @Override
    public void onStart() {
        super.onStart();
        getMembersTask = new GetMembersTask();
        getMembersTask.execute();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.new_mail) {
            if (WorkplaceKey == null) {
                Toast.makeText(getContext(), "Please select a workplace", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(getContext(), AllContacts.class);
                startActivity(intent);
            }
        }
        return  true;
    }


    @Override
    public void onPause() {
        super.onPause();
        receiveLatestMessages.cancel(true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        receiveLatestMessages.cancel(true);
    }

    @Override
    public void onStop() {
        super.onStop();
        receiveLatestMessages.cancel(true);
        getMembersTask.cancel(true);
    }


    private class ReceiveLatestMessages extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            if (WorkplaceKey != null) {
                FirebaseDatabase.getInstance().getReference().child("Users").child(authKey)
                        .child("Mails").child(WorkplaceKey)
                        .child("LatestMessages").addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        if (dataSnapshot.exists()) {
                            membersViewModel.updateMemberMessageCount(WorkplaceKey
                                            + Objects.requireNonNull(dataSnapshot.child("ReceiverKey").getValue()).toString(),
                                    Objects.requireNonNull(dataSnapshot.child("Message").getValue()).toString(),
                                    Objects.requireNonNull(dataSnapshot.child("Create Date").getValue()).toString(),
                                    Objects.requireNonNull(dataSnapshot.child("Timestamp").getValue()).toString());
                            try {
                                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                Ringtone r = RingtoneManager.getRingtone(getContext(), notification);
                                r.play();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            FirebaseDatabase.getInstance().getReference().child("Users")
                                    .child(authKey)
                                    .child("Mails").child(WorkplaceKey)
                                    .child("LatestMessages").child(Objects.requireNonNull(dataSnapshot.getKey())).removeValue();
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }
            return null;
        }
    }

    public class GetMembersTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {

            if (WorkplaceKey != null) {
                FirebaseDatabase.getInstance().getReference().child("Workplaces").child(WorkplaceKey).child("Members")
                        .addChildEventListener(new ChildEventListener() {
                            @Override
                            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                                if (!Objects.equals(dataSnapshot.getKey(), authKey)) {
                                    String phone = Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString();
                                    membersViewModel.insert(new Member(WorkplaceKey +
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Name").getValue()).toString(),
                                            Objects.requireNonNull(dataSnapshot.child("Member Phone Number").getValue()).toString(),
                                            Workplace,
                                            Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString(),
                                            "",
                                            null, 0, null));
                                }
                            }

                            @Override
                            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                                membersViewModel.deleteMMember(WorkplaceKey +
                                        Objects.requireNonNull(dataSnapshot.child("Member Key").getValue()).toString());
                            }

                            @Override
                            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
            }
            return null;
        }
    }

}
