package com.shubham.signuppage.Room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Thread.class},version =12,exportSchema = false)
public abstract class ThreadDatabase extends RoomDatabase {
    private static ThreadDatabase instance;

    public  abstract ThreadDao threadDao();

    public  static synchronized ThreadDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    ThreadDatabase.class,"thread_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbTask(instance).execute();
        }
    };
    private  static class  PopulateDbTask extends AsyncTask<Void,Void,Void> {

        private  ThreadDao threadDao;
        private PopulateDbTask(ThreadDatabase database){
            threadDao = database.threadDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            return null;
        }
    }

}
