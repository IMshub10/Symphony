package com.shubham.signuppage.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ThreadRepository {
    private ThreadDao threadDao;
    private LiveData<List<Thread>> allThreads;

    public ThreadRepository(Application application) {
        ThreadDatabase threadDatabase = ThreadDatabase.getInstance(application);
        threadDao = threadDatabase.threadDao();
    }
    public  void insert(Thread thread){
        new InsertThreadTask(threadDao).execute(thread);
    }
    public  void delete(Thread thread){
        new DeleteThreadTask(threadDao).execute(thread);
    }
    public  void update(Thread thread){
        new UpdateThreadTask(threadDao).execute(thread);
    }
    public  void deleteAllThreads(){
        new DeleteAllThreadTask(threadDao).execute();
    }
    public  LiveData<List<Thread>> getAllThread(String workKey,String work, String sender,String receiver){
        allThreads = threadDao.getAlThread(workKey,work,sender,receiver);
        return  allThreads;
    }

    public  void  updatePositionsOfThread(String threadId,int position){
        new UpdatePositionsOfThreadTask(threadDao,threadId,position).execute();
    }

    public  List<Thread> getAllThreads(String work, String sender,String receiver,int position){

        return  threadDao.getThreads(work,sender,receiver,position);
    }
    public int getThread(String threaId){
        return  threadDao.getThread(threaId);
    }


    public void deleteThread(String threadId){
        new DeleteThreadxTask(threadDao).execute(threadId);
    }

    public static class UpdatePositionsOfThreadTask extends AsyncTask<Void,Void,Void>{
        private ThreadDao threadDao;
        private String threadId;
        private int position;

        public UpdatePositionsOfThreadTask(ThreadDao threadDao, String threadId, int position) {
            this.threadDao = threadDao;
            this.threadId = threadId;
            this.position = position;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            threadDao.updatePositionsOfThread(threadId,position);
            return null;
        }
    }
    private  static  class DeleteThreadxTask extends  AsyncTask<String,Void,Void>{

        private ThreadDao threadDao;
        private  DeleteThreadxTask(ThreadDao threadDao){
            this.threadDao = threadDao;
        }

        @Override
        protected Void doInBackground(String... strings) {
            threadDao.deleteThread(strings[0]);
            return null;
        }

    }

    private  static  class InsertThreadTask extends AsyncTask<Thread,Void,Void> {

        private ThreadDao threadDao;
        private  InsertThreadTask(ThreadDao threadDao){
            this.threadDao = threadDao;
        }

        @Override
        protected Void doInBackground(Thread... threads) {
            threadDao.insert(threads[0]);
            return null;

        }

    }
    private  static  class UpdateThreadTask extends  AsyncTask<Thread,Void,Void>{

        private ThreadDao threadDao;
        private  UpdateThreadTask(ThreadDao threadDao){
            this.threadDao = threadDao;
        }

        @Override
        protected Void doInBackground(Thread... threads) {
            threadDao.update(threads[0]);
            return null;
        }

    }
    private  static  class DeleteThreadTask extends  AsyncTask<Thread,Void,Void>{

        private ThreadDao threadDao;
        private  DeleteThreadTask(ThreadDao threadDao){
            this.threadDao = threadDao;
        }

        @Override
        protected Void doInBackground(Thread... threads) {
            threadDao.delete(threads[0]);
            return null;
        }

    }
    private  static  class DeleteAllThreadTask extends  AsyncTask<Void,Void,Void>{

        private ThreadDao threadDao;
        private  DeleteAllThreadTask(ThreadDao threadDao){
            this.threadDao = threadDao;
        }

        @Override
        protected Void doInBackground(Void ... voids) {
            threadDao.deleteAllThread();
            return null;
        }

    }
}
