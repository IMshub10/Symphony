package com.shubham.signuppage.Room;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.shubham.signuppage.ui.feeds.Feed;

import java.util.List;

@Dao
public interface GroupsDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Groups groups);

    @Update
    void update(Groups groups);

    @Delete
    void delete(Groups groups);

    @Query("Delete From groups_table ")
    void deleteAllGroups();

    @Query("DELETE FROM groups_table where `key`=:groupid")
    void deleteGroup(String groupid);

    @Query("SELECT * FROM  groups_table where workplace =:work  ORDER BY timestamp DESC ")
    LiveData<List<Groups>> getAllGroups(String work);

    @Query("SELECT count(*) FROM groups_table where (workplace=:work AND `key`=:groupKey)")
    int checkGroupAlreadyExists(String groupKey,String work);

    @Query("UPDATE groups_table SET lastmesage=:lastMess,createDate=:createDate,messsageCount=messsageCount+1,timestamp=:timestam WHERE `key`=:askey AND lastmesage!=:lastMess")
    void updateMemberMessageCOunt(String askey,String lastMess,String createDate,String timestam);

    @Query("UPDATE groups_table SET lastmesage=:lastMess,createDate=:createDate,messsageCount=:messageCount,timestamp=:timestam WHERE `key`=:askey")
    void updateMember(String askey,String lastMess,int messageCount,String createDate,String timestam);

    @Query("UPDATE groups_table SET messsageCount=:messageCount WHERE `key`=:askey")
    void updateMemberMessage(String askey,int messageCount);
}
