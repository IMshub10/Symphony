package Interfaces;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.shubham.signuppage.Chat.RecyclerviewMessage;
public interface ChatFinalActivityListener {
    void onItemClick(View view, int position);
    void  onLongItemClick(RecyclerviewMessage recyclerviewMessage, View view, int thread_position, int message_position);
    void  onSwipeRight(RecyclerView recyclerView, View view, int layoutPosition, int swipePosition);
    void  onSwipeLeft(RecyclerView recyclerView,View view, int layoutPosition,int swipePosition);
}
