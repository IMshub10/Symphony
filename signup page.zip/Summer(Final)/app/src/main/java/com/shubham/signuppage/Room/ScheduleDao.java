package com.shubham.signuppage.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ScheduleDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Schedule schedule);

    @Update
    void update(Schedule schedule);

    @Delete
    void delete(Schedule schedule);

    @Query("Delete From schedule_table")
    void deleteAllMessages();

    @Query("Delete From schedule_table WHERE `key`=:id")
    void deleteMessage(String id);

    @Query("SELECT * FROM  schedule_table where workplaceKey =:workKey  ")
    LiveData<List<Schedule>> getAllSchedule(String workKey);
}
