package com.shubham.signuppage.Room;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Groups.class},version = 5,exportSchema = false)
public abstract class GroupsDatabase  extends RoomDatabase {
    private static GroupsDatabase instance;

    public abstract GroupsDao groupsDao();

    public  static  synchronized GroupsDatabase getInstance(Context context){

        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    GroupsDatabase.class,"groups_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private  static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbTask(instance).execute();
        }
    };

    private  static class  PopulateDbTask extends AsyncTask<Void,Void,Void> {

        private  GroupsDao groupsDao;
        private PopulateDbTask(GroupsDatabase database){
            groupsDao = database.groupsDao();
        }


        @Override
        protected Void doInBackground(Void... voids) {

            return null;
        }
    }
}
