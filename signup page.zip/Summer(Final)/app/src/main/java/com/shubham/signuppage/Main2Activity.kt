package com.shubham.signuppage

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken
import com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.shubham.signuppage.Services.LocalUserService
import org.tensorflow.lite.Interpreter
import java.util.concurrent.TimeUnit

class Main2Activity : AppCompatActivity() {
    var phone: EditText? = null
    var otp: EditText? = null
    var countrycode: EditText? = null
    var mAuth: FirebaseAuth? = null
    var codeSent: String? = null
    var currentUser: FirebaseUser? = null
    var database: FirebaseDatabase? = null
    var databaseReference: DatabaseReference? = null
    var sharedPreferences: SharedPreferences? = null
    var sendotp: Button? = null
    var verify: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (LocalUserService.getLocalUserFromPreferences(this).ThemeId == true) {
            setTheme(R.style.MainActivity2_Dark);
        } else {
            setTheme(R.style.AppTheme);
        }
        setContentView(R.layout.activity_main2)
        phone = findViewById(R.id.phone)
        otp = findViewById(R.id.otp)
        countrycode = findViewById(R.id.countrycode)
        sendotp =  findViewById(R.id.sendotp)
        verify = findViewById(R.id.verify)
        mAuth = FirebaseAuth.getInstance()
        currentUser = mAuth!!.currentUser
        database = FirebaseDatabase.getInstance()
        databaseReference = database!!.reference
        sharedPreferences = getSharedPreferences("LocalUser", 0)

        sendotp!!.setOnClickListener { v->
            sendVerficationcode()
        }
        verify!!.setOnClickListener { v->
            val credential = PhoneAuthProvider.getCredential(codeSent!!, otp!!.text.toString())
            signInWithPhoneAuthCredential(credential)
        }
    }



    private fun sendVerficationcode() {
        if (phone!!.text.toString().length < 10 || phone!!.text.toString().length > 10) {
            phone!!.error = "Phone no. not valid"
            phone!!.requestFocus()
            return
        }
        if (phone!!.text.toString().isEmpty()) {
            phone!!.error = "Phone no. not valid"
            phone!!.requestFocus()
            return
        }
        PhoneAuthProvider.getInstance().verifyPhoneNumber(countrycode!!.text.toString() + phone!!.text.toString(), 60, TimeUnit.SECONDS, this,
                object : OnVerificationStateChangedCallbacks() {
                    override fun onVerificationCompleted(phoneAuthCredential: PhoneAuthCredential) {}
                    override fun onCodeSent(s: String, forceResendingToken: ForceResendingToken) {
                        super.onCodeSent(s, forceResendingToken)
                        Toast.makeText(this@Main2Activity, "OTP has been sent.", Toast.LENGTH_SHORT).show()
                        codeSent = s
                    }

                    override fun onVerificationFailed(e: FirebaseException) {}
                })
    }


    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        mAuth!!.signInWithCredential(credential).addOnCompleteListener(this) { task ->
            if (task.isSuccessful) {
                login()
            } else {
                if (task.exception is FirebaseAuthActionCodeException) {
                    Toast.makeText(this@Main2Activity, "Invalid OTP", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this@Main2Activity, MainActivity::class.java)
        startActivity(intent)
        super.onBackPressed()
    }

    fun login() {
        val intent = Intent(this@Main2Activity, Info::class.java)
        intent.putExtra("countrycode", countrycode!!.text.toString())
        intent.putExtra("phone", phone!!.text.toString())
        sharedPreferences!!.edit().putString("Phone", countrycode!!.text.toString() + phone!!.text.toString()).apply()
        startActivity(intent)
    }
}