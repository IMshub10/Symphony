package com.shubham.signuppage.Groups;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.google.firebase.database.FirebaseDatabase;
import com.shubham.signuppage.R;
import com.shubham.signuppage.Room.GroupMessage;
import com.shubham.signuppage.Room.GroupMessageViewModel;
import com.shubham.signuppage.Room.GroupThread;
import com.shubham.signuppage.Room.GroupThreadsViewModel;
import com.shubham.signuppage.Services.LocalUserService;

import java.util.List;
import java.util.Objects;

import Helper.MyItemTouchHelper;
import Interfaces.DownloadGroupFiles;
import Interfaces.GroupsChatActivityListener;
import Interfaces.RecyclerviewSwipeListener;
import Helper.Swipe;
import Interfaces.RecyclerViewItemClickListener;

public class RecyclerviewGroupThread extends ListAdapter<GroupThread, RecyclerviewGroupThread.ThreadHolder> {

    public Context context;
    private GroupMessageViewModel messageViewModel;

    private String Friend_Key;

    private GroupThreadsViewModel threadsViewModel;

    private GroupsChatActivityListener groupsChatActivityListener;

    public RecyclerView.RecycledViewPool viewPool;

    private DownloadGroupFiles downloadGroupFiles;

    public RecyclerviewGroupThread(Context context, String FriendKey) {
        super(DIFF_CALLBACK);
        this.context = context;
        this.Friend_Key = FriendKey;
        viewPool = new RecyclerView.RecycledViewPool();
        threadsViewModel = ViewModelProviders.of((GroupsChatActivity) context).get(GroupThreadsViewModel.class);
    }

    public void setOnItemClickListener(GroupsChatActivityListener groupsChatActivityListener) {
        this.groupsChatActivityListener = groupsChatActivityListener;

    }

    public void DownloadGroupFiles(DownloadGroupFiles downloadGroupFiles){
        this.downloadGroupFiles=downloadGroupFiles;
    }

    public static final DiffUtil.ItemCallback<GroupThread> DIFF_CALLBACK = new DiffUtil.ItemCallback<GroupThread>() {
        @Override
        public boolean areItemsTheSame(@NonNull GroupThread oldItem, @NonNull GroupThread newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull GroupThread oldItem, @NonNull GroupThread newItem) {

            return oldItem.getSender().equals(newItem.getSender()) &&
                    oldItem.getCreate_date().equals(newItem.getCreate_date()) &&
                    oldItem.getTimestamp().equals(newItem.getTimestamp());
        }
    };


    @NonNull
    @Override
    public ThreadHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.thread, parent, false);
        return new ThreadHolder(view);
    }

    @Override
    protected GroupThread getItem(int position) {
        return super.getItem(position);
    }

    @Override
    public void onBindViewHolder(@NonNull ThreadHolder holder, int position) {
        GroupThread current_thread = getItem(position);
        // Create layout manager with initial prefetch item count
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                holder.recyclerViewMessage.getContext(),
                LinearLayoutManager.VERTICAL,
                false
        );
        holder.thread_name.setText(current_thread.getSender());
        holder.thread_name.setVisibility(View.INVISIBLE);
        holder.thread_key.setText(current_thread.getKey());
        holder.thread_key.setVisibility(View.INVISIBLE);
        holder.threadLayout.setBackgroundColor(0xf2f2f5);
        //layoutManager.setInitialPrefetchItemCount(current_thread.);
        // Create sub item view adapter
        RecyclerviewGroupMessage recyclerviewMessage = new RecyclerviewGroupMessage(context, Friend_Key);
        holder.recyclerViewMessage.setLayoutManager(layoutManager);
        holder.recyclerViewMessage.setAdapter(recyclerviewMessage);
        ((SimpleItemAnimator) Objects.requireNonNull(holder.recyclerViewMessage.getItemAnimator())).setSupportsChangeAnimations(false);

        if (position != current_thread.getPosition()) {
            threadsViewModel.updatePositionsOfThread(current_thread.getKey(), position);
        }
        holder.recyclerViewMessage.setRecycledViewPool(viewPool);
//        holder.recyclerViewMessage.addItemDecoration(new DividerItemDecoration(context, LinearLayout.VERTICAL));
        Intent intent = ((GroupsChatActivity) context).getIntent();

        messageViewModel = ViewModelProviders.of((GroupsChatActivity) context).get(GroupMessageViewModel.class);

        messageViewModel.getAllMessages(LocalUserService.getLocalUserFromPreferences((GroupsChatActivity) context).CurrentWorkplaceKey,
                LocalUserService.getLocalUserFromPreferences((GroupsChatActivity) context).CurrentWorkplaceName,
                intent.getStringExtra("Friend_key"),
                current_thread.getKey())
                .observe((GroupsChatActivity) context, new Observer<List<GroupMessage>>() {
                    @Override
                    public void onChanged(List<GroupMessage> messages) {
                        recyclerviewMessage.submitList(messages);
                    }
                });
        SharedPreferences sharedPreferences = context.getSharedPreferences("Selectedthread", 0);
        recyclerviewMessage.setOnItemClickListener(new RecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int message_position) {
            }
            @Override
            public void onLongItemClick(View view, int message_position) {
               RecyclerviewGroupThread.this.groupsChatActivityListener.onLongItemClick(recyclerviewMessage,view,position,message_position);
            }
        });
        recyclerviewMessage.DownloadGroupFiles(new DownloadGroupFiles() {
            @Override
            public void onItemClick(GroupMessage groupMessage, int item_position, int file_position) {
                RecyclerviewGroupThread.this.downloadGroupFiles.onItemClick(groupMessage,item_position,file_position);
            }
        });
    }

    class ThreadHolder extends RecyclerView.ViewHolder {
        TextView thread_name, thread_key;
        RecyclerView recyclerViewMessage;
        LinearLayout threadLayout;

        public ThreadHolder(@NonNull View itemView) {
            super(itemView);
            thread_name = itemView.findViewById(R.id.thread_name);
            thread_key = itemView.findViewById(R.id.thread_key);
            recyclerViewMessage = itemView.findViewById(R.id.recyclerViewMessage);
            threadLayout = itemView.findViewById(R.id.threadLayout);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecyclerviewGroupThread.this.groupsChatActivityListener.onItemClick(itemView, getLayoutPosition());

                }
            });
            MyItemTouchHelper myItemTouchHelper = new MyItemTouchHelper(context,0, ItemTouchHelper.RIGHT, new Swipe(){
                @Override
                public void showReplyUIRight(int position) {
                    RecyclerviewGroupThread.this.groupsChatActivityListener.onSwipeRight(recyclerViewMessage,itemView, getLayoutPosition(),position);
                }
            });
            ItemTouchHelper itemTouchHelper = new ItemTouchHelper(myItemTouchHelper);
            itemTouchHelper.attachToRecyclerView(recyclerViewMessage);
            MyItemTouchHelper myItemTouchHelper1 = new MyItemTouchHelper(context,0,ItemTouchHelper.LEFT, new Swipe(){
                @Override
                public void showReplyUIRight(int position) {
                    RecyclerviewGroupThread.this.groupsChatActivityListener.onSwipeLeft(recyclerViewMessage,itemView, getLayoutPosition(),position);
                }
            });
            ItemTouchHelper itemTouchHelper1 = new ItemTouchHelper(myItemTouchHelper1);
            itemTouchHelper1.attachToRecyclerView(recyclerViewMessage);
        }
    }


}

