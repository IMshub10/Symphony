package com.shubham.signuppage.Models;

import android.net.Uri;

public class FilesUri {
    private String name;

    private String type;

    private Uri uri;

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public Uri getUri() {
        return uri;
    }

    public FilesUri(String name, String type, Uri uri) {
        this.name = name;
        this.type = type;
        this.uri = uri;
    }
}
