package com.shubham.signuppage.Room;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "member_table")
public class Member {
    @PrimaryKey(autoGenerate = false)
    @NonNull
    private  String key;

    private String name;

    private String  phone;

    private String  workplace;

    private String memberKey;

    private  String lastMessage;

    private String createDate;

    private int messsageCount;

    private String timestamp;

    public void setKey(@NonNull String key) {
        this.key = key;
    }

    @NonNull
    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getWorkplace() {
        return workplace;
    }

    public String getMemberKey() {
        return memberKey;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public String getCreateDate() {
        return createDate;
    }

    public int getMesssageCount() {
        return messsageCount;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public Member(@NonNull String key, String name, String phone, String workplace, String memberKey, String lastMessage, String createDate, int messsageCount, String timestamp) {
        this.key = key;
        this.name = name;
        this.phone = phone;
        this.workplace = workplace;
        this.memberKey = memberKey;
        this.lastMessage = lastMessage;
        this.createDate = createDate;
        this.messsageCount = messsageCount;
        this.timestamp = timestamp;
    }

    @Ignore
    public Member(){
    }
}

