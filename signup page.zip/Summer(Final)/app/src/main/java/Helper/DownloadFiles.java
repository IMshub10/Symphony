package Helper;

import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import androidx.appcompat.app.AlertDialog;

import java.io.File;

public class DownloadFiles {
    private Context context;

    public DownloadFiles(Context context) {
        this.context = context;
    }

    public  void DownloadChatFile(String url, String title, String mimeType){

        String extension;
        if (mimeType.equals("application/pdf")){
            extension=".pdf";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        else if (mimeType.equals("text/plain")){
            extension=".txt";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        else if (mimeType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")){
            extension=".docx";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        else if (mimeType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){
            extension=".xlsx";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        if (!FileExistsCheckChat(title)){
            DownloadManager.Request request=new DownloadManager.Request(Uri.parse(url));
            request.setTitle(title);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.HONEYCOMB){
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            }
            request.setDestinationInExternalPublicDir( File.separator + "Collab/Chat/Documents",title);
            DownloadManager downloadManager=(DownloadManager)context.getSystemService(Context.DOWNLOAD_SERVICE);
            request.setMimeType(mimeType);
            request.allowScanningByMediaScanner();
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);
            downloadManager.enqueue(request);
        }else {
            String x= title;
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("File Already Exists");
            builder.setMessage("Download Again ?");
            builder.setNegativeButton("NO",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
            builder.setPositiveButton("YES",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int which) {
                            DownloadManager.Request request=new DownloadManager.Request(Uri.parse(url));
                            request.setTitle(x);
                            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.HONEYCOMB){
                                request.allowScanningByMediaScanner();
                                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                            }
                            request.setDestinationInExternalPublicDir( File.separator + "Collab/Chat/Documents",x);
                            DownloadManager downloadManager=(DownloadManager)context.getSystemService(Context.DOWNLOAD_SERVICE);
                            request.setMimeType(mimeType);
                            request.allowScanningByMediaScanner();
                            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);
                            downloadManager.enqueue(request);

                        }
                    });
            builder.show();
        }

    }

    private Boolean FileExistsCheckChat(String title) {
        // File file = new File("/storage/emulated/0/MyApplication/title.pdf");
        File file = new   File(Environment.getExternalStorageDirectory()+File.separator+"Collab/Chat/Documents/"+title);
        Log.e("FileSeperator",Environment.getExternalStorageDirectory()+File.separator+"Collab/Chat/Documents/"+title );
        if (file.exists()){
            //Toast.makeText(this, "Exists", Toast.LENGTH_SHORT).show();
            return true;

        }else {
            //Toast.makeText(this, "Does not Exists", Toast.LENGTH_SHORT).show();
            return false;
        }

    }


    public  void DownloadGroupFile(String url,String title,String mimeType){

        String extension;
        if (mimeType.equals("application/pdf")){
            extension=".pdf";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        else if (mimeType.equals("text/plain")){
            extension=".txt";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        else if (mimeType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")){
            extension=".docx";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        else if (mimeType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){
            extension=".xlsx";
            if (!title.contains(extension)){
                title= title+extension;
            }
        }
        if (!FileExistsCheckGroups(title)){
            DownloadManager.Request request=new DownloadManager.Request(Uri.parse(url));
            request.setTitle(title);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.HONEYCOMB){
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            }
            request.setDestinationInExternalPublicDir( File.separator + "Collab/Groups/Documents",title);
            DownloadManager downloadManager=(DownloadManager)context.getSystemService(Context.DOWNLOAD_SERVICE);
            request.setMimeType(mimeType);
            request.allowScanningByMediaScanner();
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);
            downloadManager.enqueue(request);
        }else {
            String x= title;
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("File Already Exists");
            builder.setMessage("Download Again?");
            builder.setNegativeButton("NO",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
            builder.setPositiveButton("YES",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int which) {
                            DownloadManager.Request request=new DownloadManager.Request(Uri.parse(url));
                            request.setTitle(x);
                            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.HONEYCOMB){
                                request.allowScanningByMediaScanner();
                                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                            }
                            request.setDestinationInExternalPublicDir( File.separator + "Collab/Groups/Documents",x);
                            DownloadManager downloadManager=(DownloadManager)context.getSystemService(Context.DOWNLOAD_SERVICE);
                            request.setMimeType(mimeType);
                            request.allowScanningByMediaScanner();
                            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);
                            downloadManager.enqueue(request);

                        }
                    });
            builder.show();
        }
    }

    private Boolean FileExistsCheckGroups(String title) {
        // File file = new File("/storage/emulated/0/MyApplication/title.pdf");
        File file = new   File(Environment.getExternalStorageDirectory()+File.separator+"Collab/Groups/Documents/"+title);
        Log.e("FileSeperator",Environment.getExternalStorageDirectory()+File.separator+"Collab/Groups/Documents/"+title );
        if (file.exists()){
            return true;

        }else {
            return false;
        }

    }

    public    void DownloadFeedFile(String url,String title,String mimeType){

        String extension;
        switch (mimeType) {
            case "application/pdf":
                extension = ".pdf";
                if (!title.contains(extension)) {
                    title = title + extension;
                }
                break;
            case "text/plain":
                extension = ".txt";
                if (!title.contains(extension)) {
                    title = title + extension;
                }
                break;
            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                extension = ".docx";
                if (!title.contains(extension)) {
                    title = title + extension;
                }
                break;
            case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                extension = ".xlsx";
                if (!title.contains(extension)) {
                    title = title + extension;
                }
                break;
        }
        if (!FileExistsCheckFeeds(title)){
            DownloadManager.Request request=new DownloadManager.Request(Uri.parse(url));
            request.setTitle(title);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.HONEYCOMB){
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            }
            request.setDestinationInExternalPublicDir( File.separator + "Collab/Feeds/Documents",title);
            DownloadManager downloadManager=(DownloadManager)context.getSystemService(Context.DOWNLOAD_SERVICE);
            request.setMimeType(mimeType);
            request.allowScanningByMediaScanner();
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);
            if (downloadManager != null) {
                downloadManager.enqueue(request);
            }
        }else {
            String x= title;
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("File Already Exists");
            builder.setMessage("Download Again");
            builder.setNegativeButton("NO",
                    (dialog, which) -> {
                    });
            builder.setPositiveButton("YES",
                    (dialog, which) -> {
                        DownloadManager.Request request=new DownloadManager.Request(Uri.parse(url));
                        request.setTitle(x);
                        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.HONEYCOMB){
                            request.allowScanningByMediaScanner();
                            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        }
                        request.setDestinationInExternalPublicDir( File.separator + "Collab/Feeds/Documents",x);
                        DownloadManager downloadManager=(DownloadManager)context.getSystemService(Context.DOWNLOAD_SERVICE);
                        request.setMimeType(mimeType);
                        request.allowScanningByMediaScanner();
                        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE | DownloadManager.Request.NETWORK_WIFI);
                        if (downloadManager != null) {
                            downloadManager.enqueue(request);
                        }

                    });
            builder.show();
        }

    }
    private Boolean FileExistsCheckFeeds(String title) {
        // File file = new File("/storage/emulated/0/MyApplication/title.pdf");
        File file = new   File(Environment.getExternalStorageDirectory()+File.separator+"Collab/Feeds/Documents/"+title);
        Log.e("FileSeperator",Environment.getExternalStorageDirectory()+File.separator+"Collab/Feeds/Documents/"+title );
        return file.exists();

    }
}
